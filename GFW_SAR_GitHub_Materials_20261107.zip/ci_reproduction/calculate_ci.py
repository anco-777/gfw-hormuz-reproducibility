from pathlib import Path
import json, hashlib, platform, warnings
import numpy as np
import pandas as pd
import scipy
from scipy.stats import rankdata, chi2, beta

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'inputs/Reproducibility_Checked_20261027'
OUT=ROOT/'ci_results'; OUT.mkdir(exist_ok=True)
B=10000; SEED=20261030
COUNTS=['total_count','matched_strict_count','unmatched_count','unknown_count']
AREAS=['coverage_original_km2','coverage_half_grid_km2','coverage_half_grid_spherical_km2']
MODES=['original_nominal','half_nominal','half_spherical']
daily=pd.read_csv(SRC/'results/completed_raw/event_2026_daily_ais_and_area.csv')
boundary=pd.read_csv(SRC/'boundary/results/event_2026_daily_ais_and_area.csv')
for col in COUNTS+AREAS:
 assert np.allclose(daily[daily.cp=='CP27'][col],boundary[boundary.cp=='CP27'][col])
daily=pd.concat([daily,boundary[boundary.cp=='CP28']],ignore_index=True)
cps=sorted(daily.cp.unique()); names=daily.groupby('cp').name.first().to_dict()
dates=sorted(daily.date.unique()); cols=COUNTS+AREAS
arr=np.stack([daily[daily.cp==cp].sort_values('date')[cols].to_numpy(float) for cp in cps],axis=1)
assert np.array_equal(arr[:,:,0],arr[:,:,1:4].sum(axis=2))
assert not np.any((arr[:,:,0]>0)&(arr[:,:,4]<=0))
checks=[]
def check(name,a,b,tol):
 diff=float(np.nanmax(np.abs(np.array(a)-np.array(b))))
 assert diff<=tol,(name,diff)
 checks.append({'check':name,'max_abs_difference':diff,'tolerance':tol})
def idx(a,b):return np.flatnonzero((np.array(dates)>=a)&(np.array(dates)<=b))
pre27=idx('2026-02-01','2026-02-27');post27=idx('2026-03-01','2026-03-27')
windows={'27d':(pre27,post27),'25d':(idx('2026-02-01','2026-02-25'),idx('2026-03-01','2026-03-25')),
 '14d':(idx('2026-02-14','2026-02-27'),idx('2026-03-01','2026-03-14')),
 '7d':(idx('2026-02-21','2026-02-27'),idx('2026-03-01','2026-03-07')),
 'phase_1':(pre27,idx('2026-03-01','2026-03-07')),'phase_2':(pre27,idx('2026-03-08','2026-03-14')),
 'phase_3':(pre27,idx('2026-03-15','2026-03-27'))}
def div(a,b):
 with np.errstate(divide='ignore',invalid='ignore'):
  return np.where(b>0,a/b,np.nan)
def metrics(a,b,mode):
 aa=a[...,4+mode]; ab=b[...,4+mode]; na=a[...,0];nb=b[...,0]
 out={}
 for k,j in [('total',0),('matched',1),('unmatched',2)]:
  ra=1000*div(a[...,j],aa); rb=1000*div(b[...,j],ab)
  out[k+'_pre_rate']=ra;out[k+'_post_rate']=rb;out[k+'_change_pct']=100*(div(rb,ra)-1)
 out['count_change_pct']=100*(div(nb,na)-1)
 out['area_change_pct']=100*(div(ab,aa)-1)
 out['pre_unmatched_pct']=100*div(a[...,2],na)
 out['post_unmatched_pct']=100*div(b[...,2],nb)
 out['unmatched_change_pp']=out['post_unmatched_pct']-out['pre_unmatched_pct']
 return out
# Validate every available window and area point estimate before resampling.
for folder in ['results/completed_raw','boundary/results']:
 for typ in ['window','area_method']:
  tab=pd.read_csv(SRC/folder/f'event_2026_{typ}_sensitivity.csv')
  for _,r in tab.iterrows():
   w=r['window'] if typ=='window' else '27d'; mode=MODES.index(r.area_method) if typ=='area_method' else 0
   ia,ib=windows[w]; j=cps.index(r.cp);a=arr[ia,j].sum(0);b=arr[ib,j].sum(0)
   check(f'{folder}/{typ}/{r.cp}/{w}/{mode}/count',[a[0],b[0]],[r.pre_count,r.post_count],0)
   check(f'{folder}/{typ}/{r.cp}/{w}/{mode}/area',[a[4+mode],b[4+mode]],[r.pre_coverage_km2_obs,r.post_coverage_km2_obs],0.00002)
   if np.isfinite(r.change_pct):check(f'{folder}/{typ}/{r.cp}/{w}/{mode}/change',metrics(a,b,mode)['total_change_pct'],r.change_pct,0.00002)

cache={}
def weights(ids,L):
 # Identical windows reuse exact draws, preserving shared baselines and all regions.
 key=(tuple(ids),L)
 if key not in cache:
  n=len(ids); rng=np.random.default_rng(np.random.SeedSequence([SEED,L,int(ids[0]),n]))
  starts=rng.integers(0,n,(B,int(np.ceil(n/L))))
  take=((starts[:,:,None]+np.arange(L))%n).reshape(B,-1)[:,:n]
  w=np.zeros((B,n),dtype=np.int16)
  np.add.at(w,(np.repeat(np.arange(B),n),take.ravel()),1)
  cache[key]=w
 return cache[key]
def samples(ids,L):return (weights(ids,L)@arr[ids].reshape(len(ids),-1)).reshape(B,len(cps),7)
def quant(x):
 v=x[np.isfinite(x)];return (*np.quantile(v,[.025,.975],method='linear'),len(v)) if len(v) else (np.nan,np.nan,0)
rows=[];globalrows=[];classrows=[]
hist=pd.read_csv(SRC/'results/completed_raw/historical_exact_date_2017_2025_yearly.csv')
historical=hist.pivot(index='year',columns='cp',values='change_pct')[cps[:27]].to_numpy()
histlo=historical.min(0);histhi=historical.max(0)
for window,(ia,ib) in windows.items():
 pa=arr[ia].sum(0);pb=arr[ib].sum(0)
 da=(arr[ia,:,4]>0).sum(0);db=(arr[ib,:,4]>0).sum(0)
 for L in [1,3,7]:
  # L=n would reproduce the same whole window and create a spurious zero-width interval.
  if L>=min(len(ia),len(ib)):continue
  sa=samples(ia,L);sb=samples(ib,L)
  for mode in (range(3) if window=='27d' else [0]):
   point=metrics(pa,pb,mode);boot=metrics(sa,sb,mode)
   for metric,x in boot.items():
    for j,cp in enumerate(cps):
     lo,hi,nv=quant(x[:,j]);validpoint=np.isfinite(point[metric][j])
     dmin=da[j] if metric.endswith('pre_rate') or metric=='pre_unmatched_pct' else db[j] if metric.endswith('post_rate') or metric=='post_unmatched_pct' else min(da[j],db[j])
     flag='undefined' if not validpoint else 'screened_unreliable' if dmin<5 or nv/B<.95 or lo==hi else 'conditional_exploratory'
     rows.append({'window':window,'area_method':MODES[mode],'block_days':L,'cp':cp,'name':names[cp],'metric':metric,'estimate':point[metric][j],
      'lower95':lo if validpoint else np.nan,'upper95':hi if validpoint else np.nan,'pre_covered_days':int(da[j]),'post_covered_days':int(db[j]),'valid_replicates':nv,'invalid_fraction':1-nv/B,'status':flag})
   if window=='27d' and mode==0:
    dR=boot['total_change_pct'][:,:27];dN=boot['count_change_pct'][:,:27];du=boot['unmatched_change_pp'][:,:27]
    ok=np.isfinite(dR).all(1)&np.isfinite(du).all(1)
    okR=np.isfinite(dR).all(1);okN=np.isfinite(dN).all(1)
    rankx=rankdata(dR[ok],axis=1);ranky=rankdata(du[ok],axis=1)
    rankx-=rankx.mean(1)[:,None];ranky-=ranky.mean(1)[:,None]
    rho=(rankx*ranky).sum(1)/np.sqrt((rankx**2).sum(1)*(ranky**2).sum(1))
    from scipy.stats import spearmanr
    for label,val,est in [('median_rate_change_pct',np.median(dR[okR],1),np.median(point['total_change_pct'][:27])),('median_count_change_pct',np.median(dN[okN],1),np.median(point['count_change_pct'][:27])),('spearman',rho,spearmanr(point['total_change_pct'][:27],point['unmatched_change_pp'][:27]).statistic)]:
     lo,hi,nv=quant(val);globalrows.append(dict(metric=label,block_days=L,estimate=est,lower95=lo,upper95=hi,valid_replicates=nv,invalid_fraction=1-nv/B))
    for label,val in [('regions_rate_increase',(dR[ok]>0).sum(1)),('direction_reversal',(dR[ok]*dN[ok]<0).sum(1)),('outside_fixed_historical_range',((dR[ok]<histlo)|(dR[ok]>histhi)).sum(1))]:
     lo,hi,nv=quant(val);classrows.append(dict(metric=label,block_days=L,lower_stability=lo,upper_stability=hi,valid_replicates=nv,note='conditional stability range, not population-proportion CI'))
pd.DataFrame(rows).to_csv(OUT/'event_bootstrap_all.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(globalrows).to_csv(OUT/'joint_statistics.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(classrows).to_csv(OUT/'classification_stability.csv',index=False,encoding='utf-8-sig')
# Year clusters: uncertainty of a hypothetical comparable-year median, not historical min/max.
rng=np.random.default_rng(np.random.SeedSequence([SEED,90]));draw=rng.integers(0,9,(B,9))
hb=np.median(historical[draw],axis=1);hr=[]
for j,cp in enumerate(cps[:27]):
 lo,hi,nv=quant(hb[:,j]);hr.append(dict(cp=cp,name=names[cp],years=9,median_pct=np.median(historical[:,j]),lower95=lo,upper95=hi,interpretation='exploratory year-cluster bootstrap; no within-year resampling'))
pd.DataFrame(hr).to_csv(OUT/'historical_median_bootstrap.csv',index=False,encoding='utf-8-sig')

def cp_ci(k,n):
 k=np.asarray(k,float);n=np.asarray(n,float)
 lo=np.where(k==0,0,beta.ppf(.025,k,n-k+1));hi=np.where(k==n,1,beta.ppf(.975,k+1,n-k))
 return np.where(n>0,lo,np.nan),np.where(n>0,hi,np.nan)
def rate_ci(n,a):
 return np.where(a>0,1000*np.where(n==0,0,chi2.ppf(.025,2*n))/(2*a),np.nan),np.where(a>0,1000*chi2.ppf(.975,2*(n+1))/(2*a),np.nan)
# Model-based benchmarks only. No assertion of independent detections.
hc=hist.copy();l,h=cp_ci(hc.post_count.to_numpy(),(hc.pre_count+hc.post_count).to_numpy())
for period in ['pre','post']:
 hc[period+'_rate_lower95'],hc[period+'_rate_upper95']=rate_ci(hc[period+'_count'].to_numpy(),hc[period+'_coverage_km2_obs'].to_numpy())
with np.errstate(divide='ignore',invalid='ignore'):
 for suf,p in [('lower95',l),('upper95',h)]:hc[suf]=100*((hc.pre_coverage_km2_obs/hc.post_coverage_km2_obs)*p/(1-p)-1)
hc['method']='independent-Poisson exact rate-ratio benchmark only'
hc.to_csv(OUT/'historical_yearly_poisson_benchmark.csv',index=False,encoding='utf-8-sig')
pa=arr[pre27].sum(0);pb=arr[post27].sum(0);pr=[]
for j,cp in enumerate(cps):
 l,h=cp_ci(pb[j,0],pa[j,0]+pb[j,0]); ratio=pa[j,4]/pb[j,4]
 with np.errstate(divide='ignore',invalid='ignore'):lo=100*(ratio*l/(1-l)-1);hi=100*(ratio*h/(1-h)-1)
 item=dict(cp=cp,name=names[cp],estimate=metrics(pa,pb,0)['total_change_pct'][j],lower95=lo,upper95=hi,method='independent-Poisson exact rate-ratio and binomial-share benchmarks only')
 for period,a in [('pre',pa[j]),('post',pb[j])]:
  item[period+'_rate_lower95'],item[period+'_rate_upper95']=rate_ci(a[0],a[4])
  item[period+'_unmatched_share_lower95'],item[period+'_unmatched_share_upper95']=cp_ci(a[2],a[0])
 pr.append(item)
pd.DataFrame(pr).to_csv(OUT/'event_poisson_benchmark.csv',index=False,encoding='utf-8-sig')
monthly=pd.read_csv(SRC/'data/07_全球AIS未匹配占比月度_2017至2026.csv');monthly['year']=monthly.month.str[:4].astype(int)
annual=pd.read_csv(SRC/'data/08_全球AIS未匹配占比年度_2017至2026.csv');annualrows=[]
for year,g in monthly.groupby('year',sort=True):
 g=g.sort_values('month');n=len(g);a=g.total_sar_detections.to_numpy();u=g.ais_unmatched_detections.to_numpy()
 ar=annual[annual.year==year].iloc[0];check(f'annual/{year}',[a.sum(),u.sum()],[ar.total_sar_detections,ar.ais_unmatched_detections],0)
 for L in [1,3]:
  rng=np.random.default_rng(np.random.SeedSequence([SEED,year,L]));starts=rng.integers(0,n,(B,int(np.ceil(n/L))))
  take=((starts[:,:,None]+np.arange(L))%n).reshape(B,-1)[:,:n]
  values=100*u[take].sum(1)/a[take].sum(1);lo,hi,nv=quant(values)
  annualrows.append(dict(year=year,months=n,block_months=L,estimate_pct=100*u.sum()/a.sum(),lower95=lo,upper95=hi,interpretation='exploratory month-block interval; seasonality/version uncertainty not covered'))
pd.DataFrame(annualrows).to_csv(OUT/'annual_share_month_bootstrap.csv',index=False,encoding='utf-8-sig')
annual['lower95_independent_binomial'],annual['upper95_independent_binomial']=cp_ci(annual.ais_unmatched_detections,annual.total_sar_detections)
annual.to_csv(OUT/'annual_share_binomial_benchmark.csv',index=False,encoding='utf-8-sig')
manifest=[]
for p in sorted(SRC.rglob('*')):
 relative = p.relative_to(SRC).as_posix()
 if p.is_file() and (relative.startswith(('results/completed_raw/','boundary/results/')) or p.name.startswith(('07_','08_'))):
  manifest.append(dict(path=relative,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
pd.DataFrame(manifest).to_csv(OUT/'input_sha256.csv',index=False)
(OUT/'validation.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'B':B,'seed':SEED,'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__},ensure_ascii=False,indent=2))
print('VALIDATION',len(checks),'checks passed')
res=pd.DataFrame(rows);f=res[(res.window=='27d')&(res.area_method=='original_nominal')&(res.block_days==3)&(res.metric=='total_change_pct')]
print(f[['cp','name','estimate','lower95','upper95','pre_covered_days','post_covered_days','invalid_fraction','status']].to_string(index=False))
print(pd.DataFrame(globalrows).to_string(index=False))
