# 海运区域船舶活动研究数据与分析代码

本包集中保存正文和补充材料所引用的衍生数据、复算代码、置信区间输入输出及图表源数据。整理日期为2026年11月7日；内容取自2026年11月6日校对配套包，保留201个文件的原字节内容。

## 文件对应

| 目录 | 用途 | 文件数 |
| --- | --- | ---: |
| Reproducibility_Checked_20261027 | 区域边界、衍生数据、原始文件清单、分析代码和历史核查记录 | 130 |
| ci_reproduction | 置信区间程序、18项输入校验值及结果 | 31 |
| Source_Data | 36项图表与补充说明索引、图表数值和显示值CSV | 40 |

先阅读 Source_Data/figure_table_index.csv。索引中的相对路径以本包根目录为起点。Source_Data/tables 保留2026年11月6日配套包的显示值；其中引用编号和文字不应自动替代后续手工修改的稿件。Reproducibility_Checked_20261027/tables 中的表格属于历史版本。

## 运行入口

完整说明和依赖版本见各目录README及requirements文件。置信区间计算会覆盖ci_reproduction/ci_results；重算前请保留原结果。

```text
cd Reproducibility_Checked_20261027
python -m pip install -r requirements_figures.txt
python code/validate_current_package.py --out-dir validation_new
python code/verify_temporal_order.py --root . --output-dir temporal_new --plot
```

```text
cd ci_reproduction
python -m pip install -r requirements.txt
python calculate_ci.py
```

从原始CSV完整重算的入口为 Reproducibility_Checked_20261027/code/run_completed_raw.py；好望角边界分析入口为 Reproducibility_Checked_20261027/boundary/code/compute_cape_boundary.py。

## 本次迁移核查

- 36项图表索引的全部文件路径存在。
- 复算包已有的128项SHA-256校验值全部吻合。
- 置信区间的18项输入SHA-256校验值全部吻合。
- 本次只进行了迁移完整性检查，没有重新运行原始CSV分析或统计计算。
- 根目录FILE_MANIFEST.csv记录201个研究材料文件的大小和SHA-256。

## 原始数据和上游来源

约92.87 GiB原始GFW CSV和原始卫星影像未包含在本包中。原始文件清单位于 Reproducibility_Checked_20261027/results/completed_raw/raw_input_inventory.csv。数据需通过GFW下载并遵守其获取及使用条款；第三方数据、代码和底图保留原权利，不在此重新授予许可。

- GFW数据入口：https://globalfishingwatch.org/datasets-and-code/
- 上游SAR检测代码：https://github.com/GlobalFishingWatch/paper-industrial-activity
- 上游SAR—AIS匹配研究代码：https://github.com/GlobalFishingWatch/paper-longline-ais-sar-matching
- 旧版公开入口：https://gfw-hormuz-reproducibility-20261024.bold-wasp-3237.chatgpt.site/

旧版网页标注的2026年10月24日固定压缩包尚未随本迁移包复制，其原下载地址和网页公布的校验值见LEGACY_DOWNLOADS.csv。不能把本包当作该固定版本的逐字节副本。本包包含现稿引用的后续复核材料。

研究区坐标说明和Natural Earth来源说明保留在配套目录内。文献DOI、维基百科及其他第三方网页仍作为来源引用，不代表本文托管的研究材料。
