"""Recompute the 2017-2025 exact-date February/March historical baseline.

Each year compares 1-27 February with 1-27 March.  Counts and cumulative
observed areas are aggregated from raw GFW monthly CSV files using the same
region geometry, per-file footprint deduplication and original grid-centre
area approximation as the main 2026 event analysis.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

from spatial_core import (
    covered_area_grid,
    flat_coords,
    footprint_key,
    load_regions,
    make_grid,
    points_in_polygon,
    points_near_panama,
    region_bbox,
    snapshot_file_lists,
)

csv.field_size_limit(2**31 - 1)


WORKER_REGIONS = None
WORKER_PANAMA = None
WORKER_GRIDS = None


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def init_worker(package_root_text):
    global WORKER_REGIONS, WORKER_PANAMA, WORKER_GRIDS
    package_root = Path(package_root_text)
    WORKER_REGIONS, WORKER_PANAMA = load_regions(package_root)
    WORKER_GRIDS = {
        rid: make_grid(rid, poly, WORKER_PANAMA)
        for rid, (_, poly) in WORKER_REGIONS.items()
    }


def process_footprint_file(path_text):
    path = Path(path_text)
    match = re.search(r"_(\d{4})(\d{2})(?:\d{2})?\.csv$", path.name)
    if not match:
        raise ValueError(path.name)
    year, month = int(match.group(1)), int(match.group(2))
    period = "pre" if month == 2 else "post"
    coverage = {rid: 0.0 for rid in WORKER_REGIONS}
    footprint_hits = {rid: 0 for rid in WORKER_REGIONS}
    rows_read = 0
    duplicates = 0
    seen = set()
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows_read += 1
            day_text = row.get("date") or ""
            if not day_text.startswith(f"{year:04d}-{month:02d}-"):
                continue
            try:
                day = int(day_text[-2:])
            except ValueError:
                continue
            if day > 27:
                continue
            wkt = row.get("footprint_wkt")
            if not wkt:
                continue
            key = footprint_key(row)
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            coords = flat_coords(wkt)
            if coords.size == 0:
                continue
            minx, miny = coords.min(axis=0)
            maxx, maxy = coords.max(axis=0)
            for rid, grid in WORKER_GRIDS.items():
                w, s, e, n = grid["bbox"]
                if maxx < w or minx > e or maxy < s or miny > n:
                    continue
                area = covered_area_grid(wkt, grid, "nominal")
                if area > 0:
                    coverage[rid] += area
                    footprint_hits[rid] += 1
    return year, period, rows_read, duplicates, coverage, footprint_hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()
    root = args.root.resolve()
    raw = args.raw_dir.resolve()
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    regions, panama = load_regions(root)
    grids = {rid: make_grid(rid, poly, panama) for rid, (_, poly) in regions.items()}
    detection_names, footprint_names = snapshot_file_lists(root)

    wanted = {f"{year}{month:02d}" for year in range(2017, 2026) for month in (2, 3)}
    detect_files = [raw / name for name in detection_names if any(f"_{ym}" in name for ym in wanted)]
    footprint_files = [raw / name for name in footprint_names if any(f"_{ym}" in name for ym in wanted)]
    if len(detect_files) != 18 or len(footprint_files) != 18:
        raise SystemExit(f"Expected 18 detection and 18 footprint files; found {len(detect_files)} and {len(footprint_files)}")
    missing = [p for p in detect_files + footprint_files if not p.is_file()]
    if missing:
        raise SystemExit(f"Missing inputs: {[p.name for p in missing]}")

    counts = {rid: {(year, period): 0 for year in range(2017, 2026) for period in ("pre", "post")} for rid in regions}
    detection_rows_read = 0
    for index, file in enumerate(detect_files, 1):
        match = re.search(r"_(\d{4})(\d{2})", file.name)
        year, month = int(match.group(1)), int(match.group(2))
        period = "pre" if month == 2 else "post"
        for chunk in pd.read_csv(file, usecols=["timestamp", "lat", "lon"], chunksize=300_000, low_memory=False):
            detection_rows_read += len(chunk)
            ts = pd.to_datetime(chunk["timestamp"], utc=True, errors="coerce")
            keep = ts.notna() & ts.dt.year.eq(year) & ts.dt.month.eq(month) & ts.dt.day.le(27)
            if not keep.any():
                continue
            lon = chunk.loc[keep, "lon"].to_numpy(float)
            lat = chunk.loc[keep, "lat"].to_numpy(float)
            for rid, (_, poly) in regions.items():
                w, s, e, n = region_bbox(rid, poly, panama)
                candidate = (lon >= w) & (lon <= e) & (lat >= s) & (lat <= n)
                if not candidate.any():
                    continue
                hit = points_near_panama(lon[candidate], lat[candidate], panama) if rid == 19 else points_in_polygon(lon[candidate], lat[candidate], poly)
                counts[rid][(year, period)] += int(hit.sum())
        print(f"detections [{index:02d}/18] {file.name}", flush=True)

    coverage = {rid: {(year, period): 0.0 for year in range(2017, 2026) for period in ("pre", "post")} for rid in regions}
    footprint_hits = {rid: {(year, period): 0 for year in range(2017, 2026) for period in ("pre", "post")} for rid in regions}
    footprint_rows_read = 0
    duplicates_skipped = 0
    with ProcessPoolExecutor(max_workers=args.workers, initializer=init_worker, initargs=(str(root),)) as pool:
        futures = [pool.submit(process_footprint_file, str(file)) for file in footprint_files]
        for index, future in enumerate(as_completed(futures), 1):
            year, period, rows_read, duplicates, local_coverage, local_hits = future.result()
            footprint_rows_read += rows_read
            duplicates_skipped += duplicates
            for rid in regions:
                coverage[rid][(year, period)] += local_coverage[rid]
                footprint_hits[rid][(year, period)] += local_hits[rid]
            print(f"footprints [{index:02d}/18] {year} {period}", flush=True)

    yearly_rows = []
    summary_rows = []
    for rid, (name, _) in regions.items():
        changes = []
        for year in range(2017, 2026):
            pre_count = counts[rid][(year, "pre")]
            post_count = counts[rid][(year, "post")]
            pre_area = coverage[rid][(year, "pre")]
            post_area = coverage[rid][(year, "post")]
            pre_rate = pre_count / pre_area * 1000 if pre_area > 0 else None
            post_rate = post_count / post_area * 1000 if post_area > 0 else None
            change = (post_rate / pre_rate - 1) * 100 if pre_rate and post_rate is not None else None
            if change is not None and np.isfinite(change):
                changes.append(change)
            yearly_rows.append({
                "cp": f"CP{rid:02d}", "name": name, "year": year,
                "pre_start": f"{year}-02-01", "pre_end": f"{year}-02-27",
                "post_start": f"{year}-03-01", "post_end": f"{year}-03-27",
                "pre_count": pre_count, "post_count": post_count,
                "pre_coverage_km2_obs": round(pre_area, 6), "post_coverage_km2_obs": round(post_area, 6),
                "pre_rate_per_1000_km2": round(pre_rate, 9) if pre_rate is not None else None,
                "post_rate_per_1000_km2": round(post_rate, 9) if post_rate is not None else None,
                "change_pct": round(change, 9) if change is not None else None,
                "pre_footprint_rows_counted": footprint_hits[rid][(year, "pre")],
                "post_footprint_rows_counted": footprint_hits[rid][(year, "post")],
            })
        values = np.asarray(changes, dtype=float)
        summary_rows.append({
            "cp": f"CP{rid:02d}", "name": name, "years_valid": len(values),
            "historical_median_pct": round(float(np.median(values)), 9) if len(values) else None,
            "historical_min_pct": round(float(values.min()), 9) if len(values) else None,
            "historical_max_pct": round(float(values.max()), 9) if len(values) else None,
        })

    yearly_path = out / "historical_exact_date_2017_2025_yearly.csv"
    summary_path = out / "historical_exact_date_2017_2025_summary.csv"
    write_csv(yearly_path, yearly_rows)
    write_csv(summary_path, summary_rows)
    metadata = {
        "method": "exact calendar dates; February 1-27 versus March 1-27 for each year",
        "years": list(range(2017, 2026)),
        "area_method": "original adaptive grid-centre integration with nominal spacing_km squared cell area",
        "footprint_deduplication": "within each monthly file by scene_id plus 12-byte BLAKE2b of original WKT",
        "detection_files": [p.name for p in detect_files],
        "footprint_files": [p.name for p in footprint_files],
        "detection_rows_read": detection_rows_read,
        "footprint_rows_read": footprint_rows_read,
        "duplicate_footprint_rows_skipped": duplicates_skipped,
        "yearly_output": str(yearly_path),
        "summary_output": str(summary_path),
    }
    (out / "historical_exact_date_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
