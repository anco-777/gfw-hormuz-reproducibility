"""Portable launcher for ORIGINAL algorithms, not new exact-date historical QC.

All inputs must match the filenames in the supplied snapshot metadata. The
launcher stops before computation when any required file is missing. It stages
path-adapted copies of the original scripts in a fresh directory and never
reuses caches. The original per-file footprint deduplication is preserved.
"""
import argparse
import ast
import csv
import json
import subprocess
import sys
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--preflight-only", action="store_true")
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    raw = args.raw_dir.resolve()
    run = args.run_dir.resolve()
    meta = json.loads((root / "data/原始JSON/27区域2017至2026连续14日完整结果.json").read_text(encoding="utf-8-sig"))
    detect = meta["detection_files"]
    footprints = meta["footprint_files"]
    if run.exists() and any(run.iterdir()):
        raise SystemExit("Choose an empty run directory; cache reuse is not allowed.")
    run.mkdir(parents=True, exist_ok=True)
    required = [("detection", n) for n in detect] + [("footprint", n) for n in footprints]
    rows = [{"kind": kind, "file": name, "present": (raw/name).is_file(), "bytes": (raw/name).stat().st_size if (raw/name).is_file() else None} for kind,name in required]
    with (run/"raw_input_inventory.csv").open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    missing = [r for r in rows if not r["present"]]
    print(json.dumps({"required_files":len(rows),"missing_files":len(missing),"raw_dir":str(raw),"mode":"preflight" if args.preflight_only else "original_raw_replication"}))
    if args.preflight_only:
        return
    if missing:
        raise SystemExit("Raw inputs missing. See raw_input_inventory.csv; no statistics were run.")
    (run/"work").mkdir()
    (run/"outputs").mkdir()
    scripts = root/"source/original_code"
    names = ["build_gfw_timeseries_3day_precise.py", "build_corrected_continuous_14day.py", "compare_27_regions_hormuz_event.py", "aggregate_27_regions_monthly_2026.py", "analyze_global_ais_unmatched.py", "analyze_27_region_event_context.py"]
    for name in names:
        text = (scripts/name).read_text(encoding="utf-8-sig")
        if name == "build_gfw_timeseries_3day_precise.py":
            # This original source is read as text before FILES= by helper
            # scripts, so preserve that lexical delimiter.
            (run/"work"/name).write_text(text,encoding="utf-8")
            continue
        tree = ast.parse(text)
        for node in tree.body:
            if isinstance(node,ast.Assign):
                identifiers={t.id for t in node.targets if isinstance(t,ast.Name)}
                if identifiers & {"ROOT","WORKSPACE"}:
                    node.value=ast.parse("Path("+repr(str(run))+")",mode="eval").body
                elif identifiers & {"DATA","DATA_DIR"}:
                    node.value=ast.parse("Path("+repr(str(raw))+")",mode="eval").body
            elif isinstance(node,ast.FunctionDef) and node.name == "load_file_lists":
                node.body=ast.parse("return [DATA_DIR / name for name in "+repr(detect)+"], [DATA_DIR / name for name in "+repr(footprints)+"]").body
            elif isinstance(node,ast.FunctionDef) and node.name == "choose_monthly_files":
                # Freeze the exact supplied snapshot instead of choosing newer
                # pipeline files found in a mixed download folder.
                node.body=ast.parse("return [DATA_DIR / name for name in "+repr(detect)+"]").body
        ast.fix_missing_locations(tree)
        (run/"work"/name).write_text(ast.unparse(tree)+"\n",encoding="utf-8")
    for name in names[1:]:
        print("Running",name,flush=True)
        with (run/(name+".log")).open("w",encoding="utf-8") as log:
            subprocess.run([sys.executable,str(run/"work"/name)],cwd=run,stdout=log,stderr=subprocess.STDOUT,check=True)
    print("Original algorithms completed. The historical output is the legacy 14-day method, not the manuscript exact-date method.")


if __name__ == "__main__":
    main()
