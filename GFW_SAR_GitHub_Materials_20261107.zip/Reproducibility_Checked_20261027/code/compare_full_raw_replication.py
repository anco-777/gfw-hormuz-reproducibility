"""Compare a fresh raw-data replication directory with the supplied bundle."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def max_abs(values):
    arr = np.asarray(values, dtype=float)
    return float(np.nanmax(np.abs(arr))) if arr.size else 0.0


def dataframe_diff(left_path, right_path, keys, numeric_columns=None):
    left = pd.read_csv(left_path)
    right = pd.read_csv(right_path)
    merged = left.merge(right, on=keys, suffixes=("_fresh", "_bundle"), how="outer", indicator=True)
    if numeric_columns is None:
        numeric_columns = [c for c in left.columns if c not in keys and pd.api.types.is_numeric_dtype(left[c])]
    diffs = {}
    for column in numeric_columns:
        a = pd.to_numeric(merged.get(column + "_fresh"), errors="coerce")
        b = pd.to_numeric(merged.get(column + "_bundle"), errors="coerce")
        diffs[column] = max_abs((a - b).fillna(0).to_numpy())
    return {"rows_fresh": len(left), "rows_bundle": len(right), "merge_status": merged["_merge"].value_counts().to_dict(), "max_abs_differences": diffs}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    run = args.run_dir.resolve()

    fresh_long = json.loads((run / "work/gfw_27_regions_2017_2026_corrected_continuous_14day.json").read_text(encoding="utf-8"))
    bundle_long = json.loads((root / "data/原始JSON/27区域2017至2026连续14日完整结果.json").read_text(encoding="utf-8-sig"))
    long_checks = []
    for fresh, bundle in zip(fresh_long["regions"], bundle_long["regions"]):
        long_checks.append({
            "cp": fresh["cp"],
            "count_max_abs": max_abs(np.asarray(fresh["counts"]) - np.asarray(bundle["counts"])),
            "coverage_max_abs_km2": max_abs(np.asarray(fresh["coverage_km2_obs"]) - np.asarray(bundle["coverage_km2_obs"])),
            "rate_max_abs": max_abs(np.asarray([x if x is not None else np.nan for x in fresh["rates_per_1000_km2"]]) - np.asarray([x if x is not None else np.nan for x in bundle["rates_per_1000_km2"]])),
        })

    fresh_event = json.loads((run / "outputs/GFW_27区域_霍尔木兹事件前后对比_20260222-20260327.json").read_text(encoding="utf-8"))
    bundle_event = json.loads((root / "data/原始JSON/事件前后完整结果.json").read_text(encoding="utf-8-sig"))
    event_checks = []
    for fresh, bundle in zip(fresh_event["regions"], bundle_event["regions"]):
        event_checks.append({
            "cp": fresh["cp"],
            "daily_count_max_abs": max_abs(np.asarray(fresh["daily_counts"]) - np.asarray(bundle["daily_counts"])),
            "daily_coverage_max_abs_km2": max_abs(np.asarray(fresh["daily_coverage_km2_obs"]) - np.asarray(bundle["daily_coverage_km2_obs"])),
            "main_change_abs_pp": abs(fresh["change_pct_matched_27d"] - bundle["change_pct_matched_27d"]),
        })

    fresh_monthly = json.loads((run / "work/gfw_27_regions_monthly_total_unmatched_2026.json").read_text(encoding="utf-8"))
    bundle_monthly = json.loads((root / "data/原始JSON/27区域2026年月度完整结果.json").read_text(encoding="utf-8-sig"))
    monthly_checks = []
    for fresh, bundle in zip(fresh_monthly["regions"], bundle_monthly["regions"]):
        for fresh_m, bundle_m in zip(fresh["monthly"], bundle["monthly"]):
            monthly_checks.append({
                "cp": fresh["cp"], "month": fresh_m["month"],
                "total_difference": fresh_m["total_sar_detections"] - bundle_m["total_sar_detections"],
                "unmatched_difference": fresh_m["ais_unmatched_detections"] - bundle_m["ais_unmatched_detections"],
                "unknown_difference": fresh_m["unknown_match_status"] - bundle_m["unknown_match_status"],
                "share_abs_difference": abs((fresh_m["ais_unmatched_share"] or 0) - (bundle_m["ais_unmatched_share"] or 0)),
            })

    comparisons = {
        "continuous_14day": long_checks,
        "event": event_checks,
        "regional_monthly": monthly_checks,
        "global_monthly": dataframe_diff(
            run / "outputs/GFW_全球SAR检测_AIS未匹配占比_月度_2017-2026.csv",
            root / "data/07_全球AIS未匹配占比月度_2017至2026.csv",
            ["month"],
        ),
        "global_annual": dataframe_diff(
            run / "outputs/GFW_全球SAR检测_AIS未匹配占比_年度_2017-2026.csv",
            root / "data/08_全球AIS未匹配占比年度_2017至2026.csv",
            ["year"],
        ),
    }
    tolerances = {
        "counts": 0.0,
        "coverage_km2": 0.0011,
        "rates": 0.0000011,
        "change_percentage_points": 0.0011,
    }
    checks = {
        "long_counts_exact": all(row["count_max_abs"] == 0 for row in long_checks),
        "long_coverage_within_rounding": all(row["coverage_max_abs_km2"] <= tolerances["coverage_km2"] for row in long_checks),
        "long_rates_within_rounding": all(row["rate_max_abs"] <= tolerances["rates"] for row in long_checks),
        "event_counts_exact": all(row["daily_count_max_abs"] == 0 for row in event_checks),
        "event_coverage_within_rounding": all(row["daily_coverage_max_abs_km2"] <= tolerances["coverage_km2"] for row in event_checks),
        "event_changes_within_rounding": all(row["main_change_abs_pp"] <= tolerances["change_percentage_points"] for row in event_checks),
        "regional_monthly_exact": all(
            row["total_difference"] == 0 and row["unmatched_difference"] == 0 and row["unknown_difference"] == 0 and row["share_abs_difference"] == 0
            for row in monthly_checks
        ),
        "global_monthly_exact": max(comparisons["global_monthly"]["max_abs_differences"].values()) == 0,
        "global_annual_exact": max(comparisons["global_annual"]["max_abs_differences"].values()) == 0,
    }
    payload = {
        "scope": "fresh computation from 114 detection and 114 footprint CSV files; no supplied caches reused",
        "fresh_metadata": {
            "detection_rows_read": fresh_long["detection_rows_read"],
            "footprint_rows_read": fresh_long["footprint_rows_read"],
            "duplicate_footprint_rows_skipped": fresh_long["duplicate_footprint_rows_skipped"],
        },
        "checks": checks,
        "passed": sum(checks.values()),
        "total": len(checks),
        "details": comparisons,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: payload[k] for k in ("scope", "fresh_metadata", "checks", "passed", "total")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
