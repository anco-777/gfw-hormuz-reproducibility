"""Regenerate the nine figures from packaged data; numerical reproduction, not pixel matching."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--out-dir',type=Path,required=True);a=p.parse_args();r=a.root;out=a.out_dir;out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.sans-serif':['SimSun','Microsoft YaHei','DejaVu Sans'],'axes.unicode_minus':False,'font.size':10})
pos,neg='#d9824c','#4b75a8'
def save(fig,name):
 fig.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(out/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
d=pd.read_csv(r/'results/completed_raw/event_2026_daily_ais_and_area.csv')
records=[]
for cp,g in d.groupby('cp'):
 b=g[g.date.between('2026-02-01','2026-02-27')];f=g[g.date.between('2026-03-01','2026-03-27')];nr=100*(f.total_count.sum()/b.total_count.sum()-1);rc=100*((f.total_count.sum()/f.coverage_original_km2.sum())/(b.total_count.sum()/b.coverage_original_km2.sum())-1)
 records.append([cp,g['name'].iloc[0],nr,rc])
s=pd.DataFrame(records,columns=['cp','name','raw_change','rate_change']).set_index('cp');s.to_csv(out/'figure_region_values.csv',encoding='utf-8-sig')
geo=json.loads((r/'data/regions_27.geojson').read_text(encoding='utf-8-sig'))['features'];land=json.loads((r/'data/ne_50m_land.geojson').read_text())['features']
def mapbase(ax,extent):
 ax.set_facecolor('#f4f7fa')
 for f in land:
  g=f['geometry'];polys=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
  for pp in polys:ax.add_patch(Polygon(pp[0],facecolor='#e0e5e9',edgecolor='#aeb8bf',linewidth=.2))
 ax.set_xlim(extent[:2]);ax.set_ylim(extent[2:]);ax.set_xlabel('经度');ax.set_ylabel('纬度');ax.grid(alpha=.15);ax.set_aspect('equal',adjustable='box')
def center(f):
 g=f['geometry'];v=np.array(g['coordinates'][0] if g['type']=='Polygon' else g['coordinates']);return (v.min(axis=0)+v.max(axis=0))/2
# Main 1
fig,ax=plt.subplots(figsize=(8,10));y=np.arange(len(s))
for i,z in enumerate(s.itertuples()):ax.plot([z.raw_change,z.rate_change],[i,i],color='#c4cbd0',lw=1)
ax.scatter(s.raw_change,y,facecolors='white',edgecolors='#8f989f',label='原始计数');ax.scatter(s.rate_change,y,c=[pos if x>0 else neg for x in s.rate_change],label='覆盖标准化');ax.set_yticks(y,s.index+' '+s.name);ax.invert_yaxis();ax.axvline(0,color='#b8bfc5');ax.set_xlabel('事件后相对事件前变化（%）');ax.legend();fig.tight_layout();save(fig,'main_01_coverage')
# Main 2 and Supplement 1
for main in [True,False]:
 fig,ax=plt.subplots(figsize=(13,6));mapbase(ax,[-180,180,-65,80])
 for f in geo:
  cp=f['properties']['cp'];v=s.loc[cp,'rate_change'];x,y=center(f);g=f['geometry'];color=(pos if v>0 else neg) if main else '#246c91'
  if main and g['type']=='Polygon':ax.add_patch(Polygon(g['coordinates'][0],facecolor=color,edgecolor=color,alpha=.2,lw=.5))
  if g['type']=='LineString':vtx=np.array(g['coordinates']);ax.plot(vtx[:,0],vtx[:,1],color=color,lw=1)
  ax.scatter([x],[y],s=(18+abs(v)*1.2 if main else 18),c=color,zorder=3);ax.annotate(cp,(x,y),xytext=(4,4),textcoords='offset points',fontsize=7)
 ax.set_title('橙色增加 蓝色下降' if main else '全球27个研究区域定位');save(fig,'main_02_spatial' if main else 'supplement_01_locations')
# Main 3
h=pd.read_csv(r/'results/completed_raw/historical_exact_date_2017_2025_summary.csv').set_index('cp').loc[s.index];fig,ax=plt.subplots(figsize=(8,10));y=np.arange(len(s));ax.hlines(y,h.historical_min_pct,h.historical_max_pct,color='#a8b3bc');ax.scatter(h.historical_median_pct,y,marker='|',color='#7e8b95');outside=(s.rate_change<h.historical_min_pct)|(s.rate_change>h.historical_max_pct);ax.scatter(s.rate_change,y,c=np.where(outside,pos,neg));ax.set_yticks(y,s.index+' '+s.name);ax.invert_yaxis();ax.axvline(0,color='#b8bfc5');ax.set_xlabel('变化（%）：线段为历史经验范围，非置信区间');fig.tight_layout();save(fig,'main_03_history')
# Main 4
z=pd.read_csv(r/'results/completed_raw/event_2026_ais_groups_27day_summary.csv').set_index('cp').loc[s.index];fig,ax=plt.subplots(figsize=(8,6));ax.scatter(s.rate_change,z.unmatched_share_change_pp,color=neg)
for cp in s.index:ax.annotate(cp,(s.loc[cp,'rate_change'],z.loc[cp,'unmatched_share_change_pp']),xytext=(3,3),textcoords='offset points',fontsize=7)
ax.axhline(0,color='#bbb');ax.axvline(0,color='#bbb');ax.set_xlabel('标准化检测率变化（%）');ax.set_ylabel('AIS未匹配占比变化（百分点）');ax.grid(alpha=.15);save(fig,'main_04_ais')
# Supplement 2
win=pd.read_csv(r/'results/completed_raw/event_2026_window_sensitivity.csv');fig,axes=plt.subplots(3,2,figsize=(9,9))
for ax,cp in zip(axes.flat,['CP01','CP02','CP13','CP19','CP26','CP27']):
 x=win[(win.cp==cp)&win.window.isin(['7d','14d','27d'])].set_index('window').loc[['7d','14d','27d']];ax.plot([7,14,27],x.change_pct,'o-');ax.set_xticks([7,14,27],['7日','14日','27日']);ax.set_title(s.loc[cp,'name']);ax.axhline(0,color='#bbb');ax.grid(alpha=.15)
fig.tight_layout();save(fig,'supplement_02_windows')
# Supplement 3
m=pd.read_csv(r/'data/07_全球AIS未匹配占比月度_2017至2026.csv');m['year']=m.month.str[:4].astype(int);an=m.groupby('year')[['total_sar_detections','ais_unmatched_detections']].sum();fig,axes=plt.subplots(2,1,figsize=(10,7));x=np.arange(len(an));axes[0].bar(x-.16,an.total_sar_detections/1e6,.32,label='总检测');axes[0].bar(x+.16,an.ais_unmatched_detections/1e6,.32,label='未匹配');axes[0].legend();axes[0].set_ylabel('百万次');axes[1].plot(x,100*an.ais_unmatched_detections/an.total_sar_detections,'o-');axes[1].set_ylabel('未匹配占比（%）')
for ax in axes:ax.set_xticks(x,[str(y) if y!=2026 else '2026上半年' for y in an.index]);ax.grid(axis='y',alpha=.15)
fig.suptitle('2026年资料截至6月29日，不与完整年度计数直接比较');fig.tight_layout();save(fig,'supplement_03_annual')
# Supplement 4, same algorithm as verify_temporal_order.py --plot, with Chinese labels.
fig,axes=plt.subplots(3,1,figsize=(10,10),sharex=True)
for ax,cp,color in zip(axes,['CP01','CP26','CP27'],['#a8442a','#25738a','#456942']):
 g=d[d.cp==cp].copy();g.date=pd.to_datetime(g.date);g=g.set_index('date');b=g.loc['2026-02-01':'2026-02-27'];rate=1000*b.total_count.sum()/b.coverage_original_km2.sum();post=g.loc['2026-03-01':'2026-03-27'];covered=post.coverage_original_km2>0;daily=100*(1000*post.total_count/post.coverage_original_km2.replace(0,np.nan)/rate-1);area=post.coverage_original_km2.rolling(7,min_periods=7).sum();counts=post.total_count.rolling(7,min_periods=7).sum();days=covered.rolling(7,min_periods=7).sum();smooth=(100*(1000*counts/area/rate-1)).where(days>=2)
 ax.scatter(post.index[covered],daily[covered],color=color);ax.plot(post.index,smooth,color=color);ax.axhline(0,color='#aaa');ax.plot(post.index[~covered],np.full((~covered).sum(),.025),'|',transform=ax.get_xaxis_transform(),color='#aaa');ax.set_title(s.loc[cp,'name']+f'（27日中{covered.sum()}日有覆盖）',loc='left');ax.set_ylabel('检测率变化（%）');ax.grid(alpha=.15)
fig.tight_layout();save(fig,'supplement_04_daily')
# Supplement 5
fig,(ax,bx)=plt.subplots(1,2,figsize=(10,6),gridspec_kw={'width_ratios':[2,1]});mapbase(ax,[12,34,-42,-26]);ax.add_patch(Rectangle((14,-40),18,11,fill=False,edgecolor='#59646e',lw=2,label='扩展边界'));ax.add_patch(Rectangle((15,-36.3),5.5,4.5,fill=False,edgecolor='#9070ab',linestyle='--',lw=2,label='窄边界'));ax.legend();b=pd.read_csv(r/'boundary/results/event_2026_area_method_sensitivity.csv');v=[float(b[(b.cp==cp)&(b.area_method=='original_nominal')].change_pct.iloc[0]) for cp in ['CP28','CP27']];bx.bar(['窄边界','扩展边界'],v,color=pos);bx.set_ylabel('标准化检测率变化（%）');bx.set_ylim(0,8)
for i,t in enumerate(v):bx.text(i,t+.1,f'+{t:.1f}%',ha='center')
fig.tight_layout();save(fig,'supplement_05_boundary')
print(json.dumps({'figures_generated':9,'scope':'Numerical figure reproduction; typography and label offsets may differ from manuscript','outputs':str(out)},ensure_ascii=False))
