"""Run the complete raw-data replication, including the previously missing analyses."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(command, log_path, cwd):
    print("Running", " ".join(map(str, command)), flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--hash-raw", action="store_true")
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    raw = args.raw_dir.resolve()
    run_dir = args.run_dir.resolve()
    if run_dir.exists() and any(run_dir.iterdir()):
        raise SystemExit("Choose an empty run directory.")
    run_dir.mkdir(parents=True, exist_ok=True)
    original_dir = run_dir / "original"
    completed_dir = run_dir / "completed_results"
    validation_dir = run_dir / "validation"
    completed_dir.mkdir()
    validation_dir.mkdir()
    python = sys.executable
    code = root / "code"

    run(
        [python, str(code / "run_original_raw.py"), "--raw-dir", str(raw), "--run-dir", str(original_dir)],
        run_dir / "01_original_raw.log", root,
    )
    run(
        [python, str(code / "compute_exact_date_history.py"), "--root", str(root), "--raw-dir", str(raw), "--out-dir", str(completed_dir), "--workers", str(args.workers)],
        run_dir / "02_exact_date_history.log", root,
    )
    run(
        [python, str(code / "compute_event_sensitivities_and_ais.py"), "--root", str(root), "--raw-dir", str(raw), "--out-dir", str(completed_dir)],
        run_dir / "03_event_sensitivities_and_ais.log", root,
    )
    inventory_command = [python, str(code / "inventory_raw_inputs.py"), "--root", str(root), "--raw-dir", str(raw), "--output", str(completed_dir / "raw_input_inventory.csv")]
    if args.hash_raw:
        inventory_command.append("--sha256")
    run(inventory_command, run_dir / "04_raw_inventory.log", root)
    run(
        [python, str(code / "compare_full_raw_replication.py"), "--root", str(root), "--run-dir", str(original_dir), "--output", str(validation_dir / "full_raw_replication_comparison.json")],
        run_dir / "05_full_raw_comparison.log", root,
    )
    run(
        [python, str(code / "validate_completed_raw_results.py"), "--root", str(root), "--results-dir", str(completed_dir), "--output-dir", str(validation_dir)],
        run_dir / "06_manuscript_table_validation.log", root,
    )
    run(
        [python, str(code / "verify_temporal_order.py"), "--root", str(root), "--daily", str(completed_dir / "event_2026_daily_ais_and_area.csv"), "--output-dir", str(run_dir / "temporal_order")],
        run_dir / "07_temporal_order.log", root,
    )
    print(f"Completed results: {completed_dir}")
    print(f"Validation: {validation_dir}")


if __name__ == "__main__":
    main()
