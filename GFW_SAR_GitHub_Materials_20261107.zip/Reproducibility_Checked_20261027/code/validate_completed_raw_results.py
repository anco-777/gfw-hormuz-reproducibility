"""Compare newly recomputed raw-data outputs with manuscript tables."""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path

import pandas as pd
from docx import Document


def number(text):
    value = text.strip().replace("−", "-").replace("–", "-").replace(",", "").replace("%", "").replace("+", "")
    if not value or value in {"—", "-"}:
        return None
    match = re.search(r"-?\d+(?:\.\d+)?", value)
    return float(match.group()) if match else None


def table_rows(doc, index):
    if isinstance(doc, tuple):
        table_dir, prefix = doc
        with (table_dir / f"{prefix}_{index + 1:02d}.csv").open(encoding="utf-8-sig", newline="") as handle:
            return list(csv.reader(handle))[1:]
    return [["".join(t.text or "" for t in cell._tc.xpath(".//w:t[not(ancestor::w:del)]")).strip() for cell in row.cells] for row in doc.tables[index].rows[1:]]


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def close(a, b, tolerance=0.0500001):
    if isinstance(a, float) and math.isnan(a):
        a = None
    if isinstance(b, float) and math.isnan(b):
        b = None
    if a is None or b is None:
        return a is None and b is None
    return abs(a - b) <= tolerance


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--results-dir", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    results = args.results_dir.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    # The public release contains exact manuscript-table CSVs, without draft
    # prose or reviewer comments. The private revision package also has DOCX.
    manuscript = Document(root.parent / "Manuscript.docx") if (root.parent / "Manuscript.docx").exists() else (root / "tables", "main")
    supplement = Document(root.parent / "Supplementary_Material.docx") if (root.parent / "Supplementary_Material.docx").exists() else (root / "tables", "supplement")

    exact = pd.read_csv(results / "historical_exact_date_2017_2025_summary.csv").set_index("cp")
    historical_rows = []
    for row in table_rows(supplement, 1):
        cp = row[0]
        actual = exact.loc[cp]
        expected = [number(row[3]), number(row[4]), number(row[5])]
        computed = [actual["historical_median_pct"], actual["historical_min_pct"], actual["historical_max_pct"]]
        historical_rows.append({
            "cp": cp, "name": row[1],
            "manuscript_median": expected[0], "computed_median": computed[0], "median_match_0_1": close(expected[0], computed[0]),
            "manuscript_min": expected[1], "computed_min": computed[1], "min_match_0_1": close(expected[1], computed[1]),
            "manuscript_max": expected[2], "computed_max": computed[2], "max_match_0_1": close(expected[2], computed[2]),
        })
    write_csv(out / "validation_exact_date_history.csv", historical_rows)

    sensitivity = pd.read_csv(results / "event_2026_area_method_sensitivity.csv")
    sensitivity = sensitivity.pivot(index="cp", columns="area_method", values="change_pct")
    area_rows = []
    for row in table_rows(supplement, 3):
        cp = row[0]
        expected = [number(row[2]), number(row[3]), number(row[4])]
        computed = [sensitivity.loc[cp, "original_nominal"], sensitivity.loc[cp, "half_nominal"], sensitivity.loc[cp, "half_spherical"]]
        area_rows.append({
            "cp": cp, "name": row[1],
            "manuscript_original": expected[0], "computed_original": computed[0], "original_match_0_1": close(expected[0], computed[0]),
            "manuscript_half": expected[1], "computed_half": computed[1], "half_match_0_1": close(expected[1], computed[1]),
            "manuscript_spherical": expected[2], "computed_spherical": computed[2], "spherical_match_0_1": close(expected[2], computed[2]),
        })
    write_csv(out / "validation_area_sensitivity.csv", area_rows)

    windows = pd.read_csv(results / "event_2026_window_sensitivity.csv")
    window_by_name = {(row["name"], row["window"]): row["change_pct"] for row in windows.to_dict(orient="records")}
    window_rows = []
    for row in table_rows(manuscript, 1):
        name = row[0]
        for window, cell in zip(("7d", "14d", "27d"), row[1:4]):
            expected = number(cell)
            computed = window_by_name.get((name, window))
            window_rows.append({"name": name, "window": window, "manuscript": expected, "computed": computed, "match_0_1": close(expected, computed)})
    write_csv(out / "validation_window_sensitivity.csv", window_rows)

    ais = pd.read_csv(results / "event_2026_ais_groups_27day_summary.csv").set_index("name")
    ais_rows = []
    for row in table_rows(manuscript, 3):
        name = row[0]
        actual = ais.loc[name]
        matched_counts = [int(v) for v in re.findall(r"\d+", row[1])]
        unmatched_counts = [int(v) for v in re.findall(r"\d+", row[2])]
        checks = [
            matched_counts[0] == actual["pre_matched_strict_count"],
            matched_counts[1] == actual["post_matched_strict_count"],
            unmatched_counts[0] == actual["pre_unmatched_count"],
            unmatched_counts[1] == actual["post_unmatched_count"],
            close(number(row[3]), actual["matched_strict_rate_change_pct"]),
            close(number(row[4]), actual["unmatched_rate_change_pct"]),
            close(number(row[5]), actual["unmatched_share_change_pp"]),
        ]
        ais_rows.append({
            "name": name,
            "manuscript_matched_counts": row[1], "computed_non_unmatched_counts": f"{int(actual['pre_non_unmatched_count'])}->{int(actual['post_non_unmatched_count'])}",
            "computed_strict_matched_counts": f"{int(actual['pre_matched_strict_count'])}->{int(actual['post_matched_strict_count'])}",
            "unknown_counts": f"{int(actual['pre_unknown_count'])}->{int(actual['post_unknown_count'])}",
            "manuscript_unmatched_counts": row[2], "computed_unmatched_counts": f"{int(actual['pre_unmatched_count'])}->{int(actual['post_unmatched_count'])}",
            "manuscript_matched_rate_change": number(row[3]), "computed_non_unmatched_rate_change": actual["non_unmatched_rate_change_pct"],
            "computed_strict_matched_rate_change": actual["matched_strict_rate_change_pct"],
            "manuscript_unmatched_rate_change": number(row[4]), "computed_unmatched_rate_change": actual["unmatched_rate_change_pct"],
            "manuscript_share_change_pp": number(row[5]), "computed_share_change_pp": actual["unmatched_share_change_pp"],
            "all_match_0_1": all(checks), "manuscript_uses_strict_matched": True,
            "interpretation": "manuscript matched column strictly excludes unknown status; total and unmatched-share denominator retain unknown records",
        })
    write_csv(out / "validation_ais_groups.csv", ais_rows)

    checks = {
        "exact_date_history_all_27_match_at_0_1": all(row["median_match_0_1"] and row["min_match_0_1"] and row["max_match_0_1"] for row in historical_rows),
        "area_sensitivity_all_27_match_at_0_1": all(row["original_match_0_1"] and row["half_match_0_1"] and row["spherical_match_0_1"] for row in area_rows),
        "window_sensitivity_all_reported_match_at_0_1": all(row["match_0_1"] for row in window_rows),
        "ais_groups_all_reported_match_at_0_1": all(row["all_match_0_1"] for row in ais_rows),
    }
    summary = {"checks": checks, "passed": sum(checks.values()), "total": len(checks)}
    (out / "completed_raw_validation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if summary["passed"] != summary["total"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
