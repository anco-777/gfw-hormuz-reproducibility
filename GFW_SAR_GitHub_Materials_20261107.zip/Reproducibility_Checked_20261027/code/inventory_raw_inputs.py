"""Inventory the exact 228 raw GFW snapshot files, optionally with SHA-256."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

from spatial_core import snapshot_file_lists


def sha256(path, block_size=8 * 1024 * 1024):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--sha256", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    raw = args.raw_dir.resolve()
    detections, footprints = snapshot_file_lists(root)
    required = [("detection", name) for name in detections] + [("footprint", name) for name in footprints]
    rows = []
    for index, (kind, name) in enumerate(required, 1):
        path = raw / name
        present = path.is_file()
        rows.append({
            "kind": kind,
            "file": name,
            "present": present,
            "bytes": path.stat().st_size if present else None,
            "sha256": sha256(path) if present and args.sha256 else "",
        })
        print(f"[{index:03d}/{len(required)}] {name}: {'ok' if present else 'missing'}", flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "required": len(rows),
        "present": sum(row["present"] for row in rows),
        "missing": sum(not row["present"] for row in rows),
        "total_bytes": sum(row["bytes"] or 0 for row in rows),
        "sha256_included": args.sha256,
        "output": str(args.output),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
