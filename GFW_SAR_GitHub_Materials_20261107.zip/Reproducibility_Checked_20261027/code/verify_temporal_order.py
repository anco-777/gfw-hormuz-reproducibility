"""Coverage-aware descriptive audit of the proposed Hormuz -> Mozambique -> Cape order.

No zero-exposure date is imputed as zero vessel activity. First qualifying
blocks are observed signal summaries, not estimates of a physical onset.
All sensitivity settings are exported; no p-values or causal claims are made.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import numpy as np
import pandas as pd

REGIONS = {'CP01': 'Hormuz', 'CP26': 'Mozambique', 'CP27': 'Cape of Good Hope'}
AREAS = {'original': 'coverage_original_km2', 'half_grid': 'coverage_half_grid_km2',
         'half_spherical': 'coverage_half_grid_spherical_km2'}
BASELINES = {'27d': '2026-02-01', '14d': '2026-02-14', '7d': '2026-02-21'}

def aggregate(frame, area):
    exposure = float(frame[area].sum())
    count = int(frame.total_count.sum())
    days = int((frame[area] > 0).sum())
    return count, exposure, days, 1000 * count / exposure if exposure > 0 else np.nan

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--daily', type=Path)
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--plot', action='store_true')
    args = parser.parse_args()
    daily = args.daily or args.root / 'results/completed_raw/event_2026_daily_ais_and_area.csv'
    output = args.output_dir or args.root / 'results/temporal_order'
    output.mkdir(parents=True, exist_ok=True)
    data = pd.read_csv(daily, parse_dates=['date'])
    assert not data.duplicated(['cp', 'date']).any()
    assert (data.total_count == data.matched_strict_count + data.unmatched_count + data.unknown_count).all()
    for area in AREAS.values():
        assert not ((data[area] <= 0) & (data.total_count > 0)).any()
    selected = data[data.cp.isin(REGIONS)].sort_values(['cp', 'date'])
    phases = []
    daily_output = []
    blocks = {}
    for cp, group in selected.groupby('cp', sort=True):
        assert len(group) == 55
        for mode, area in AREAS.items():
            for baseline, first in BASELINES.items():
                before = group[(group.date >= first) & (group.date <= '2026-02-27')]
                bn, ba, bd, br = aggregate(before, area)
                for _, row in group[group.date >= '2026-03-01'].iterrows():
                    valid = row[area] > 0 and br > 0
                    daily_output.append({'cp': cp, 'area_method': mode, 'baseline': baseline,
                        'date': row.date.date().isoformat(), 'total_count': row.total_count,
                        'area_km2': row[area], 'observed': bool(row[area] > 0),
                        'change_pct': 100 * (1000 * row.total_count / row[area] / br - 1) if valid else np.nan})
                for width in [3, 5, 7, 9]:
                    series = []
                    # Complete, disjoint blocks only; any tail is explicitly unused.
                    for offset in range(0, 28 - width, width):
                        start = pd.Timestamp('2026-03-01') + pd.Timedelta(days=offset)
                        end = start + pd.Timedelta(days=width - 1)
                        block = group[group.date.between(start, end)]
                        n, a, d, rate = aggregate(block, area)
                        series.append({'start': start.date().isoformat(), 'end': end.date().isoformat(),
                            'count': n, 'area_km2': a, 'covered_days': d,
                            'change_pct': 100 * (rate / br - 1) if br > 0 else np.nan})
                    blocks[cp, mode, baseline, width] = (series, bd)
            before = group[group.date.between('2026-02-01', '2026-02-27')]
            bn, ba, bd, br = aggregate(before, area)
            for first, last in [('2026-03-01', '2026-03-07'), ('2026-03-08', '2026-03-14'), ('2026-03-15', '2026-03-27')]:
                n, a, d, rate = aggregate(group[group.date.between(first, last)], area)
                phases.append({'cp': cp, 'name': REGIONS[cp], 'area_method': mode,
                    'baseline_count': bn, 'baseline_area_km2': ba, 'baseline_covered_days': bd,
                    'start': first, 'end': last, 'count': n, 'area_km2': a, 'covered_days': d,
                    'change_pct': 100 * (rate / br - 1) if br > 0 else np.nan})
    evaluations = []
    first_blocks = []
    for mode, baseline, width, threshold, persistence, minimum in itertools.product(
        AREAS, BASELINES, [3, 5, 7, 9], [0, 10, 20], [1, 2], [1, 2]):
        case = f'{mode}/{baseline}/{width}d/{threshold}pct/{persistence}blocks/{minimum}days'
        candidate = {}
        unresolved = False
        for cp in REGIONS:
            series, baseline_days = blocks[cp, mode, baseline, width]
            direction = -1 if cp == 'CP01' else 1
            qualifying = [baseline_days >= minimum and b['covered_days'] >= minimum and
                          np.isfinite(b['change_pct']) and direction * b['change_pct'] > threshold for b in series]
            index = next((i for i in range(len(series) - persistence + 1) if all(qualifying[i:i+persistence])), None)
            prior_gap = index is not None and any(b['covered_days'] < minimum for b in series[:index])
            candidate[cp] = series[index] if index is not None else None
            unresolved |= index is None or prior_gap or baseline_days < minimum
            first_blocks.append({'case': case, 'cp': cp, 'area_method': mode, 'baseline': baseline,
                'width_days': width, 'threshold_pct': threshold, 'persistence_blocks': persistence,
                'minimum_covered_days': minimum, 'baseline_covered_days': baseline_days,
                'first_start': series[index]['start'] if index is not None else None,
                'first_end': series[index]['end'] if index is not None else None,
                'first_change_pct': series[index]['change_pct'] if index is not None else np.nan,
                'earlier_unassessable_block': bool(prior_gap)})
        found = all(candidate.values())
        ordered = bool(found and candidate['CP01']['end'] < candidate['CP26']['start'] and
                       candidate['CP26']['end'] < candidate['CP27']['start'])
        evaluations.append({'case': case, 'area_method': mode, 'baseline': baseline, 'width_days': width,
            'threshold_pct': threshold, 'persistence_blocks': persistence, 'minimum_covered_days': minimum,
            'all_three_found': found, 'apparent_strict_order': ordered, 'coverage_unresolved': bool(unresolved),
            'strict_order_without_prior_coverage_gap': ordered and not unresolved})
    phases = pd.DataFrame(phases)
    evaluations = pd.DataFrame(evaluations)
    pd.DataFrame(daily_output).to_csv(output / 'daily_changes_fixed_baselines.csv', index=False, encoding='utf-8-sig')
    phases.to_csv(output / 'fixed_baseline_phases_three_regions.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(first_blocks).to_csv(output / 'first_qualifying_blocks.csv', index=False, encoding='utf-8-sig')
    evaluations.to_csv(output / 'all_temporal_order_sensitivities.csv', index=False, encoding='utf-8-sig')
    first_observations = []
    primary_daily = pd.DataFrame(daily_output)
    primary_daily = primary_daily[(primary_daily.area_method == 'original') & (primary_daily.baseline == '27d')]
    for cp, group in primary_daily.groupby('cp', sort=True):
        observed = group[group.observed]
        signal = observed[observed.change_pct < 0] if cp == 'CP01' else observed[observed.change_pct > 0]
        first_observations.append({'cp': cp, 'first_covered_post_event_day': observed.iloc[0].date,
            'first_observed_directional_signal_day': signal.iloc[0].date if len(signal) else None,
            'covered_post_event_days': len(observed),
            'interpretation': 'First observed day is not a physical onset; earlier dates may lack coverage.'})
    pd.DataFrame(first_observations).to_csv(output / 'first_observed_days.csv', index=False, encoding='utf-8-sig')
    summary = {'input_sha256': hashlib.sha256(daily.read_bytes()).hexdigest(),
        'input_rows': len(data), 'focused_regions': list(REGIONS), 'settings_evaluated': len(evaluations),
        'all_three_found_cases': int(evaluations.all_three_found.sum()),
        'apparent_strict_order_cases': int(evaluations.apparent_strict_order.sum()),
        'strict_order_without_prior_coverage_gap_cases': int(evaluations.strict_order_without_prior_coverage_gap.sum()),
        'coverage_unresolved_cases': int(evaluations.coverage_unresolved.sum()),
        'first_observations': first_observations,
        'primary_setting': {'area_method': 'original', 'baseline': '27d', 'width_days': 7,
                            'threshold_pct': 0, 'persistence_blocks': 1, 'minimum_covered_days': 2},
        'conclusion': 'The complete Hormuz-decrease -> Mozambique-increase -> Cape-increase chronology is not confirmed.',
        'interpretation': 'These are descriptive, coverage-aware observed-block diagnostics, not change-point estimates, significance tests, independent-vessel tracking, or causal identification.',
        'protocol': {'baselines': BASELINES, 'area_methods': AREAS, 'block_lengths_days': [3, 5, 7, 9],
            'thresholds_pct': [0, 10, 20], 'consecutive_qualifying_blocks': [1, 2], 'minimum_covered_days_per_block': [1, 2],
            'zero_coverage': 'missing, never a zero activity observation',
            'incomplete_terminal_blocks': 'excluded',
            'rate': 'sum of counts / sum of observed areas, not average of daily rates',
            'strict_order': 'end(Hormuz first qualifying block) < start(Mozambique first qualifying block) and end(Mozambique block) < start(Cape block)',
            'prior_coverage_gap': 'Any earlier block without the required covered days makes onset order unresolved.'}}
    (output / 'temporal_order_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if args.plot:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
        fig, axes = plt.subplots(3, 1, figsize=(9, 9.4), sharex=True)
        colors = ['#a8442a', '#25738a', '#456942']
        for ax, (cp, name), color in zip(axes, REGIONS.items(), colors):
            g = selected[selected.cp == cp].set_index('date')
            _, _, _, baseline_rate = aggregate(g.loc['2026-02-01':'2026-02-27'], AREAS['original'])
            post = g.loc['2026-03-01':'2026-03-27']
            obs = post.coverage_original_km2 > 0
            delta = 100 * (1000 * post.total_count / post.coverage_original_km2.replace(0, np.nan) / baseline_rate - 1)
            a = post.coverage_original_km2.rolling(7, min_periods=7).sum()
            n = post.total_count.rolling(7, min_periods=7).sum()
            days = obs.rolling(7, min_periods=7).sum()
            smooth = (100 * (1000 * n / a / baseline_rate - 1)).where(days >= 2)
            ax.axhline(0, color='#969d9d', lw=.8)
            ax.scatter(post.index[obs], delta[obs], color=color, s=32, label='Observed daily change', zorder=3)
            ax.plot(post.index, smooth, color=color, lw=1.8, label='Trailing 7-day aggregate')
            missing = post.index[~obs]
            ax.plot(missing, np.full(len(missing), .025), '|', transform=ax.get_xaxis_transform(), color='#abb1b7', ms=5)
            ax.set_title(f'{name}  |  {int(obs.sum())}/27 days with coverage', loc='left', fontsize=11, fontweight='bold')
            ax.set_ylabel('Rate change (%)');ax.grid(axis='y', alpha=.15)
            for s in ['top','right']:ax.spines[s].set_visible(False)
        axes[0].legend(frameon=False, fontsize=9, loc='best')
        axes[-1].xaxis.set_major_locator(mdates.DayLocator(interval=4));axes[-1].xaxis.set_major_formatter(mdates.DateFormatter('%b %d'))
        fig.suptitle('Temporal order cannot be resolved as a three-stage sequence', fontsize=14, fontweight='bold', x=.1, ha='left')
        fig.text(.1,.025,'Fixed baseline: Feb 1–27, 2026. Missing-coverage dates are grey ticks; no interpolation.\nLines require a complete 7-calendar-day window and at least two covered days. Detection events are not unique vessels.',fontsize=8.4,color='#4a5158')
        fig.subplots_adjust(top=.91,bottom=.12,left=.1,right=.97,hspace=.32)
        fig.savefig(output / 'temporal_order_daily_and_7day.png', dpi=200)
        fig.savefig(output / 'temporal_order_daily_and_7day.pdf')
        plt.close(fig)
    print(json.dumps({k: summary[k] for k in ['settings_evaluated','all_three_found_cases','apparent_strict_order_cases','strict_order_without_prior_coverage_gap_cases','coverage_unresolved_cases','conclusion']}, indent=2))

if __name__ == '__main__':
    main()
