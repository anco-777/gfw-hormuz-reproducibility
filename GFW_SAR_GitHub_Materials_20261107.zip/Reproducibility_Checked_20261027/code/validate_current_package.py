from pathlib import Path
import argparse,csv,json,math,re,hashlib,sys
import numpy as np
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--out-dir',type=Path,required=True);a=p.parse_args();r=a.root.resolve();out=a.out_dir.resolve();out.mkdir(parents=True,exist_ok=True)
checks=[]
def ck(name,ok,details=''):checks.append({'check':name,'pass':bool(ok),'details':str(details)})
def close(x,y,tol=0.000002):
 if pd.isna(x) or pd.isna(y):return pd.isna(x) and pd.isna(y)
 return abs(float(x)-float(y))<=tol
def num(x):
 s=str(x).replace(',','').replace('−','-').replace('–','-').replace('%','').replace('+','');m=re.search(r'-?\d+(?:\.\d+)?',s);return float(m.group()) if m else np.nan
def table(prefix,n):
 with (r/'tables'/f'{prefix}_{n:02d}.csv').open(encoding='utf-8-sig',newline='') as f:return list(csv.reader(f))[1:]
d=pd.read_csv(r/'results/completed_raw/event_2026_daily_ais_and_area.csv');cpids=[f'CP{i:02d}' for i in range(1,28)]
ck('daily_complete_grid',len(d)==1485 and set(d.cp)==set(cpids) and not d.duplicated(['cp','date']).any() and all(len(g)==55 for _,g in d.groupby('cp')))
ck('group_count_identity',(d.total_count==d.matched_strict_count+d.unmatched_count+d.unknown_count).all())
ck('counts_nonnegative_integer',all((d[c]>=0).all() and (d[c]%1==0).all() for c in ['total_count','matched_strict_count','unmatched_count','unknown_count']))
areas={'original_nominal':'coverage_original_km2','half_nominal':'coverage_half_grid_km2','half_spherical':'coverage_half_grid_spherical_km2'}
ck('coverage_nonnegative_no_counts_without_coverage',all((d[c]>=0).all() and not ((d[c]==0)&(d.total_count>0)).any() for c in areas.values()))
def agg(g,first,last,area='coverage_original_km2',count='total_count'):
 x=g[g.date.between(first,last)];n=x[count].sum();area_sum=x[area].sum();return n,area_sum,1000*n/area_sum if area_sum>0 else np.nan
def pct(x,y):return 100*(y/x-1) if pd.notna(x) and x>0 and pd.notna(y) else np.nan
summary={};name_to_cp={}
for cp,g in d.groupby('cp'):
 pre=agg(g,'2026-02-01','2026-02-27');post=agg(g,'2026-03-01','2026-03-27');pu=agg(g,'2026-02-01','2026-02-27',count='unmatched_count')[0];qu=agg(g,'2026-03-01','2026-03-27',count='unmatched_count')[0]
 summary[cp]={'name':g['name'].iloc[0],'pre':pre,'post':post,'count_change':pct(pre[0],post[0]),'rate_change':pct(pre[2],post[2]),'share_change':100*(qu/post[0]-pu/pre[0])};name_to_cp[g['name'].iloc[0]]=cp
for row in table('main',1):
 x=summary[name_to_cp[row[0]]];exp=[x['pre'][0],x['post'][0],x['count_change'],x['pre'][2],x['post'][2],x['rate_change']];ck('main1_'+row[0],all(close(num(v),e,t) for v,e,t in zip(row[1:],exp,[0,0,.0500001,.0005001,.0005001,.0500001])))
for row in table('supplement',1):
 x=summary[row[0]];exp=[x['pre'][0],x['post'][0],x['count_change'],x['rate_change'],x['share_change']];ck('supp1_'+row[0],all(close(num(v),e,t) for v,e,t in zip(row[2:],exp,[0,0,.0500001,.0500001,.0500001])))
x=pd.DataFrame(summary).T
rho=x.rate_change.astype(float).rank(method='average').corr(x.share_change.astype(float).rank(method='average'))
stat={'raw_median':float(x.count_change.median()),'rate_median':float(x.rate_change.median()),'raw_increases':int((x.count_change>0).sum()),'rate_increases':int((x.rate_change>0).sum()),'direction_reversals':int(((x.count_change*x.rate_change)<0).sum()),'unmatched_share_increases':int((x.share_change>0).sum()),'opposite_activity_share_directions':int(((x.rate_change*x.share_change)<0).sum()),'spearman':rho}
ck('headline_statistics',close(stat['raw_median'],12.5,.05) and close(stat['rate_median'],4.6,.05) and stat['raw_increases']==18 and stat['rate_increases']==18 and stat['direction_reversals']==6 and stat['unmatched_share_increases']==11 and stat['opposite_activity_share_directions']==13 and close(rho,.237,.0005),stat)
for filename in ['event_2026_area_method_sensitivity.csv','event_2026_window_sensitivity.csv','event_2026_fixed_baseline_phases.csv']:
 q=pd.read_csv(r/'results/completed_raw'/filename);ok=True
 for z in q.to_dict('records'):
  g=d[d.cp==z['cp']]
  if 'area_method' in z:area=areas[z['area_method']];before=('2026-02-01','2026-02-27');after=('2026-03-01','2026-03-27')
  elif 'window' in z:
   area=areas['original_nominal'];k=int(z['window'][:-1]);before=('2026-02-'+str(28-k).zfill(2),'2026-02-27') if k in [7,14] else ('2026-02-01',f'2026-02-{k}');after=('2026-03-01',f'2026-03-{k:02d}')
  else:area=areas['original_nominal'];before=(z['baseline_start'],z['baseline_end']);after=(z['phase_start'],z['phase_end'])
  b=agg(g,*before,area);f=agg(g,*after,area);ok &= close(pct(b[2],f[2]),z['change_pct'])
 ck('reaggregate_'+filename,ok,len(q))
h=pd.read_csv(r/'results/completed_raw/historical_exact_date_2017_2025_yearly.csv');ck('history_27_by_9',len(h)==243 and not h.duplicated(['cp','year']).any() and all(set(g.year)==set(range(2017,2026)) for _,g in h.groupby('cp')))
calc=100*((h.post_count/h.post_coverage_km2_obs)/(h.pre_count/h.pre_coverage_km2_obs)-1);ck('history_rates_from_counts_and_area',np.allclose(calc,h.change_pct,atol=.000002,rtol=0));hist=h.groupby('cp').change_pct.agg(['median','min','max']);outliers=[]
for row in table('supplement',2):
 cp=row[0];z=hist.loc[cp];val=summary[cp]['rate_change'];pos='低于范围' if val<z['min'] else '高于范围' if val>z['max'] else '范围内';outliers+=([cp] if pos!='范围内' else []);ck('supp2_'+cp,all(close(num(c),v,.0500001) for c,v in zip(row[2:6],[val,z['median'],z['min'],z['max']])) and row[6]==pos)
ck('nine_history_outliers',len(outliers)==9,outliers)
for row in table('supplement',4):
 cp=row[0];g=d[d.cp==cp];v=[pct(agg(g,'2026-02-01','2026-02-27',ar)[2],agg(g,'2026-03-01','2026-03-27',ar)[2]) for ar in areas.values()];ck('supp4_'+cp,all(close(num(c),v,.0500001) for c,v in zip(row[2:],v)))
for row in table('supplement',6):
 cp=name_to_cp[row[0]];g=d[d.cp==cp];v=[pct(agg(g,'2026-02-01',f'2026-02-{k}')[2],agg(g,'2026-03-01',f'2026-03-{k}')[2]) for k in [27,25]];ck('supp6_'+cp,all(close(num(c),v,.0500001) for c,v in zip(row[1:],v)))
monthly=pd.read_csv(r/'data/07_全球AIS未匹配占比月度_2017至2026.csv');monthly['year']=monthly.month.str[:4].astype(int);annual=monthly.groupby('year')[['total_sar_detections','ais_unmatched_detections']].sum();ck('monthly_114_unique',len(monthly)==114 and monthly.month.nunique()==114)
for row in table('supplement',5):
 yr=int(num(row[0]));z=annual.loc[yr];ck('supp5_'+str(yr),num(row[1])==z.total_sar_detections and num(row[2])==z.ais_unmatched_detections and close(num(row[3]),100*z.ais_unmatched_detections/z.total_sar_detections,.0500001))
ck('all_detection_records',int(annual.total_sar_detections.sum())==35371326)
geo=json.loads((r/'data/regions_27.geojson').read_text(encoding='utf-8-sig'));features={f['properties']['cp']:f for f in geo['features']};space=pd.read_csv(r/'data/01_27个研究区空间范围.csv').set_index('cp');ck('geometry_27_regions',len(features)==27 and set(features)==set(cpids))
for row in table('supplement',3):
 cp=row[0];f=features[cp];g=f['geometry'];points=g['coordinates'][0] if g['type']=='Polygon' else g['coordinates'];xs,ys=zip(*points);pad=.07 if cp=='CP19' else 0;vals=[min(xs)-pad,min(ys)-pad,max(xs)+pad,max(ys)+pad];ck('supp3_'+cp,all(close(num(c),v,.005001) for c,v in zip(row[2:],vals)))
for row in table('main',2):
 cp=name_to_cp[row[0]];g=d[d.cp==cp];expected=[]
 for k in [7,14,27]:
  before=('2026-02-'+str(28-k).zfill(2),'2026-02-27') if k in [7,14] else ('2026-02-01','2026-02-27')
  expected.append(pct(agg(g,*before)[2],agg(g,'2026-03-01',f'2026-03-{k:02d}')[2]))
 ck('main2_'+cp,all(close(num(c),e,.0500001) for c,e in zip(row[1:],expected)))
for cp,f in features.items():
 g=f['geometry'];pts=g['coordinates'][0] if g['type']=='Polygon' else g['coordinates'];xx,yy=zip(*pts);pad=.07 if cp=='CP19' else 0;vv=[min(xx)-pad,min(yy)-pad,max(xx)+pad,max(yy)+pad]
 ck('spatial_csv_'+cp,all(close(space.loc[cp,k],z,.000002) for k,z in zip(['bbox_west','bbox_south','bbox_east','bbox_north'],vv)))
bd=pd.read_csv(r/'boundary/results/event_2026_daily_ais_and_area.csv');bs=pd.read_csv(r/'boundary/results/event_2026_area_method_sensitivity.csv');ck('boundary_daily_complete',len(bd)==110 and not bd.duplicated(['cp','date']).any())
for z in bs.to_dict('records'):
 g=bd[bd.cp==z['cp']];ar=areas[z['area_method']];b=agg(g,'2026-02-01','2026-02-27',ar);f=agg(g,'2026-03-01','2026-03-27',ar);ck('boundary_reaggregate_'+z['cp']+'_'+z['area_method'],close(pct(b[2],f[2]),z['change_pct']))
for row in table('main',3):
 cp='CP28' if row[0]=='原始窄边界' else 'CP27';g=bd[bd.cp==cp];b=agg(g,'2026-02-01','2026-02-27');f=agg(g,'2026-03-01','2026-03-27');nn=[num(v) for v in row[2].split('→')];aa=[num(v) for v in row[3].split('→')];ck('main3_'+cp,nn==[b[0],f[0]] and close(aa[0],b[1],.51) and close(aa[1],f[1],.51) and close(num(row[4]),pct(b[2],f[2]),.050001))
for row in table('supplement',7):
 cp='CP27' if row[0]=='扩展' else 'CP28';mode={'原网格':'original_nominal','半网格':'half_nominal','半网格球面权重':'half_spherical'}[row[1]];g=bd[bd.cp==cp];ar=areas[mode];b=agg(g,'2026-02-01','2026-02-27',ar);f=agg(g,'2026-03-01','2026-03-27',ar);ck('supp7_'+cp+'_'+mode,close(num(row[2]),b[2],.00000051) and close(num(row[3]),f[2],.00000051) and close(num(row[4]),pct(b[2],f[2]),.00051))
inv=pd.read_csv(r/'results/completed_raw/raw_input_inventory.csv');ck('raw_inventory_228_names',len(inv)==228 and inv.file.nunique()==228 and all(v==114 for v in inv.groupby('kind').size()))
info={'checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'summary_statistics':stat,'raw_csv_reread':False,'raw_sha256_complete':bool(inv.sha256.notna().all()),'raw_total_gib':inv.bytes.sum()/1024**3}
(out/'current_data_validation.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:info[k] for k in ['passed','total','summary_statistics','raw_csv_reread','raw_sha256_complete','raw_total_gib']},ensure_ascii=False));print(json.dumps([x for x in checks if not x['pass']],ensure_ascii=False));sys.exit(0 if all(x['pass'] for x in checks) else 1)
