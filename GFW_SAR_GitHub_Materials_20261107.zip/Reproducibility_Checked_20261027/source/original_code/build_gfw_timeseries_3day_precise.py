import csv
import json
import math
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

DATA_DIR = Path("raw_csv")
START = datetime(2026, 2, 20, tzinfo=timezone.utc)
END = datetime(2026, 6, 30, tzinfo=timezone.utc)
BIN_DAYS = int(os.environ.get("GFW_BIN_DAYS", "3"))
OUT = Path("original_run") / f"gfw_27_regions_{BIN_DAYS}day_precise.json"

def rect(w, s, e, n):
    return [(w,s),(e,s),(e,n),(w,n),(w,s)]

REGIONS = {
  1:("霍尔木兹海峡",[(55.25,26.15),(55.65,26.85),(56.10,27.25),(56.85,27.35),(57.55,26.70),(57.35,26.05),(56.55,25.65),(55.65,25.55),(55.25,26.15)]),
  2:("曼德海峡",rect(43.15,12.35,43.65,12.85)),
  3:("博斯普鲁斯海峡",[(29.02,41.26),(29.10,41.27),(29.17,41.23),(29.15,41.17),(29.12,41.11),(29.10,41.06),(29.06,41.02),(29.02,40.99),(28.97,40.99),(28.98,41.03),(28.99,41.08),(29.00,41.13),(28.98,41.19),(29.02,41.26)]),
  4:("达达尼尔海峡",[(25.98,40.07),(26.12,40.14),(26.28,40.20),(26.43,40.27),(26.59,40.38),(26.76,40.52),(26.98,40.60),(27.18,40.50),(27.00,40.35),(26.82,40.27),(26.63,40.18),(26.45,40.09),(26.28,40.00),(26.12,39.90),(25.98,40.07)]),
  5:("直布罗陀海峡",[(-6.05,36.20),(-5.34,36.12),(-5.27,35.90),(-5.93,35.78),(-6.05,36.20)]),
  6:("多佛尔海峡",rect(0.70,50.70,2.25,51.38)),
  7:("厄勒/松德海峡",[(11.95,56.12),(12.25,56.28),(12.55,56.34),(12.82,56.15),(12.78,56.02),(12.95,55.82),(13.13,55.60),(13.20,55.38),(12.95,55.22),(12.45,55.20),(12.05,55.30),(11.85,55.50),(12.10,55.62),(12.32,55.70),(12.45,55.82),(12.52,55.98),(12.35,56.08),(11.95,56.12)]),
  8:("台湾海峡",[(119.55,25.75),(121.60,25.30),(121.20,24.70),(120.95,23.90),(120.75,22.80),(120.72,21.95),(117.10,23.45),(119.55,25.75)]),
  9:("吕宋海峡",[(119.20,21.70),(120.80,22.35),(122.70,22.10),(124.20,20.80),(123.80,19.10),(122.20,18.05),(120.10,18.40),(119.20,21.70)]),
 10:("朝鲜/韩国海峡",[(127.75,34.15),(128.25,34.85),(129.20,35.35),(130.25,35.40),(131.10,34.80),(130.85,34.05),(130.20,33.35),(129.35,33.25),(128.30,33.45),(127.75,34.15)]),
 11:("津轻海峡",[(139.50,41.30),(139.90,41.68),(140.25,41.76),(140.70,41.88),(141.25,41.98),(141.78,41.78),(141.90,41.52),(141.35,41.38),(140.85,41.33),(140.35,41.24),(139.85,41.18),(139.50,41.30)]),
 12:("渤海海峡",[(120.25,37.95),(120.65,38.35),(121.10,38.85),(121.65,38.75),(122.20,38.25),(121.95,37.75),(121.10,37.55),(120.45,37.70),(120.25,37.95)]),
 13:("马六甲海峡",[(98.3000,7.7500),(99.20,7.00),(99.85,6.25),(100.30,5.50),(100.80,4.60),(101.25,3.60),(101.80,2.65),(102.25,2.25),(102.65,2.00),(103.05,1.65),(103.5167,1.2667),(103.3500,1.1917),(103.3917,1.1667),(102.9667,1.2200),(102.20,1.45),(101.45,1.78),(100.60,2.30),(99.70,3.15),(98.70,3.95),(97.60,4.75),(96.40,5.35),(95.4333,5.6667),(98.3000,7.7500)]),
 14:("新加坡海峡",[(103.5167,1.2667),(103.6200,1.2850),(103.7400,1.3000),(103.8500,1.3150),(103.9800,1.3200),(104.1200,1.3500),(104.2833,1.3667),(104.4100,1.3300),(104.5833,1.2250),(104.4500,1.1700),(104.2000,1.1200),(103.9800,1.1000),(103.7917,1.1083),(103.6000,1.1100),(103.3917,1.1667),(103.3500,1.1917),(103.5167,1.2667)]),
 15:("巽他海峡",[(104.45,-6.12),(104.85,-5.85),(105.30,-5.58),(105.90,-5.55),(106.35,-5.70),(106.25,-6.02),(105.95,-6.28),(105.65,-6.48),(105.35,-6.72),(104.90,-6.88),(104.62,-6.55),(104.45,-6.12)]),
 16:("龙目海峡",[(115.35,-8.05),(115.75,-7.82),(116.25,-7.90),(116.30,-8.25),(116.18,-8.65),(116.05,-9.05),(115.55,-8.95),(115.42,-8.65),(115.30,-8.30),(115.35,-8.05)]),
 17:("望加锡海峡",[(116.80,1.70),(120.10,1.40),(119.75,-0.60),(119.35,-2.60),(119.35,-5.40),(117.20,-5.90),(116.30,-3.80),(116.20,-0.80),(116.80,1.70)]),
 18:("托雷斯海峡",[(141.10,-9.35),(141.85,-8.75),(142.80,-8.60),(143.80,-8.80),(145.05,-9.25),(144.80,-10.10),(143.80,-10.55),(142.70,-10.75),(141.45,-10.95),(141.10,-9.35)]),
 19:("巴拿马运河",None),
 20:("佛罗里达海峡",rect(-82.80,23.00,-79.50,25.00)),
 21:("尤卡坦海峡",[(-88.05,21.55),(-87.55,22.45),(-86.30,22.95),(-84.85,23.05),(-84.40,22.25),(-84.75,21.35),(-86.10,20.60),(-87.45,20.45),(-88.05,21.55)]),
 22:("向风海峡",rect(-75.20,19.10,-72.70,20.88)),
 23:("莫纳海峡",[(-69.00,18.85),(-68.30,19.15),(-67.35,19.05),(-66.75,18.70),(-66.85,17.95),(-67.45,17.65),(-68.35,17.75),(-68.95,18.25),(-69.00,18.85)]),
 24:("麦哲伦海峡",[(-72.85,-54.15),(-72.30,-53.70),(-71.70,-53.20),(-71.10,-52.75),(-70.60,-52.25),(-70.20,-51.85),(-69.00,-51.85),(-67.80,-52.00),(-67.45,-52.45),(-67.95,-52.95),(-68.60,-53.40),(-69.40,-53.85),(-70.40,-54.05),(-71.30,-54.15),(-72.10,-54.20),(-72.85,-54.15)]),
 25:("合恩角/德雷克北部",rect(-71.50,-57.50,-65.00,-55.32)),
 26:("莫桑比克海峡",[(39.80,-10.00),(44.80,-10.20),(48.80,-13.20),(47.80,-17.20),(46.20,-21.50),(44.00,-25.80),(36.00,-27.20),(33.80,-24.20),(34.10,-20.80),(34.90,-17.20),(36.10,-13.50),(37.80,-10.80),(39.80,-10.00)]),
 27:("好望角航运区",rect(14.00,-40.00,32.00,-29.00)),
}

PANAMA_LINE=[(-79.90,9.36),(-79.91,9.30),(-79.90,9.23),(-79.84,9.20),(-79.78,9.17),(-79.72,9.13),(-79.68,9.08),(-79.65,9.03),(-79.61,8.99),(-79.59,8.95),(-79.57,8.91)]

def point_in_polygon(x, y, poly):
    inside=False
    j=len(poly)-1
    for i in range(len(poly)):
        xi,yi=poly[i]; xj,yj=poly[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi)+xi:
            inside=not inside
        j=i
    return inside

def segment_distance_km(lon,lat,a,b):
    mean=math.radians((lat+a[1]+b[1])/3)
    kx=111.32*math.cos(mean); ky=110.57
    px,py=lon*kx,lat*ky; ax,ay=a[0]*kx,a[1]*ky; bx,by=b[0]*kx,b[1]*ky
    dx,dy=bx-ax,by-ay
    t=0 if dx==dy==0 else max(0,min(1,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy)))
    return math.hypot(px-(ax+t*dx),py-(ay+t*dy))

def in_region(rid,lon,lat,poly):
    if rid==19:
        return min(segment_distance_km(lon,lat,PANAMA_LINE[i],PANAMA_LINE[i+1]) for i in range(len(PANAMA_LINE)-1)) <= 6.0
    return point_in_polygon(lon,lat,poly)

def bounds(rid,poly):
    pts=PANAMA_LINE if rid==19 else poly
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    pad=0.10 if rid==19 else 0
    return min(xs)-pad,min(ys)-pad,max(xs)+pad,max(ys)+pad

FILES=[DATA_DIR/'sar_vessel_detections_pipev3_202602.csv']+[DATA_DIR/f'sar_vessel_detections_pipev4_20260{m}.csv' for m in range(3,7)]
bin_count=math.ceil((END-START).days/BIN_DAYS)
starts=[START+timedelta(days=BIN_DAYS*i) for i in range(bin_count)]
stats={rid:{'cp':f'CP{rid:02d}','name':name,'geometry_type':'line_buffer_6km' if rid==19 else 'precise_polygon','bbox':bounds(rid,poly),'counts':[0]*bin_count,'matched':[0]*bin_count,'unmatched':[0]*bin_count,'fishing':[0]*bin_count,'scenes':set()} for rid,(name,poly) in REGIONS.items()}

rows_read=0
for file in FILES:
    print('reading',file.name,flush=True)
    with file.open('r',encoding='utf-8',newline='') as f:
        for row in csv.DictReader(f):
            rows_read+=1
            ts=datetime.strptime(row['timestamp'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
            if not START<=ts<END: continue
            lat=float(row['lat']); lon=float(row['lon']); bi=(ts-START).days//BIN_DAYS
            category=(row.get('matched_category') or '').strip().lower()
            score=float(row['fishing_score']) if row.get('fishing_score') else None
            for rid,(name,poly) in REGIONS.items():
                w,s,e,n=stats[rid]['bbox']
                if w<=lon<=e and s<=lat<=n and in_region(rid,lon,lat,poly):
                    q=stats[rid]; q['counts'][bi]+=1; q['scenes'].add(row['scene_id'])
                    if category=='unmatched': q['unmatched'][bi]+=1
                    else: q['matched'][bi]+=1
                    if score is not None and score>=0.9: q['fishing'][bi]+=1

records=[]
for rid in range(1,28):
    q=stats[rid]; counts=q['counts']; total=sum(counts)
    peak=max(range(bin_count),key=lambda i:counts[i])
    records.append({
      'cp':q['cp'],'name':q['name'],'geometry_type':q['geometry_type'],'bbox':[round(x,4) for x in q['bbox']],
      'bin_starts':[d.strftime('%Y-%m-%d') for d in starts],
      'counts':counts,'matched_counts':q['matched'],'unmatched_counts':q['unmatched'],'likely_fishing_counts':q['fishing'],
      'total':total,'matched':sum(q['matched']),'unmatched':sum(q['unmatched']),'likely_fishing':sum(q['fishing']),
      'scene_count_with_detection':len(q['scenes']),'peak_bin_index':peak,'peak_count':counts[peak]
    })

payload={'source':'Global Fishing Watch SAR vessel detections','files':[x.name for x in FILES],
 'start':START.strftime('%Y-%m-%d'),'end_exclusive':END.strftime('%Y-%m-%d'),'bin_days':BIN_DAYS,
 'last_bin_partial':((END-START).days % BIN_DAYS != 0),'aoi_method':'PRECISE_AOI_BY_REGION supplied by user; CP19 line buffered 6 km',
 'rows_read':rows_read,'regions':records}
OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rows_read':rows_read,'total_region_hits':sum(r['total'] for r in records),'top5':[(r['cp'],r['name'],r['total']) for r in sorted(records,key=lambda x:x['total'],reverse=True)[:5]]},ensure_ascii=False),flush=True)
