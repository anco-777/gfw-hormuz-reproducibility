from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


WORKSPACE = Path("original_run")
DATA_DIR = Path("raw_csv")
OUTPUT_DIR = WORKSPACE / "outputs"
MONTHLY_CSV = OUTPUT_DIR / "GFW_全球SAR检测_AIS未匹配占比_月度_2017-2026.csv"
ANNUAL_CSV = OUTPUT_DIR / "GFW_全球SAR检测_AIS未匹配占比_年度_2017-2026.csv"
SUMMARY_JSON = OUTPUT_DIR / "GFW_全球SAR检测_AIS未匹配占比_趋势摘要.json"
FIGURE = OUTPUT_DIR / "GFW_全球SAR检测_AIS未匹配占比_月度趋势_2017-2026.png"


def choose_monthly_files() -> list[Path]:
    """Choose exactly one complete/canonical file per calendar month."""
    candidates: dict[str, tuple[int, Path]] = {}
    pattern = re.compile(r"_(\d{6})(\d{2})?\.csv$")
    for path in DATA_DIR.glob("sar_vessel_detections_*.csv"):
        match = pattern.search(path.name)
        if not match:
            continue
        ym, suffix = match.group(1), match.group(2)
        if not ("201701" <= ym <= "202606"):
            continue
        score = 400 if "pipev4" in path.name else 300 if "pipev3" in path.name else 200
        score += 20 if suffix is None else 0
        # This dated file includes June 29 and supersedes the shorter June snapshot.
        if path.name.endswith("_20260629.csv"):
            score += 100
        if ym not in candidates or score > candidates[ym][0]:
            candidates[ym] = (score, path)

    expected = [
        f"{year}{month:02d}"
        for year in range(2017, 2027)
        for month in range(1, 13)
        if f"{year}{month:02d}" <= "202606"
    ]
    missing = [ym for ym in expected if ym not in candidates]
    if missing:
        raise RuntimeError(f"Missing monthly files: {missing}")
    return [candidates[ym][1] for ym in expected]


def pipeline_label(path: Path) -> str:
    if "pipev4" in path.name:
        return "v4"
    if "pipev3" in path.name:
        return "v3"
    return "v20231026"


def ols_slope_pp_per_year(dates: pd.Series, rates: pd.Series) -> float:
    x = (dates - dates.min()).dt.days.to_numpy(dtype=float) / 365.2425
    y = rates.to_numpy(dtype=float) * 100.0
    return float(np.polyfit(x, y, 1)[0]) if len(x) >= 2 else float("nan")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    files = choose_monthly_files()
    monthly_rows: list[dict] = []

    usecols = ["timestamp", "mmsi", "matching_score", "matched_category"]
    for index, path in enumerate(files, 1):
        counts = defaultdict(int)
        min_time = None
        max_time = None
        for chunk in pd.read_csv(path, usecols=usecols, chunksize=300_000, low_memory=False):
            timestamps = pd.to_datetime(chunk["timestamp"], utc=True, errors="coerce")
            valid_time = timestamps.notna()
            chunk = chunk.loc[valid_time].copy()
            timestamps = timestamps.loc[valid_time]
            if chunk.empty:
                continue
            this_min = timestamps.min()
            this_max = timestamps.max()
            min_time = this_min if min_time is None else min(min_time, this_min)
            max_time = this_max if max_time is None else max(max_time, this_max)

            category = chunk["matched_category"].fillna("").astype(str).str.strip().str.lower()
            is_unmatched = category.eq("unmatched")
            is_unknown = category.eq("") | category.eq("na") | category.eq("nan")
            mmsi_present = chunk["mmsi"].notna() & chunk["mmsi"].astype(str).str.strip().ne("")

            counts["total"] += len(chunk)
            counts["unmatched"] += int(is_unmatched.sum())
            counts["matched"] += int((~is_unmatched & ~is_unknown).sum())
            counts["unknown_status"] += int(is_unknown.sum())
            counts["unmatched_with_mmsi"] += int((is_unmatched & mmsi_present).sum())
            counts["unmatched_without_mmsi"] += int((is_unmatched & ~mmsi_present).sum())

        ym_match = re.search(r"_(\d{6})", path.name)
        assert ym_match
        ym = ym_match.group(1)
        total = counts["total"]
        monthly_rows.append(
            {
                "month": f"{ym[:4]}-{ym[4:]}",
                "pipeline": pipeline_label(path),
                "source_file": path.name,
                "first_timestamp_utc": min_time.isoformat() if min_time is not None else "",
                "last_timestamp_utc": max_time.isoformat() if max_time is not None else "",
                "total_sar_detections": total,
                "ais_unmatched_detections": counts["unmatched"],
                "ais_matched_detections": counts["matched"],
                "unknown_match_status": counts["unknown_status"],
                "unmatched_share": counts["unmatched"] / total if total else None,
                "unmatched_with_mmsi": counts["unmatched_with_mmsi"],
                "unmatched_without_mmsi": counts["unmatched_without_mmsi"],
            }
        )
        print(f"[{index:03d}/{len(files)}] {path.name}: {total:,} rows", flush=True)

    monthly = pd.DataFrame(monthly_rows)
    monthly["date"] = pd.to_datetime(monthly["month"] + "-01")
    monthly["unmatched_share_3m_trailing"] = monthly["ais_unmatched_detections"].rolling(3).sum() / monthly[
        "total_sar_detections"
    ].rolling(3).sum()

    annual = (
        monthly.assign(year=monthly["date"].dt.year)
        .groupby("year", as_index=False)
        .agg(
            months=("month", "count"),
            total_sar_detections=("total_sar_detections", "sum"),
            ais_unmatched_detections=("ais_unmatched_detections", "sum"),
            ais_matched_detections=("ais_matched_detections", "sum"),
            unknown_match_status=("unknown_match_status", "sum"),
            unmatched_with_mmsi=("unmatched_with_mmsi", "sum"),
            unmatched_without_mmsi=("unmatched_without_mmsi", "sum"),
        )
    )
    annual["unmatched_share"] = annual["ais_unmatched_detections"] / annual["total_sar_detections"]
    annual["year_over_year_change_pp"] = annual["unmatched_share"].diff() * 100.0
    annual["period_note"] = np.where(annual["year"].eq(2026), "Jan-Jun 29 only", "Full year")

    columns = [
        "month",
        "pipeline",
        "source_file",
        "first_timestamp_utc",
        "last_timestamp_utc",
        "total_sar_detections",
        "ais_unmatched_detections",
        "ais_matched_detections",
        "unknown_match_status",
        "unmatched_share",
        "unmatched_share_3m_trailing",
        "unmatched_with_mmsi",
        "unmatched_without_mmsi",
    ]
    monthly[columns].to_csv(MONTHLY_CSV, index=False, encoding="utf-8-sig", quoting=csv.QUOTE_MINIMAL)
    annual.to_csv(ANNUAL_CSV, index=False, encoding="utf-8-sig", quoting=csv.QUOTE_MINIMAL)

    version_stats = []
    for version, group in monthly.groupby("pipeline", sort=False):
        total = int(group["total_sar_detections"].sum())
        unmatched = int(group["ais_unmatched_detections"].sum())
        version_stats.append(
            {
                "pipeline": version,
                "start_month": group["month"].min(),
                "end_month": group["month"].max(),
                "months": len(group),
                "total": total,
                "unmatched": unmatched,
                "unmatched_share": unmatched / total,
                "monthly_ols_slope_percentage_points_per_year": ols_slope_pp_per_year(
                    group["date"], group["unmatched_share"]
                ),
            }
        )

    full_total = int(monthly["total_sar_detections"].sum())
    full_unmatched = int(monthly["ais_unmatched_detections"].sum())
    summary = {
        "definition": "matched_category normalized to lowercase equals 'unmatched' divided by all valid-timestamp SAR detection rows",
        "scope": "global; no spatial filter",
        "start_month": monthly["month"].min(),
        "end_month": monthly["month"].max(),
        "selected_monthly_files": len(files),
        "total_sar_detections": full_total,
        "ais_unmatched_detections": full_unmatched,
        "overall_unmatched_share": full_unmatched / full_total,
        "unknown_match_status": int(monthly["unknown_match_status"].sum()),
        "full_series_monthly_ols_slope_percentage_points_per_year": ols_slope_pp_per_year(
            monthly["date"], monthly["unmatched_share"]
        ),
        "pipeline_segments": version_stats,
        "annual": annual.to_dict(orient="records"),
        "excluded_overlapping_snapshots": [
            "sar_vessel_detections_pipev20231026_20240824.csv",
            "sar_vessel_detections_pipev20231026_20241106.csv",
            "sar_vessel_detections_pipev4_202606.csv",
        ],
        "notes": [
            "2026 is partial through 2026-06-29.",
            "The ratio is detection-event based, not a unique-vessel ratio.",
            "Rows labelled unmatched may still contain an MMSI candidate; matched_category is used as the authoritative status.",
            "Changes in geographic SAR sampling can change the global mixture even though numerator and denominator use the same scenes.",
            "Pipeline/version boundaries mean the full-period linear slope is descriptive, not a pure behavioral trend.",
        ],
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    print(f"monthly_csv={MONTHLY_CSV}", flush=True)
    print(f"annual_csv={ANNUAL_CSV}", flush=True)


if __name__ == "__main__":
    main()
