from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path("original_run")
DATA = Path("raw_csv")
OUT_JSON = ROOT / "work" / "gfw_27_regions_monthly_total_unmatched_2026.json"
OUT_CSV = ROOT / "outputs" / "GFW_27区域_月度SAR检测总数与AIS未匹配占比_2026.csv"


def load_regions():
    source = (ROOT / "work" / "build_gfw_timeseries_3day_precise.py").read_text(encoding="utf-8")
    namespace = {}
    exec(source.split("FILES=")[0], namespace)
    return namespace["REGIONS"], namespace["bounds"], namespace["in_region"]


def selected_files():
    return [
        DATA / "sar_vessel_detections_pipev3_202601.csv",
        DATA / "sar_vessel_detections_pipev3_202602.csv",
        DATA / "sar_vessel_detections_pipev4_202603.csv",
        DATA / "sar_vessel_detections_pipev4_202604.csv",
        DATA / "sar_vessel_detections_pipev4_202605.csv",
        DATA / "sar_vessel_detections_pipev4_20260629.csv",
    ]


def main():
    regions, bounds, in_region = load_regions()
    region_meta = {}
    for rid, (name, poly) in regions.items():
        region_meta[rid] = {
            "cp": f"CP{rid:02d}",
            "name": name,
            "bbox": bounds(rid, poly),
            "poly": poly,
        }

    months = [f"2026-{m:02d}" for m in range(1, 7)]
    stats = {rid: {month: {"total": 0, "unmatched": 0, "unknown": 0} for month in months} for rid in regions}
    file_rows = []

    for file in selected_files():
        month = "-".join(file.stem.split("_")[-1][:6][i:i+2] if i else file.stem.split("_")[-1][:4] for i in [0, 4])
        # The filename suffix may include a day (20260629); only YYYY-MM is used.
        token = file.stem.split("_")[-1]
        month = f"{token[:4]}-{token[4:6]}"
        rows = 0
        with file.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                rows += 1
                try:
                    lon = float(row["lon"])
                    lat = float(row["lat"])
                except (TypeError, ValueError, KeyError):
                    continue
                category = (row.get("matched_category") or "").strip().lower()
                for rid, meta in region_meta.items():
                    w, s, e, n = meta["bbox"]
                    if not (w <= lon <= e and s <= lat <= n):
                        continue
                    if not in_region(rid, lon, lat, meta["poly"]):
                        continue
                    cell = stats[rid][month]
                    cell["total"] += 1
                    if category == "unmatched":
                        cell["unmatched"] += 1
                    elif category in ("", "na", "nan"):
                        cell["unknown"] += 1
        file_rows.append({"file": file.name, "month": month, "rows": rows})
        print(f"{file.name}: {rows:,} rows", flush=True)

    records = []
    for rid in sorted(regions):
        meta = region_meta[rid]
        monthly = []
        for month in months:
            cell = stats[rid][month]
            total = cell["total"]
            monthly.append({
                "month": month,
                "total_sar_detections": total,
                "ais_unmatched_detections": cell["unmatched"],
                "unknown_match_status": cell["unknown"],
                "ais_unmatched_share": cell["unmatched"] / total if total else None,
            })
        records.append({
            "cp": meta["cp"],
            "name": meta["name"],
            "geometry_type": "line_buffer_6km" if rid == 19 else "precise_polygon",
            "bbox": [round(v, 4) for v in meta["bbox"]],
            "monthly": monthly,
        })

    payload = {
        "source": "Global Fishing Watch Sentinel-1 SAR vessel detections",
        "scope": "User-provided 27 precise regions; CP19 uses a 6 km canal-line buffer",
        "period": "2026-01 through 2026-06-29",
        "metric_total": "SAR detection-event rows inside each region; not unique vessels",
        "metric_unmatched": "matched_category normalized to lowercase equals unmatched / all regional SAR detection rows",
        "event_date": "2026-02-28",
        "files": file_rows,
        "regions": records,
    }
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "cp", "name", "month", "total_sar_detections", "ais_unmatched_detections",
            "unknown_match_status", "ais_unmatched_share",
        ])
        writer.writeheader()
        for region in records:
            for month in region["monthly"]:
                writer.writerow({"cp": region["cp"], "name": region["name"], **month})

    print(json.dumps({"json": str(OUT_JSON), "csv": str(OUT_CSV), "regions": len(records)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
