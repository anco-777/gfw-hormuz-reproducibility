import csv
import json
from datetime import date, timedelta
from pathlib import Path

import numpy as np


ROOT = Path("original_run")
EVENT_FILE = ROOT / "outputs" / "GFW_27区域_霍尔木兹事件前后对比_20260222-20260327.json"
LONG_FILE = ROOT / "work" / "gfw_27_regions_2017_2026_corrected_continuous_14day.json"
OUT = ROOT / "outputs" / "GFW_27区域_事件变化与历史季节波动对比.csv"


def rate(counts, areas, indices):
    count = sum(counts[i] for i in indices)
    area = sum(areas[i] for i in indices)
    return count / area * 1000 if area > 0 else None


def change(before, after):
    if before is None or after is None or before <= 0:
        return None
    return (after / before - 1) * 100


event = json.loads(EVENT_FILE.read_text(encoding="utf-8"))
long = json.loads(LONG_FILE.read_text(encoding="utf-8"))
long_by_cp = {r["cp"]: r for r in long["regions"]}
rows = []

for current in event["regions"]:
    history = long_by_cp[current["cp"]]
    starts = [date.fromisoformat(x) for x in history["bin_starts"]]
    midpoints = [x + timedelta(days=6.5) for x in starts]
    annual_changes = []
    for year in range(2017, 2026):
        pre = [i for i, d in enumerate(midpoints) if d.year == year and d.month == 2 and d.day <= 27]
        post = [i for i, d in enumerate(midpoints) if d.year == year and d.month == 3 and d.day <= 27]
        c = change(
            rate(history["counts"], history["coverage_km2_obs"], pre),
            rate(history["counts"], history["coverage_km2_obs"], post),
        )
        if c is not None and np.isfinite(c):
            annual_changes.append(c)
    event_change = current["change_pct_matched_27d"]
    arr = np.asarray(annual_changes, dtype=float)
    median = float(np.median(arr)) if len(arr) else None
    mad = float(np.median(np.abs(arr - median))) if len(arr) else None
    robust_z = (event_change - median) / (1.4826 * mad) if mad and event_change is not None else None
    percentile = float((np.sum(arr <= event_change) + 0.5) / (len(arr) + 1) * 100) if len(arr) and event_change is not None else None
    outside = "below_history" if len(arr) and event_change < arr.min() else "above_history" if len(arr) and event_change > arr.max() else "within_history"
    rows.append({
        "cp": current["cp"],
        "name": current["name"],
        "event_change_pct": event_change,
        "historical_feb_mar_median_pct": round(median, 3) if median is not None else None,
        "historical_min_pct": round(float(arr.min()), 3) if len(arr) else None,
        "historical_max_pct": round(float(arr.max()), 3) if len(arr) else None,
        "event_minus_historical_median_pp": round(event_change - median, 3) if median is not None and event_change is not None else None,
        "robust_z": round(robust_z, 3) if robust_z is not None and np.isfinite(robust_z) else None,
        "event_percentile": round(percentile, 1) if percentile is not None else None,
        "historical_position": outside,
        "historical_years_valid": len(arr),
        "coverage_limited": current["matched_pre_equivalent_full_coverages"] < 1 or current["matched_post_equivalent_full_coverages"] < 1,
        "pre_count": current["matched_pre_27d"]["count"],
        "post_count": current["matched_post_27d"]["count"],
    })

with OUT.open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

print(json.dumps(rows, ensure_ascii=False, indent=2))
