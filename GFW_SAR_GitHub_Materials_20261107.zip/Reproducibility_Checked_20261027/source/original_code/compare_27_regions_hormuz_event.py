import csv
import hashlib
import importlib.util
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path("original_run")
DATA = Path("raw_csv")
START = datetime(2026, 2, 1, tzinfo=timezone.utc)
END = datetime(2026, 3, 28, tzinfo=timezone.utc)  # exclusive; through 2026-03-27
EVENT = datetime(2026, 2, 28, tzinfo=timezone.utc)
PAPER_PRE_START = datetime(2026, 2, 22, tzinfo=timezone.utc)
MATCHED_PRE_START = datetime(2026, 2, 1, tzinfo=timezone.utc)
MATCHED_PRE_END = datetime(2026, 2, 28, tzinfo=timezone.utc)
MATCHED_POST_START = datetime(2026, 3, 1, tzinfo=timezone.utc)
DAY_COUNT = (END - START).days
OUT_JSON = ROOT / "outputs" / "GFW_27区域_霍尔木兹事件前后对比_20260222-20260327.json"
OUT_CSV = ROOT / "outputs" / "GFW_27区域_霍尔木兹事件前后对比_20260222-20260327.csv"
csv.field_size_limit(2_147_483_647)


def load_helpers():
    source = ROOT / "work" / "build_corrected_continuous_14day.py"
    spec = importlib.util.spec_from_file_location("gfw14", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


H = load_helpers()
REGIONS = H.REGIONS
GRIDS = {rid: H.make_grid(rid, poly) for rid, (_, poly) in REGIONS.items()}


def detection_files():
    return [
        DATA / "sar_vessel_detections_pipev3_202602.csv",
        DATA / "sar_vessel_detections_pipev4_202603.csv",
    ]


def footprint_files():
    return [
        DATA / "sar_detections_footprints_202602.csv",
        DATA / "sar_detections_footprints_202603.csv",
    ]


def build_daily_counts():
    counts = {rid: np.zeros(DAY_COUNT, dtype=np.int64) for rid in REGIONS}
    rows_read = 0
    for file in detection_files():
        for chunk in pd.read_csv(file, usecols=["timestamp", "lat", "lon"], chunksize=300_000):
            rows_read += len(chunk)
            ts = pd.to_datetime(chunk["timestamp"], utc=True, errors="coerce")
            keep = ts.notna() & (ts >= START) & (ts < END)
            if not keep.any():
                continue
            lon = chunk.loc[keep, "lon"].to_numpy(float)
            lat = chunk.loc[keep, "lat"].to_numpy(float)
            days = ((ts.loc[keep] - START).dt.total_seconds() // 86400).astype(int).to_numpy()
            for rid, (_, poly) in REGIONS.items():
                w, s, e, n = H.region_bbox(rid, poly)
                pre = (lon >= w) & (lon <= e) & (lat >= s) & (lat <= n)
                if not pre.any():
                    continue
                hit = H.points_near_panama(lon[pre], lat[pre]) if rid == 19 else H.points_in_polygon(lon[pre], lat[pre], poly)
                if hit.any():
                    np.add.at(counts[rid], days[pre][hit], 1)
        print(f"detections {file.name}: rows={rows_read:,}", flush=True)
    return counts, rows_read


def build_daily_coverage():
    coverage = {rid: np.zeros(DAY_COUNT, dtype=float) for rid in REGIONS}
    scene_rows = {rid: np.zeros(DAY_COUNT, dtype=np.int64) for rid in REGIONS}
    rows_read = 0
    duplicates = 0
    for file in footprint_files():
        seen = set()
        selected_rows = 0
        with file.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                rows_read += 1
                date_text = row.get("date")
                if not date_text or not ("2026-02-01" <= date_text <= "2026-03-27"):
                    continue
                dt = datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                if not START <= dt < END:
                    continue
                wkt = row.get("footprint_wkt")
                if not wkt:
                    continue
                key = (row["scene_id"], hashlib.blake2b(wkt.encode("utf-8"), digest_size=12).digest())
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                selected_rows += 1
                coords = H.flat_coords(wkt)
                if coords.size == 0:
                    continue
                day = (dt - START).days
                minx, miny = coords.min(axis=0)
                maxx, maxy = coords.max(axis=0)
                for rid, grid in GRIDS.items():
                    w, s, e, n = grid["bbox"]
                    if maxx < w or minx > e or maxy < s or miny > n:
                        continue
                    area = H.covered_area_grid(wkt, grid)
                    if area > 0:
                        coverage[rid][day] += area
                        scene_rows[rid][day] += 1
        print(f"footprints {file.name}: selected={selected_rows:,}, duplicates_total={duplicates:,}", flush=True)
    return coverage, scene_rows, rows_read, duplicates


def aggregate(counts, coverage, first, last_exclusive):
    a = (first - START).days
    b = (last_exclusive - START).days
    count = int(counts[a:b].sum())
    area = float(coverage[a:b].sum())
    return {
        "count": count,
        "coverage_km2_obs": round(area, 3),
        "rate_per_1000_km2": round(count / area * 1000, 6) if area > 0 else None,
        "days": b - a,
    }


def percent_change(before, after):
    if before is None or after is None or before == 0:
        return None
    return round((after / before - 1) * 100, 3)


def main():
    counts, detection_rows = build_daily_counts()
    coverage, scene_rows, footprint_rows, duplicates = build_daily_coverage()
    dates = [(START + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(DAY_COUNT)]
    records = []
    for rid, (name, _) in REGIONS.items():
        # Paper-like windows overlap on the event date, matching the article wording.
        pre = aggregate(counts[rid], coverage[rid], PAPER_PRE_START, EVENT + timedelta(days=1))
        post = aggregate(counts[rid], coverage[rid], EVENT, END)
        # Non-overlap sensitivity check treats 2026-02-28 only as post-event.
        pre_nonoverlap = aggregate(counts[rid], coverage[rid], PAPER_PRE_START, EVENT)
        # Primary global comparison: equal 27-day windows, excluding the event day.
        matched_pre = aggregate(counts[rid], coverage[rid], MATCHED_PRE_START, MATCHED_PRE_END)
        matched_post = aggregate(counts[rid], coverage[rid], MATCHED_POST_START, END)
        aoi_area = GRIDS[rid]["approx_aoi_area_km2"]
        daily_rates = np.divide(
            counts[rid] * 1000.0,
            coverage[rid],
            out=np.full(DAY_COUNT, np.nan),
            where=coverage[rid] > 0,
        )
        records.append({
            "cp": f"CP{rid:02d}",
            "name": name,
            "geometry_type": "line_buffer_6km" if rid == 19 else "precise_polygon",
            "pre_paper_like": pre,
            "post_paper_like": post,
            "change_pct_paper_like": percent_change(pre["rate_per_1000_km2"], post["rate_per_1000_km2"]),
            "pre_nonoverlap": pre_nonoverlap,
            "change_pct_nonoverlap": percent_change(pre_nonoverlap["rate_per_1000_km2"], post["rate_per_1000_km2"]),
            "matched_pre_27d": matched_pre,
            "matched_post_27d": matched_post,
            "change_pct_matched_27d": percent_change(matched_pre["rate_per_1000_km2"], matched_post["rate_per_1000_km2"]),
            "approx_aoi_area_km2": round(float(aoi_area), 3),
            "matched_pre_equivalent_full_coverages": round(matched_pre["coverage_km2_obs"] / aoi_area, 3) if aoi_area else None,
            "matched_post_equivalent_full_coverages": round(matched_post["coverage_km2_obs"] / aoi_area, 3) if aoi_area else None,
            "daily_counts": counts[rid].tolist(),
            "daily_coverage_km2_obs": [round(float(v), 3) for v in coverage[rid]],
            "daily_rates_per_1000_km2": [None if np.isnan(v) else round(float(v), 6) for v in daily_rates],
            "daily_footprint_rows": scene_rows[rid].tolist(),
        })
    payload = {
        "source": "Global Fishing Watch Sentinel-1 SAR vessel detections + detection footprints",
        "analysis": "Hormuz crisis paper-like before/after comparison across the user's 27 regions",
        "event_date": "2026-02-28",
        "pre_paper_like": {"start": "2026-02-22", "end_inclusive": "2026-02-28", "days": 7},
        "post_paper_like": {"start": "2026-02-28", "end_inclusive": "2026-03-27", "days": 28},
        "nonoverlap_pre": {"start": "2026-02-22", "end_inclusive": "2026-02-27", "days": 6},
        "matched_pre_27d": {"start": "2026-02-01", "end_inclusive": "2026-02-27", "days": 27},
        "matched_post_27d": {"start": "2026-03-01", "end_inclusive": "2026-03-27", "days": 27},
        "metric": "SAR detection events / cumulative observed footprint area * 1000",
        "dates": dates,
        "detection_rows_read": detection_rows,
        "footprint_rows_read": footprint_rows,
        "duplicate_footprint_rows_skipped": duplicates,
        "regions": records,
    }
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = [
            "cp", "name", "pre_count", "pre_coverage_km2_obs", "pre_rate_per_1000_km2",
            "post_count", "post_coverage_km2_obs", "post_rate_per_1000_km2",
            "change_pct_paper_like", "change_pct_nonoverlap",
            "matched_pre_count", "matched_pre_coverage_km2_obs", "matched_pre_rate_per_1000_km2",
            "matched_post_count", "matched_post_coverage_km2_obs", "matched_post_rate_per_1000_km2",
            "change_pct_matched_27d", "matched_pre_equivalent_full_coverages", "matched_post_equivalent_full_coverages",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for r in records:
            writer.writerow({
                "cp": r["cp"], "name": r["name"],
                "pre_count": r["pre_paper_like"]["count"],
                "pre_coverage_km2_obs": r["pre_paper_like"]["coverage_km2_obs"],
                "pre_rate_per_1000_km2": r["pre_paper_like"]["rate_per_1000_km2"],
                "post_count": r["post_paper_like"]["count"],
                "post_coverage_km2_obs": r["post_paper_like"]["coverage_km2_obs"],
                "post_rate_per_1000_km2": r["post_paper_like"]["rate_per_1000_km2"],
                "change_pct_paper_like": r["change_pct_paper_like"],
                "change_pct_nonoverlap": r["change_pct_nonoverlap"],
                "matched_pre_count": r["matched_pre_27d"]["count"],
                "matched_pre_coverage_km2_obs": r["matched_pre_27d"]["coverage_km2_obs"],
                "matched_pre_rate_per_1000_km2": r["matched_pre_27d"]["rate_per_1000_km2"],
                "matched_post_count": r["matched_post_27d"]["count"],
                "matched_post_coverage_km2_obs": r["matched_post_27d"]["coverage_km2_obs"],
                "matched_post_rate_per_1000_km2": r["matched_post_27d"]["rate_per_1000_km2"],
                "change_pct_matched_27d": r["change_pct_matched_27d"],
                "matched_pre_equivalent_full_coverages": r["matched_pre_equivalent_full_coverages"],
                "matched_post_equivalent_full_coverages": r["matched_post_equivalent_full_coverages"],
            })
    print(json.dumps({"json": str(OUT_JSON), "csv": str(OUT_CSV), "regions": len(records)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
