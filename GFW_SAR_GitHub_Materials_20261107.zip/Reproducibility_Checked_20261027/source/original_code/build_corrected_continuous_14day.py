import csv
import hashlib
import json
import math
import pickle
import re
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path

import numpy as np
import pandas as pd


WORKSPACE = Path("original_run")
DATA_DIR = Path("raw_csv")
START = datetime(2017, 1, 1, tzinfo=timezone.utc)
END = datetime(2026, 6, 30, tzinfo=timezone.utc)
BIN_DAYS = 14
BIN_COUNT = math.ceil((END - START).days / BIN_DAYS)
OUT = WORKSPACE / "work" / "gfw_27_regions_2017_2026_corrected_continuous_14day.json"
csv.field_size_limit(2_147_483_647)

source = (WORKSPACE / "work" / "build_gfw_timeseries_3day_precise.py").read_text(encoding="utf-8")
ns = {}
exec(source.split("FILES=")[0], ns)
REGIONS = ns["REGIONS"]
PANAMA_LINE = ns["PANAMA_LINE"]

# Bind intermediate caches to the exact research-area definition.  This avoids
# silently reusing results after a polygon (for example CP27) is revised.
REGION_SIGNATURE = hashlib.sha256(
    json.dumps({"regions": REGIONS, "panama_line": PANAMA_LINE}, ensure_ascii=False, sort_keys=True).encode("utf-8")
).hexdigest()[:12]
COUNT_CACHE = WORKSPACE / "work" / f"corrected_continuous_14day_counts_{REGION_SIGNATURE}.pkl"
COVERAGE_CACHE = WORKSPACE / "work" / f"corrected_continuous_14day_coverage_{REGION_SIGNATURE}.pkl"


def point_in_polygon(x, y, poly):
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def points_in_polygon(xs, ys, poly):
    inside = np.zeros(xs.shape, dtype=bool)
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        inside ^= ((yi > ys) != (yj > ys)) & (xs < (xj - xi) * (ys - yi) / ((yj - yi) + 1e-30) + xi)
        j = i
    return inside


def segment_distance_km(lon, lat, a, b):
    mean = np.radians((lat + a[1] + b[1]) / 3)
    kx, ky = 111.32 * np.cos(mean), 110.57
    px, py = lon * kx, lat * ky
    ax, ay = a[0] * kx, a[1] * ky
    bx, by = b[0] * kx, b[1] * ky
    dx, dy = bx - ax, by - ay
    den = dx * dx + dy * dy
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / (den + 1e-30), 0, 1)
    return np.hypot(px - (ax + t * dx), py - (ay + t * dy))


def points_near_panama(xs, ys):
    best = np.full(xs.shape, np.inf)
    for a, b in zip(PANAMA_LINE[:-1], PANAMA_LINE[1:]):
        best = np.minimum(best, segment_distance_km(xs, ys, a, b))
    return best <= 6.0


def region_bbox(rid, poly):
    pts = PANAMA_LINE if rid == 19 else poly
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    pad = 0.07 if rid == 19 else 0.0
    return min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad


def polygon_area_km2(poly):
    lat0 = sum(y for _, y in poly) / len(poly)
    kx, ky = 111.32 * math.cos(math.radians(lat0)), 110.57
    return abs(sum(
        (poly[i][0] * kx) * (poly[i + 1][1] * ky)
        - (poly[i + 1][0] * kx) * (poly[i][1] * ky)
        for i in range(len(poly) - 1)
    )) / 2


def make_grid(rid, poly):
    est_area = 6 * 2 * 60 if rid == 19 else max(1.0, polygon_area_km2(poly))
    spacing = min(5.0, max(0.75, math.sqrt(est_area / 12000.0)))
    w, s, e, n = region_bbox(rid, poly)
    lat0 = (s + n) / 2
    dy = spacing / 110.57
    dx = spacing / (111.32 * max(0.15, math.cos(math.radians(lat0))))
    xv = np.arange(w + dx / 2, e, dx)
    yv = np.arange(s + dy / 2, n, dy)
    xx, yy = np.meshgrid(xv, yv)
    xs, ys = xx.ravel(), yy.ravel()
    mask = points_near_panama(xs, ys) if rid == 19 else points_in_polygon(xs, ys, poly)
    xs, ys = xs[mask], ys[mask]
    order = np.argsort(ys, kind="stable")
    xs, ys = xs[order], ys[order]
    unique_y, starts, counts = np.unique(ys, return_index=True, return_counts=True)
    return {
        "spacing_km": spacing,
        "cell_area_km2": spacing * spacing,
        "xs": xs,
        "ys": ys,
        "unique_y": unique_y,
        "row_starts": starts,
        "row_counts": counts,
        "bbox": (w, s, e, n),
        "approx_aoi_area_km2": float(len(xs) * spacing * spacing),
    }


RING_RE = re.compile(r"\(([^()]*)\)")
TRANS = str.maketrans({"(": " ", ")": " ", ",": " "})


def flat_coords(wkt):
    vals = np.fromstring(wkt[wkt.find("("):].translate(TRANS), sep=" ")
    if vals.size % 2:
        vals = vals[:-1]
    return vals.reshape(-1, 2)


def parse_rings(wkt):
    rings = []
    for match in RING_RE.finditer(wkt):
        vals = np.fromstring(match.group(1).replace(",", " "), sep=" ")
        if vals.size >= 8:
            if vals.size % 2:
                vals = vals[:-1]
            rings.append(vals.reshape(-1, 2))
    return rings


def covered_area_grid(wkt, grid):
    rings = parse_rings(wkt)
    if not rings:
        return 0.0
    total_points = 0
    for y, start, count in zip(grid["unique_y"], grid["row_starts"], grid["row_counts"]):
        crosses = []
        for poly in rings:
            x1, y1 = poly[:-1, 0], poly[:-1, 1]
            x2, y2 = poly[1:, 0], poly[1:, 1]
            take = (y1 > y) != (y2 > y)
            if take.any():
                crosses.append(x1[take] + (y - y1[take]) * (x2[take] - x1[take]) / (y2[take] - y1[take]))
        if crosses:
            cx = np.sort(np.concatenate(crosses))
            rowx = grid["xs"][start:start + count]
            total_points += int((np.searchsorted(cx, rowx, side="right") % 2 == 1).sum())
    return total_points * grid["cell_area_km2"]


def load_file_lists():
    raw = json.loads((WORKSPACE / "work" / "gfw_27_regions_2017_2026_annual_7day.json").read_text(encoding="utf-8"))
    old = json.loads((WORKSPACE / "work" / "gfw_27_regions_2017_2026_coverage_normalized_14day.json").read_text(encoding="utf-8"))
    return [DATA_DIR / name for name in raw["files"]], [DATA_DIR / name for name in old["footprint_files"]]


def build_counts(files):
    if COUNT_CACHE.exists():
        return pickle.loads(COUNT_CACHE.read_bytes())
    counts = {rid: np.zeros(BIN_COUNT, dtype=np.int64) for rid in REGIONS}
    rows_read = 0
    usecols = ["timestamp", "lat", "lon"]
    t0 = time.time()
    for fi, file in enumerate(files, 1):
        for chunk in pd.read_csv(file, usecols=usecols, chunksize=300_000, low_memory=False):
            rows_read += len(chunk)
            ts = pd.to_datetime(chunk["timestamp"], utc=True, errors="coerce")
            keep = ts.notna() & (ts >= START) & (ts < END)
            if not keep.any():
                continue
            selected = chunk.loc[keep, ["lat", "lon"]].copy()
            selected["bin"] = ((ts.loc[keep] - START).dt.total_seconds() // (BIN_DAYS * 86400)).astype(int).to_numpy()
            lon = selected["lon"].to_numpy(float)
            lat = selected["lat"].to_numpy(float)
            bins = selected["bin"].to_numpy(int)
            for rid, (_, poly) in REGIONS.items():
                w, s, e, n = region_bbox(rid, poly)
                pre = (lon >= w) & (lon <= e) & (lat >= s) & (lat <= n)
                if not pre.any():
                    continue
                hit = points_near_panama(lon[pre], lat[pre]) if rid == 19 else points_in_polygon(lon[pre], lat[pre], poly)
                if hit.any():
                    np.add.at(counts[rid], bins[pre][hit], 1)
        print(f"counts [{fi:03d}/{len(files)}] {file.name} rows={rows_read:,} elapsed_min={(time.time()-t0)/60:.1f}", flush=True)
    payload = {"counts": counts, "rows_read": rows_read}
    COUNT_CACHE.write_bytes(pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL))
    return payload


WORKER_GRIDS = None


def init_coverage_worker():
    global WORKER_GRIDS
    WORKER_GRIDS = {rid: make_grid(rid, poly) for rid, (_, poly) in REGIONS.items()}


def process_footprint_file(file_text):
    file = Path(file_text)
    local_coverage = {rid: np.zeros(BIN_COUNT, dtype=float) for rid in REGIONS}
    local_scene_rows = {rid: np.zeros(BIN_COUNT, dtype=np.int64) for rid in REGIONS}
    rows_read = 0
    duplicates = 0
    seen = set()
    with file.open("r", encoding="utf-8", newline="") as handle:
        prefix = handle.read(96)
        handle.seek(0)
        fields = ["scene_id", "date", "start_time", "end_time", "footprint_wkt"]
        reader = csv.DictReader(handle) if prefix.startswith("scene_id,date,") else csv.DictReader(handle, fieldnames=fields)
        for row in reader:
            rows_read += 1
            wkt = row.get("footprint_wkt")
            if not wkt:
                continue
            key = (row["scene_id"], hashlib.blake2b(wkt.encode("utf-8"), digest_size=12).digest())
            if key in seen:
                duplicates += 1
                continue
            seen.add(key)
            coords = flat_coords(wkt)
            if coords.size == 0:
                continue
            dt = datetime.strptime(row["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            if not START <= dt < END:
                continue
            bi = (dt - START).days // BIN_DAYS
            minx, miny = coords.min(axis=0)
            maxx, maxy = coords.max(axis=0)
            for rid, grid in WORKER_GRIDS.items():
                w, s, e, n = grid["bbox"]
                if maxx < w or minx > e or maxy < s or miny > n:
                    continue
                area = covered_area_grid(wkt, grid)
                if area > 0:
                    local_coverage[rid][bi] += area
                    local_scene_rows[rid][bi] += 1
    return file.name, rows_read, duplicates, local_coverage, local_scene_rows


def build_coverage(files, grids):
    coverage = {rid: np.zeros(BIN_COUNT, dtype=float) for rid in REGIONS}
    scene_rows = {rid: np.zeros(BIN_COUNT, dtype=np.int64) for rid in REGIONS}
    start_index = 0
    rows_read = 0
    duplicates_skipped = 0
    if COVERAGE_CACHE.exists():
        state = pickle.loads(COVERAGE_CACHE.read_bytes())
        start_index = state["next_index"]
        coverage = state["coverage"]
        scene_rows = state["scene_rows"]
        rows_read = state["rows_read"]
        duplicates_skipped = state["duplicates_skipped"]
        print(f"resuming coverage at file {start_index + 1}/{len(files)}", flush=True)
    t0 = time.time()
    remaining = files[start_index:]
    completed = 0
    with ProcessPoolExecutor(max_workers=4, initializer=init_coverage_worker) as pool:
        futures = [pool.submit(process_footprint_file, str(file)) for file in remaining]
        for future in as_completed(futures):
            name, file_rows, file_duplicates, local_coverage, local_scene_rows = future.result()
            rows_read += file_rows
            duplicates_skipped += file_duplicates
            for rid in REGIONS:
                coverage[rid] += local_coverage[rid]
                scene_rows[rid] += local_scene_rows[rid]
            completed += 1
            print(
                f"coverage [{start_index + completed:03d}/{len(files)}] {name} rows={rows_read:,} "
                f"duplicates_file={file_duplicates:,} duplicates_total={duplicates_skipped:,} "
                f"elapsed_min={(time.time()-t0)/60:.1f}", flush=True
            )
    state = {
        "next_index": len(files),
        "coverage": coverage,
        "scene_rows": scene_rows,
        "rows_read": rows_read,
        "duplicates_skipped": duplicates_skipped,
    }
    tmp = COVERAGE_CACHE.with_suffix(".tmp")
    tmp.write_bytes(pickle.dumps(state, protocol=pickle.HIGHEST_PROTOCOL))
    tmp.replace(COVERAGE_CACHE)
    return {
        "coverage": coverage,
        "scene_rows": scene_rows,
        "rows_read": rows_read,
        "duplicates_skipped": duplicates_skipped,
    }


def main():
    detection_files, footprint_files = load_file_lists()
    grids = {rid: make_grid(rid, poly) for rid, (_, poly) in REGIONS.items()}
    count_state = build_counts(detection_files)
    coverage_state = build_coverage(footprint_files, grids)
    bin_starts = [(START + timedelta(days=BIN_DAYS * i)).strftime("%Y-%m-%d") for i in range(BIN_COUNT)]
    complete_days = []
    for i in range(BIN_COUNT):
        begin = START + timedelta(days=BIN_DAYS * i)
        complete_days.append(min(BIN_DAYS, (END - begin).days))
    records = []
    for rid, (name, poly) in REGIONS.items():
        counts = count_state["counts"][rid]
        coverage = coverage_state["coverage"][rid]
        rates = np.divide(counts * 1000.0, coverage, out=np.full(BIN_COUNT, np.nan), where=coverage > 0)
        records.append({
            "cp": f"CP{rid:02d}",
            "name": name,
            "geometry_type": "line_buffer_6km" if rid == 19 else "precise_polygon",
            "bbox": [round(x, 4) for x in region_bbox(rid, poly)],
            "grid_spacing_km": round(grids[rid]["spacing_km"], 3),
            "approx_aoi_area_km2": round(grids[rid]["approx_aoi_area_km2"], 3),
            "bin_starts": bin_starts,
            "bin_actual_days": complete_days,
            "counts": counts.tolist(),
            "coverage_km2_obs": [round(float(v), 3) for v in coverage],
            "footprint_rows_counted": coverage_state["scene_rows"][rid].tolist(),
            "rates_per_1000_km2": [None if np.isnan(v) else round(float(v), 6) for v in rates],
            "total_detections": int(counts.sum()),
            "total_coverage_km2_obs": round(float(coverage.sum()), 3),
            "overall_rate_per_1000_km2": round(float(counts.sum() / coverage.sum() * 1000), 6) if coverage.sum() else None,
            "uncovered_bin_count": int((coverage <= 0).sum()),
        })
    payload = {
        "source": "Global Fishing Watch Sentinel-1 SAR vessel detections + detection footprints",
        "start": START.strftime("%Y-%m-%d"),
        "end_exclusive": END.strftime("%Y-%m-%d"),
        "bin_days": BIN_DAYS,
        "binning": "continuous from 2017-01-01; no annual reset",
        "rate_unit": "SAR detection events per 1,000 km² observed",
        "coverage_definition": "sum of footprint intersect AOI area after exact duplicate (scene_id, WKT) removal",
        "coverage_area_method": "adaptive regular-grid integration in user AOI",
        "detection_files": [f.name for f in detection_files],
        "footprint_files": [f.name for f in footprint_files],
        "detection_rows_read": count_state["rows_read"],
        "footprint_rows_read": coverage_state["rows_read"],
        "duplicate_footprint_rows_skipped": coverage_state["duplicates_skipped"],
        "regions": records,
    }
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(OUT), "bins": BIN_COUNT, "duplicates_skipped": coverage_state["duplicates_skipped"]}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
