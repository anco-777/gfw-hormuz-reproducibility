# 霍尔木兹研究数据与代码复核版

版本日期：2026-10-27。与本次正文及补充材料配套。原2026-10-24网页固定版本保持原样；本包包含后续修订。表格使用最新正文5表、补充8表；旧表格仅在archive中供追溯。

## 已运行的检查及限制

- 当前190项独立衍生数据与表格检查通过；原核验程序4组检查通过。
- 从配套逐日表重算432组时序设置：158组同时找到三地方向信号，严格分离顺序为0组，覆盖限制导致无法判定349组。
- 九幅图的数值重绘程序已运行成功；排版与标签位置可与论文图片不同。论文原图单独保留，并有数据映射表。
- 本轮未重新读取228个原始GFW CSV（约92.87 GiB）。原始运行日志属于此前复算记录，不计本轮原始数据端到端重跑。raw_input_inventory.csv中的原始SHA256均为空，不能据此认证原始文件逐字节一致。
- 表格一致和代码可运行不证明原始观测无误，也不构成事件因果验证。

## 安装与衍生结果核验

在本目录运行；建议Python 3.12.14。

~~~text
python -m pip install -r requirements_figures.txt
python code/validate_current_package.py --out-dir validation_new
python code/validate_completed_raw_results.py --root . --results-dir results/completed_raw --output-dir validation_legacy_new
python code/verify_temporal_order.py --root . --output-dir temporal_new --plot
python code/replot_figures.py --root . --out-dir figures_new
~~~

中文重绘需要系统可用的宋体、微软雅黑或等效中文字体；中文原图已保存。实际复核依赖与日志位于results/current_validation。程序失败时应检查退出码和日志，不可将异常或缺失输入记为通过。

## 从原始快照重算

原始数据入口：https://globalfishingwatch.org/datasets-and-code/。需要注册、遵守数据条款，并取得清单所列同一快照；上游后续处理更新可能改变结果。

~~~text
python code/run_completed_raw.py --raw-dir /path/to/gfw_csv --run-dir /path/to/empty_run_directory --hash-raw
python boundary/code/compute_cape_boundary.py --root . --raw-dir /path/to/gfw_csv --out-dir /path/to/new_boundary_results
~~~

第一个入口重算27区原始分析、精确日期历史、面积与窗口敏感性、AIS和时序结果；好望角窄／扩展边界用第二个入口单独重算。不得用空目录代替原始资料。--hash-raw会计算本次实际输入的校验值，但历史原始文件缺少既有哈希，无法进行历史逐字节比对。

## 数据对应与定义

- results/completed_raw是当前分析依据：1485条27区×55日事件记录、243条27区×9年精确日期历史、面积／窗口／固定基准阶段结果及AIS分组。名义窗口为2月1—27日和3月1—27日；2月资料实际截至25日。
- boundary保存两种好望角定义、110条逐日记录和六种边界×面积结果；仅说明增幅敏感，不支持方向反转。
- tables/main_01至05及supplement_01至08与现稿一致；其中main_05和supplement_08为外部文献／机制表，不是独立测算的经济结果。
- data/01及regions_27.geojson保存区域定义；巴拿马用中心线及6 km局部距离条件。范围CSV已与代码中心线四至扩展0.07°的预筛选范围一致，修正的是元数据，未改变统计结果。
- data/02—10及原始JSON包含早期汇总。尤其data/09是旧14日近似基准，不是现稿固定日期历史。重现现稿历史必须用results/completed_raw中的exact_date文件。
- strict matched不含空值、na、nan；未知记录仍计入总数和未匹配占比分母。legacy non_unmatched含未知状态，不等于现稿已匹配组。
- 无覆盖日期为缺失，不能当作活动为零。检测次数不是唯一船舶或航次数；累计面积保留重复场景的观测贡献。
- figures/figure_data_mapping.csv对应九幅图的输入；data/ne_50m_land.geojson为Natural Earth公共领域底图。
- FILE_INVENTORY.csv列文件用途类别、CSV行数与列名；SHA256SUMS.csv为本复核版完整文件校验清单，不是原始92.87 GiB的校验值。

## 来源与权利

GFW数据与上游算法保留原权利和条款。检测：https://github.com/GlobalFishingWatch/paper-industrial-activity；匹配：https://github.com/GlobalFishingWatch/paper-longline-ais-sar-matching。本文代码使用这些已发布产品，不包含SAR模型重新训练或原始卫星影像处理。Natural Earth来源和使用条件见data/Natural_Earth_Source.txt。

## 文献删除后的编号同步

按用户要求删除原第1、2篇。main_05与supplement_08的来源编号已与当前正文重排同步；tables/Reference_Number_Map_20261027.csv保留80条原编号到现编号的映射。该映射不是第14张研究结果表。本轮统计数据、分析代码和图像未变；190项检查、4组检查及432组时序复算为此前核验记录。本次核对其数值文件未改变，不另记作重新运行。
