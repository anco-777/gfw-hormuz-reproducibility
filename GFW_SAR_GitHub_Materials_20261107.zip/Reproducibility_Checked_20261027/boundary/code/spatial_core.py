"""Shared spatial routines matching the study's original grid implementation.

The default ``nominal`` area mode reproduces the original calculation:
each accepted grid centre contributes spacing_km ** 2.  ``spherical`` keeps
the same grid-centre inclusion rule but weights each cell row on a sphere.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np


EARTH_RADIUS_KM = 6371.0088
RING_RE = re.compile(r"\(([^()]*)\)")
TRANS = str.maketrans({"(": " ", ")": " ", ",": " "})


def load_regions(package_root: Path):
    source = (package_root / "source/original_code/build_gfw_timeseries_3day_precise.py").read_text(encoding="utf-8-sig")
    namespace: dict = {}
    exec(source.split("FILES=")[0], namespace)
    return namespace["REGIONS"], namespace["PANAMA_LINE"]


def points_in_polygon(xs, ys, poly):
    inside = np.zeros(xs.shape, dtype=bool)
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        inside ^= ((yi > ys) != (yj > ys)) & (
            xs < (xj - xi) * (ys - yi) / ((yj - yi) + 1e-30) + xi
        )
        j = i
    return inside


def segment_distance_km(lon, lat, a, b):
    mean = np.radians((lat + a[1] + b[1]) / 3)
    kx, ky = 111.32 * np.cos(mean), 110.57
    px, py = lon * kx, lat * ky
    ax, ay = a[0] * kx, a[1] * ky
    bx, by = b[0] * kx, b[1] * ky
    dx, dy = bx - ax, by - ay
    den = dx * dx + dy * dy
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / (den + 1e-30), 0, 1)
    return np.hypot(px - (ax + t * dx), py - (ay + t * dy))


def points_near_panama(xs, ys, panama_line):
    best = np.full(xs.shape, np.inf)
    for a, b in zip(panama_line[:-1], panama_line[1:]):
        best = np.minimum(best, segment_distance_km(xs, ys, a, b))
    return best <= 6.0


def region_bbox(rid, poly, panama_line):
    pts = panama_line if rid == 19 else poly
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    pad = 0.07 if rid == 19 else 0.0
    return min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad


def polygon_area_km2(poly):
    lat0 = sum(y for _, y in poly) / len(poly)
    kx, ky = 111.32 * math.cos(math.radians(lat0)), 110.57
    return abs(
        sum(
            (poly[i][0] * kx) * (poly[i + 1][1] * ky)
            - (poly[i + 1][0] * kx) * (poly[i][1] * ky)
            for i in range(len(poly) - 1)
        )
    ) / 2


def make_grid(rid, poly, panama_line, spacing_factor=1.0):
    est_area = 6 * 2 * 60 if rid == 19 else max(1.0, polygon_area_km2(poly))
    original_spacing = min(5.0, max(0.75, math.sqrt(est_area / 12000.0)))
    spacing = original_spacing * spacing_factor
    w, s, e, n = region_bbox(rid, poly, panama_line)
    lat0 = (s + n) / 2
    dy = spacing / 110.57
    dx = spacing / (111.32 * max(0.15, math.cos(math.radians(lat0))))
    xv = np.arange(w + dx / 2, e, dx)
    yv = np.arange(s + dy / 2, n, dy)
    xx, yy = np.meshgrid(xv, yv)
    xs, ys = xx.ravel(), yy.ravel()
    mask = points_near_panama(xs, ys, panama_line) if rid == 19 else points_in_polygon(xs, ys, poly)
    xs, ys = xs[mask], ys[mask]
    order = np.argsort(ys, kind="stable")
    xs, ys = xs[order], ys[order]
    unique_y, starts, counts = np.unique(ys, return_index=True, return_counts=True)
    lon_width_rad = math.radians(dx)
    row_area_spherical = (
        EARTH_RADIUS_KM**2
        * lon_width_rad
        * (np.sin(np.radians(unique_y + dy / 2)) - np.sin(np.radians(unique_y - dy / 2)))
    )
    return {
        "spacing_km": spacing,
        "original_spacing_km": original_spacing,
        "cell_area_km2": spacing * spacing,
        "row_area_spherical_km2": row_area_spherical,
        "xs": xs,
        "ys": ys,
        "unique_y": unique_y,
        "row_starts": starts,
        "row_counts": counts,
        "bbox": (w, s, e, n),
        "approx_aoi_area_km2": float(len(xs) * spacing * spacing),
    }


def flat_coords(wkt):
    vals = np.fromstring(wkt[wkt.find("(") :].translate(TRANS), sep=" ")
    if vals.size % 2:
        vals = vals[:-1]
    return vals.reshape(-1, 2)


def parse_rings(wkt):
    rings = []
    for match in RING_RE.finditer(wkt):
        vals = np.fromstring(match.group(1).replace(",", " "), sep=" ")
        if vals.size >= 8:
            if vals.size % 2:
                vals = vals[:-1]
            rings.append(vals.reshape(-1, 2))
    return rings


def covered_area_grid(wkt, grid, area_mode="nominal"):
    rings = parse_rings(wkt)
    if not rings:
        return 0.0
    total_area = 0.0
    for row_index, (y, start, count) in enumerate(
        zip(grid["unique_y"], grid["row_starts"], grid["row_counts"])
    ):
        crosses = []
        for poly in rings:
            x1, y1 = poly[:-1, 0], poly[:-1, 1]
            x2, y2 = poly[1:, 0], poly[1:, 1]
            take = (y1 > y) != (y2 > y)
            if take.any():
                crosses.append(x1[take] + (y - y1[take]) * (x2[take] - x1[take]) / (y2[take] - y1[take]))
        if not crosses:
            continue
        cx = np.sort(np.concatenate(crosses))
        rowx = grid["xs"][start : start + count]
        points = int((np.searchsorted(cx, rowx, side="right") % 2 == 1).sum())
        cell_area = (
            float(grid["row_area_spherical_km2"][row_index])
            if area_mode == "spherical"
            else grid["cell_area_km2"]
        )
        total_area += points * cell_area
    return total_area


def footprint_key(row):
    wkt = row["footprint_wkt"]
    return row["scene_id"], hashlib.blake2b(wkt.encode("utf-8"), digest_size=12).digest()


def snapshot_file_lists(package_root: Path):
    meta = json.loads(
        (package_root / "data/原始JSON/27区域2017至2026连续14日完整结果.json").read_text(encoding="utf-8-sig")
    )
    return meta["detection_files"], meta["footprint_files"]
