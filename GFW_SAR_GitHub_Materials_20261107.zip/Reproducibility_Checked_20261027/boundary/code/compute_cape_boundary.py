from pathlib import Path
import compute_event_sensitivities_and_ais as analysis

def boundary_regions(root):
    def rect(w,s,e,n): return [(w,s),(e,s),(e,n),(w,n),(w,s)]
    return {27:("Cape expanded",rect(14.,-40.,32.,-29.)),
            28:("Cape original narrow",rect(15.,-36.3,20.5,-31.8))}, []

analysis.load_regions=boundary_regions
if __name__ == "__main__": analysis.main()
