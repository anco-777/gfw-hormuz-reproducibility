# Figure Reproduction Package (Bilingual High-Resolution Edition)
# 论文主图与补充图复现补充包（中英文双语高清定稿版）

Companion figure-generation scripts, derived plotting datasets, CSV source tables, deterministic SIL OFL-1.1 fonts, and all **22 publication-ready high-resolution PNG figures (350–360 DPI)** for:

* **English Manuscript**: *Satellite radar reveals shipping reorganization across global chokepoints amid the 2026 Strait of Hormuz crisis*
* **中文主稿**：《卫星雷达揭示 2026 年霍尔木兹危机背景下全球关键海上通道的航运重组》

This package complements the raw-archive and confidence-interval workflows in [`gfw-hormuz-reproducibility`](https://github.com/anco-777/gfw-hormuz-reproducibility) (`Source_Data/`, `Reproducibility_Checked_20261027/`, and `ci_reproduction/`) and reproduces all **9 figure groups (4 main figures + 5 supplementary figures, 22 PNG files across English and Simplified Chinese)** pixel-for-pixel using estimation graphics conventions aligned with [*Nature* (Ohenhen et al., 2026)](https://doi.org/10.1038/s41586-025-09928-6), [*Nature* (Gaskin & Abel, 2026)](https://doi.org/10.1038/s41586-026-10611-7), and [*Nature Methods* DABEST 2.0 (Lu et al., 2026)](https://doi.org/10.1038/s41592-026-03187-7).

## 1. Directory Structure | 目录结构

```text
GFW_SAR_Figure_Reproduction_CN_EN/
├── README.md                          # Bilingual documentation & figure-to-data index
├── LICENSE                            # MIT (code) + CC BY 4.0 (data/figs) + OFL-1.1 (fonts) + Natural Earth PD
├── requirements.txt                   # Minimal pure-Python dependencies (numpy, matplotlib, Pillow)
├── SHA256SUMS.txt                     # SHA-256 checksums for all scripts, JSON/CSV data, fonts, and 22 PNGs
├── run_all_figures.py                 # One-click reproduction & DPI/dimension verifier
├── scripts/
│   ├── generate_main_figures.py       # Generates Main Figs. 1–4 (EN & CN, 360 DPI)
│   ├── generate_supp_figures.py       # Generates Supplementary Figs. 1–5 (EN & CN, 350–360 DPI)
│   └── export_csv_tables.py           # Exports structured JSON plotting inputs to UTF-8 CSV tables
├── data/
│   ├── master_data.json               # Master derived estimates, 3-day block 95% CIs, historical & sensitivity tables
│   ├── supp4_daily_rolling.json       # Daily covered observations, 7-day rolling curves & uncovered dates
│   └── basemaps/
│       ├── naturalearth_110m_land.geojson   # Natural Earth 1:110m land vectors (OGC:CRS84, Fig. 2a)
│       ├── south_africa_1_50m_land.json     # Natural Earth 1:50m Southern Africa coastline (Supp. Fig. 5a)
│       └── supp_fig1_base/                  # Base WGS 84 27-corridor polygon plates (CP01–CP27, Supp. Fig. 1)
├── Source_Data_Figures_CSV/           # Human-readable UTF-8 CSV exports underlying every figure panel
│   ├── 01_corridors_27_rates_and_ais_ci.csv
│   ├── 02_corridors_27_historical_2017_2025.csv
│   ├── 03_focal_area_grid_sensitivity.csv
│   ├── 04_focal_window_sensitivity_ci.csv
│   ├── 05_global_annual_sar_ais_2017_2026H1.csv
│   ├── 06_post_event_phases_summary.csv
│   ├── 06b_post_event_daily_and_7d_rolling.csv
│   └── 07_cape_boundary_grid_block_sensitivity.csv
├── figures/                           # Pre-rendered 22 high-resolution PNG figures (matching manuscript embeds)
│   ├── English_Main/                  # Fig. 1 – Fig. 4 (360 DPI)
│   ├── English_Supplement/            # Supp. Fig. 1 (3 plates) – Supp. Fig. 5 (350–360 DPI)
│   ├── Chinese_Main/                  # 图 1 – 图 4 (360 DPI)
│   └── Chinese_Supplement/            # 补充图 1 (3 页) – 补充图 5 (350–360 DPI)
└── fonts/                             # Bundled SIL OFL-1.1 fonts + complete verbatim license texts
    ├── LiberationSans-Regular.ttf
    ├── LiberationSans-Bold.ttf
    ├── ReproSansCJKSC-Regular.otf
    ├── ReproSansCJKSC-Bold.otf
    ├── OFL-1.1.txt
    ├── LICENSE_LiberationSans_OFL-1.1.txt
    ├── LICENSE_ReproSansCJKSC_OFL-1.1.txt
    └── README_FONTS.txt
```

## 2. Quickstart | 一键复现方法

Requires **Python 3.9+** with only three lightweight packages (`numpy`, `matplotlib`, `Pillow` — no GDAL or OpenCV installation required):

```bash
pip install -r requirements.txt

# Regenerate all 8 CSV tables and all 22 bilingual PNG figures into ./figures_reproduced
python3 run_all_figures.py --out-dir ./figures_reproduced

# Verify integrity of pre-packaged data, scripts, fonts, and manuscript-embedded PNGs
sha256sum -c SHA256SUMS.txt
```

## 3. Figure-to-Script & Source Table Index | 图表—脚本—源数据对照索引

| Figure (EN / CN) | Script & Function | Underlying CSV in `Source_Data_Figures_CSV/` | Output Resolution & DPI |
| --- | --- | --- | --- |
| **Fig. 1 / 图 1** | `scripts/generate_main_figures.py` (`make_fig1`) | `01_corridors_27_rates_and_ais_ci.csv` | `3960 × 3024 px` (360 DPI) |
| **Fig. 2 / 图 2** | `scripts/generate_main_figures.py` (`make_fig2`) | `01_corridors_27_rates_and_ais_ci.csv`, `03_focal_area_grid_sensitivity.csv` | `3960 × 2951 px` (360 DPI) |
| **Fig. 3 / 图 3** | `scripts/generate_main_figures.py` (`make_fig3`) | `02_corridors_27_historical_2017_2025.csv` | `3960 × 2951 px` (360 DPI) |
| **Fig. 4 / 图 4** | `scripts/generate_main_figures.py` (`make_fig4`) | `01_corridors_27_rates_and_ais_ci.csv` | `3960 × 2340 px` (360 DPI) |
| **Supp. Fig. 1a–aa / 补充图 1a–aa** (3 plates) | `scripts/generate_supp_figures.py` (`make_supp_fig1`) | `data/basemaps/supp_fig1_base/` (`regions_27.geojson`, Supp. Table 3) | `2222 × 2430 px` (350 DPI) |
| **Supp. Fig. 2 / 补充图 2** | `scripts/generate_supp_figures.py` (`make_supp_fig2`) | `04_focal_window_sensitivity_ci.csv` | `3816 × 2628 px` (360 DPI) |
| **Supp. Fig. 3 / 补充图 3** | `scripts/generate_supp_figures.py` (`make_supp_fig3`) | `05_global_annual_sar_ais_2017_2026H1.csv` | `3744 × 2232 px` (360 DPI) |
| **Supp. Fig. 4 / 补充图 4** | `scripts/generate_supp_figures.py` (`make_supp_fig4`) | `06_post_event_phases_summary.csv`, `06b_post_event_daily_and_7d_rolling.csv` | `3780 × 3168 px` (360 DPI) |
| **Supp. Fig. 5 / 补充图 5** | `scripts/generate_supp_figures.py` (`make_supp_fig5`) | `07_cape_boundary_grid_block_sensitivity.csv` | `3960 × 1835 px` (360 DPI) |

## 4. Coordinate System & External Data Sources | 坐标约定与上游数据源

* **Coordinate Reference System**: All geographic coordinates follow WGS 84 longitude–latitude order (`[lon, lat]`) per [OGC:CRS84](http://www.opengis.net/def/crs/OGC/1.3/CRS84) and [IETF RFC 7946 GeoJSON](https://doi.org/10.17487/RFC7946).
* **SAR Detections & Footprints**: Raw Sentinel-1 SAR vessel detections and image footprints are distributed via the [Global Fishing Watch Data Download Portal](https://globalfishingwatch.org/datasets-and-code/) ([Paolo et al., *Nature* 2024](https://doi.org/10.1038/s41586-023-06825-8)).
* **Cartographic Basemaps**: Land polygons use [Natural Earth 1:10m, 1:50m, and 1:110m Land Vectors](https://www.naturalearthdata.com/about/terms-of-use/) (Public Domain) for cartographic reference only.
