Optional CJK / Sans-Serif Font Folder
=====================================
By default, scripts/generate_main_figures.py and scripts/generate_supp_figures.py
automatically detect installed system fonts across Linux, macOS, and Windows:
- English figures: Liberation Sans -> Arial -> Helvetica -> DejaVu Sans
- Chinese figures: Noto Sans CJK SC -> Source Han Sans SC -> PingFang SC -> Microsoft YaHei

If you wish to reproduce the exact Linux glyph metrics byte-for-byte on another OS,
place `NotoSansCJKsc-Regular.otf` and `NotoSansCJKsc-Bold.otf` (SIL Open Font License 1.1)
into this `fonts/` directory before running `python3 run_all_figures.py`.
