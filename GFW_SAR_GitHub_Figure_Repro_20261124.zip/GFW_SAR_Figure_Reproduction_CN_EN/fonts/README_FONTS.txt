Bundled Deterministic Reproduction Fonts & Licenses (SIL OFL-1.1)
=================================================================
To guarantee 100% pixel-identical figure generation across Linux, macOS, and Windows,
this directory bundles two SIL Open Font License 1.1 (OFL-1.1) font families:

1. `LiberationSans-Regular.ttf` & `LiberationSans-Bold.ttf` (Version 2.1.5, Unmodified)
   - Upstream: Google Corporation & Red Hat, Inc. (https://github.com/liberationfonts)
   - License: SIL Open Font License, Version 1.1 -> see `LICENSE_LiberationSans_OFL-1.1.txt`

2. `ReproSansCJKSC-Regular.otf` & `ReproSansCJKSC-Bold.otf` (Version 2.004 OFL Subset)
   - Upstream: Derived from Adobe / Google `Noto Sans CJK SC` v2.004 (https://github.com/googlefonts/noto-cjk)
   - Subsetted to GB2312 (6,763 Chinese characters) + Latin/Greek/math symbols and renamed
     to `Repro Sans CJK SC` in strict compliance with SIL OFL-1.1 Condition 3.
   - License: SIL Open Font License, Version 1.1 -> see `LICENSE_ReproSansCJKSC_OFL-1.1.txt`

Full verbatim license text is also provided in `OFL-1.1.txt`.
If these font files are removed, `scripts/generate_main_figures.py` and
`scripts/generate_supp_figures.py` automatically fall back to installed OS fonts.
