#!/usr/bin/env python3
"""Export structured JSON figure inputs to human-readable UTF-8 CSV tables."""
import os, json, csv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data")
CSV_DIR = os.path.join(ROOT, "Source_Data_Figures_CSV")
os.makedirs(CSV_DIR, exist_ok=True)

def get_macro_group(idx, macro_groups):
    for name_en, name_cn, i0, i1 in macro_groups:
        if i0 <= idx <= i1:
            return name_en, name_cn
    return "", ""

def main():
    with open(os.path.join(DATA_DIR, "master_data.json"), encoding="utf-8") as f:
        master = json.load(f)
    with open(os.path.join(DATA_DIR, "supp4_daily_rolling.json"), encoding="utf-8") as f:
        supp4 = json.load(f)

    m_groups = master["macro_groups"]

    # 1. Main 27 corridors + AIS strata (Fig. 1, Fig. 2a/b, Fig. 4)
    p1 = os.path.join(CSV_DIR, "01_corridors_27_rates_and_ais_ci.csv")
    with open(p1, "w", newline="", encoding="utf-8-sig") as f:
        cols = [
            "id", "name_en", "name_cn", "macro_group_en", "macro_group_cn",
            "is_focal", "lon", "lat", "pre_cov_days", "post_cov_days", "low_cov_lt5d", "sign_reversal",
            "pre_count", "post_count", "raw_chg_pct", "norm_chg_pct", "norm_ci_low_pct", "norm_ci_high_pct",
            "pre_rate_per_1000km2", "post_rate_per_1000km2",
            "ais_matched_chg_pct", "ais_matched_ci_low", "ais_matched_ci_high",
            "ais_unmatched_chg_pct", "ais_unmatched_ci_low", "ais_unmatched_ci_high",
            "unmatched_share_diff_pp", "unmatched_share_ci_low_pp", "unmatched_share_ci_high_pp"
        ]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for c in master["corridors"]:
            g_en, g_cn = get_macro_group(c["idx"], m_groups)
            ci = c.get("rc_ci") or [None, None]
            mci = c.get("m_ci") or [None, None]
            uci = c.get("u_ci") or [None, None]
            duci = c.get("du_ci") or [None, None]
            w.writerow({
                "id": c["id"], "name_en": c["name_en"], "name_cn": c["name_cn"],
                "macro_group_en": g_en, "macro_group_cn": g_cn,
                "is_focal": c["is_focal"], "lon": c["lon"], "lat": c["lat"],
                "pre_cov_days": c["pre_d"], "post_cov_days": c["post_d"],
                "low_cov_lt5d": c["flagged"], "sign_reversal": c["is_sign_reversal"],
                "pre_count": c["pre_cnt"], "post_count": c["post_cnt"],
                "raw_chg_pct": c["cnt_chg"], "norm_chg_pct": c["rate_chg"],
                "norm_ci_low_pct": ci[0], "norm_ci_high_pct": ci[1],
                "pre_rate_per_1000km2": c["pre_rate"], "post_rate_per_1000km2": c["post_rate"],
                "ais_matched_chg_pct": c["m_chg"], "ais_matched_ci_low": mci[0], "ais_matched_ci_high": mci[1],
                "ais_unmatched_chg_pct": c["u_chg"], "ais_unmatched_ci_low": uci[0], "ais_unmatched_ci_high": uci[1],
                "unmatched_share_diff_pp": c["du_est"], "unmatched_share_ci_low_pp": duci[0], "unmatched_share_ci_high_pp": duci[1],
            })

    # 2. Historical 2017-2025 baselines vs 2026 (Fig. 3)
    p2 = os.path.join(CSV_DIR, "02_corridors_27_historical_2017_2025.csv")
    with open(p2, "w", newline="", encoding="utf-8-sig") as f:
        cols = [
            "id", "name_en", "name_cn", "chg_2026_pct", "outside_hist_span",
            "hist_min_pct", "hist_max_pct", "hist_median_pct", "hist_med_ci_low_pct", "hist_med_ci_high_pct", "hist_pos_years"
        ]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for c in master["corridors"]:
            w.writerow({
                "id": c["id"], "name_en": c["name_en"], "name_cn": c["name_cn"],
                "chg_2026_pct": c["rate_chg"], "outside_hist_span": c["outside_hist"],
                "hist_min_pct": c["hist_min"], "hist_max_pct": c["hist_max"],
                "hist_median_pct": c["hist_med"],
                "hist_med_ci_low_pct": c["hmed_ci_lo"], "hist_med_ci_high_pct": c["hmed_ci_hi"],
                "hist_pos_years": c["hist_pos"],
            })

    # 3. Area-grid sensitivity on 6 Table 1 corridors (Fig. 2c)
    p3 = os.path.join(CSV_DIR, "03_focal_area_grid_sensitivity.csv")
    with open(p3, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["id", "name_en", "name_cn", "baseline_grid_chg_pct", "halved_grid_chg_pct", "spherical_grid_chg_pct"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for c in master["corridors"]:
            if c.get("grid_base") is not None:
                w.writerow({
                    "id": c["id"], "name_en": c["name_en"], "name_cn": c["name_cn"],
                    "baseline_grid_chg_pct": c["grid_base"],
                    "halved_grid_chg_pct": c["grid_half"],
                    "spherical_grid_chg_pct": c["grid_sph"],
                })

    # 4. Temporal window sensitivity (Supp. Fig. 2)
    p4 = os.path.join(CSV_DIR, "04_focal_window_sensitivity_ci.csv")
    with open(p4, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["id", "window", "cov_days_pre_post", "low_cov_lt5d", "valid_replicates", "rate_chg_pct", "ci_low_pct", "ci_high_pct"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in master["win_sens"]:
            ci = r.get("ci") or [None, None]
            w.writerow({
                "id": r["id"], "window": r["window"], "cov_days_pre_post": r["cov_days"],
                "low_cov_lt5d": r["flagged"], "valid_replicates": r["valid_rep"],
                "rate_chg_pct": r["est"], "ci_low_pct": ci[0], "ci_high_pct": ci[1],
            })

    # 5. Global annual SAR & AIS-unmatched shares 2017-2026 H1 (Supp. Fig. 3)
    p5 = os.path.join(CSV_DIR, "05_global_annual_sar_ais_2017_2026H1.csv")
    with open(p5, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["year_label", "months_included", "total_detections", "unmatched_detections", "unmatched_share_pct",
                "ci_1month_low_pct", "ci_1month_high_pct", "ci_3month_low_pct", "ci_3month_high_pct"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in master["annual_bg"]:
            c1 = r.get("ci1") or [None, None]
            c3 = r.get("ci3") or [None, None]
            w.writerow({
                "year_label": r["year_label"], "months_included": r["months"],
                "total_detections": r["total"], "unmatched_detections": r["unmatched"],
                "unmatched_share_pct": r["share"],
                "ci_1month_low_pct": c1[0], "ci_1month_high_pct": c1[1],
                "ci_3month_low_pct": c3[0], "ci_3month_high_pct": c3[1],
            })

    # 6. Post-event phased summary & daily/rolling series (Supp. Fig. 4)
    p6 = os.path.join(CSV_DIR, "06_post_event_phases_summary.csv")
    with open(p6, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["id", "phase_en", "phase_cn", "covered_days", "low_cov_lt5d", "rate_chg_pct"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for cid, obj in master["post_phases"].items():
            for ph_en, ph_cn, chg, cd in zip(obj["phases"], obj["phases_cn"], obj["chg"], obj["cov_d"]):
                w.writerow({
                    "id": cid, "phase_en": ph_en, "phase_cn": ph_cn,
                    "covered_days": cd, "low_cov_lt5d": cd < 5, "rate_chg_pct": chg,
                })

    p6b = os.path.join(CSV_DIR, "06b_post_event_daily_and_7d_rolling.csv")
    with open(p6b, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["id", "series_type", "march_day", "rate_chg_pct"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for cid, obj in supp4.items():
            for pt in obj["covered"]:
                w.writerow({"id": cid, "series_type": "covered_day_chg", "march_day": pt["day"], "rate_chg_pct": pt["val"]})
            for pt in obj["rolling"]:
                w.writerow({"id": cid, "series_type": "rolling_7d_chg", "march_day": pt["day"], "rate_chg_pct": pt["val"]})
            for d_idx in obj["uncovered_days"]:
                w.writerow({"id": cid, "series_type": "uncovered_date", "march_day": d_idx, "rate_chg_pct": None})

    # 7. Cape of Good Hope joint sensitivity (Supp. Fig. 5)
    p7 = os.path.join(CSV_DIR, "07_cape_boundary_grid_block_sensitivity.csv")
    with open(p7, "w", newline="", encoding="utf-8-sig") as f:
        cols = ["boundary", "method", "algo_code", "pre_rate", "post_rate", "rate_chg_pct",
                "ci_1d_low", "ci_1d_high", "ci_3d_low", "ci_3d_high", "ci_7d_low", "ci_7d_high"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in master["cape_sens"]:
            w.writerow({
                "boundary": r["boundary"], "method": r["method"], "algo_code": r["algo_code"],
                "pre_rate": r["pre_rate"], "post_rate": r["post_rate"], "rate_chg_pct": r["chg_disp"],
                "ci_1d_low": r["ci1"][0], "ci_1d_high": r["ci1"][1],
                "ci_3d_low": r["ci3"][0], "ci_3d_high": r["ci3"][1],
                "ci_7d_low": r["ci7"][0], "ci_7d_high": r["ci7"][1],
            })
    print("Exported 8 CSV source tables to:", CSV_DIR)

if __name__ == "__main__":
    main()
