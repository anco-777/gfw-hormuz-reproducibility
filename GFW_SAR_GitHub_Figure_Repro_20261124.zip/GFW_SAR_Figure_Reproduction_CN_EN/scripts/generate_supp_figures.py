#!/usr/bin/env python3
"""
Standalone generator for Supplementary Figures 1–5 (English & Chinese, 350–360 DPI).
Uses only relative repository paths, prioritized bundled SIL OFL-1.1 fonts,
and bundled Natural Earth 1:50m coordinates (zero OpenCV dependency).
"""
import os, sys, json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import matplotlib.font_manager as fm
from matplotlib.gridspec import GridSpec

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(REPO_ROOT, "data")
FONTS_DIR = os.path.join(REPO_ROOT, "fonts")

_bundled_font_paths = []
for fn in sorted(os.listdir(FONTS_DIR)) if os.path.isdir(FONTS_DIR) else []:
    if fn.lower().endswith((".otf", ".ttf", ".ttc")):
        fp = os.path.abspath(os.path.join(FONTS_DIR, fn))
        fm.fontManager.addfont(fp)
        _bundled_font_paths.append(fp)
if _bundled_font_paths:
    _bset = set(_bundled_font_paths)
    fm.fontManager.ttflist = (
        [e for e in fm.fontManager.ttflist if os.path.abspath(e.fname) in _bset]
        + [e for e in fm.fontManager.ttflist if os.path.abspath(e.fname) not in _bset]
    )
    if hasattr(fm.fontManager, "_findfont_cached"):
        fm.fontManager._findfont_cached.cache_clear()

with open(os.path.join(DATA_DIR, "master_data.json"), encoding="utf-8") as f:
    DATA = json.load(f)
with open(os.path.join(DATA_DIR, "supp4_daily_rolling.json"), encoding="utf-8") as f:
    SUPP4 = json.load(f)
with open(os.path.join(DATA_DIR, "basemaps", "south_africa_1_50m_land.json"), encoding="utf-8") as f:
    _sa_obj = json.load(f)
SA_LONS = np.array(_sa_obj["lons"], dtype=float)
SA_LATS = np.array(_sa_obj["lats"], dtype=float)

OUT_DIR = os.environ.get("GFW_FIG_OUT_DIR", os.path.join(REPO_ROOT, "figures"))
os.makedirs(OUT_DIR, exist_ok=True)

OUT_SUPP_MAP = {
    ("supp_fig1_p1", "en"): "English_Supplement/SuppFig1a-i_Region_Boundaries_CP01-CP09.png",
    ("supp_fig1_p2", "en"): "English_Supplement/SuppFig1j-r_Region_Boundaries_CP10-CP18.png",
    ("supp_fig1_p3", "en"): "English_Supplement/SuppFig1s-aa_Region_Boundaries_CP19-CP27.png",
    ("supp_fig2", "en"): "English_Supplement/SuppFig2_Window_Sensitivity_95CI.png",
    ("supp_fig3", "en"): "English_Supplement/SuppFig3_Annual_Global_SAR_AIS_Intervals.png",
    ("supp_fig4", "en"): "English_Supplement/SuppFig4_Daily_Rolling_and_Phases.png",
    ("supp_fig5", "en"): "English_Supplement/SuppFig5_Cape_Boundary_and_Sensitivity_95CI.png",
    ("supp_fig1_p1", "cn"): "Chinese_Supplement/补充图1a-i_研究区域边界_CP01-CP09.png",
    ("supp_fig1_p2", "cn"): "Chinese_Supplement/补充图1j-r_研究区域边界_CP10-CP18.png",
    ("supp_fig1_p3", "cn"): "Chinese_Supplement/补充图1s-aa_研究区域边界_CP19-CP27.png",
    ("supp_fig2", "cn"): "Chinese_Supplement/补充图2_重点海域时间窗口敏感性与置信区间.png",
    ("supp_fig3", "cn"): "Chinese_Supplement/补充图3_全球年度SAR与AIS未匹配探索性区间.png",
    ("supp_fig4", "cn"): "Chinese_Supplement/补充图4_三地逐日滚动与分阶段变化.png",
    ("supp_fig5", "cn"): "Chinese_Supplement/补充图5_好望角双边界与多设定区间估计.png",
}

def resolve_supp_out(fig_key, lang):
    rel = OUT_SUPP_MAP[(fig_key, lang)]
    full = os.path.join(OUT_DIR, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    return full

def find_pil_font(candidates_files, candidates_families, weight="normal"):
    for p in candidates_files:
        if p and os.path.exists(p):
            return p
    for fam in candidates_families:
        try:
            matched = fm.findfont(fm.FontProperties(family=fam, weight=weight), fallback_to_default=False)
            if matched and os.path.exists(matched):
                return matched
        except Exception:
            continue
    return fm.findfont(fm.FontProperties(family="sans-serif", weight=weight))

COL_POS = "#C8472C"
COL_NEG = "#1B5E91"
COL_TEXT = "#111827"
COL_MUTED = "#475569"
COL_GRID = "#EAECEF"
COL_ZERO = "#262626"
COL_FRAME = "#262626"
COL_RIM = "#1E293B"
COL_ZEBRA = "#F7F9FB"

def set_lang_rc(lang="en"):
    plt.rcParams.update(plt.rcParamsDefault)
    if lang == "cn":
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["Repro Sans CJK SC", "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "SimHei", "WenQuanYi Micro Hei", "Liberation Sans", "Arial", "DejaVu Sans"]
    else:
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["Liberation Sans", "Arial", "Helvetica", "Repro Sans CJK SC", "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.edgecolor"] = COL_FRAME
    plt.rcParams["axes.linewidth"] = 0.68
    plt.rcParams["xtick.color"] = COL_FRAME
    plt.rcParams["ytick.color"] = COL_FRAME
    plt.rcParams["xtick.major.width"] = 0.65
    plt.rcParams["ytick.major.width"] = 0.65
    plt.rcParams["xtick.major.size"] = 2.8
    plt.rcParams["ytick.major.size"] = 2.8
    plt.rcParams["xtick.labelsize"] = 8.0
    plt.rcParams["ytick.labelsize"] = 8.0
    plt.rcParams["text.color"] = COL_TEXT

def style_nature_box(ax):
    for sp in ax.spines.values():
        sp.set_visible(True)
        sp.set_color(COL_FRAME)
        sp.set_linewidth(0.68)

def style_top_legend(leg):
    frame = leg.get_frame()
    frame.set_facecolor("#F8FAFC")
    frame.set_edgecolor("#CBD5E1")
    frame.set_linewidth(0.6)
    frame.set_alpha(0.96)
    frame.set_boxstyle("round,pad=0.28,rounding_size=0.35")

def fmt_signed(val, decimals=1):
    sign = "+" if val > 0 else ("−" if val < 0 else "")
    return f"{sign}{abs(val):.{decimals}f}"

#

# ==============================================================================
# SUPP FIG. 1 (3 pages: a-i, j-r, s-aa) — Ohenhen Extended Data Figs. 2–7 style
# ==============================================================================
def make_supp_fig1(lang="en"):
    corridors = DATA["corridors"]
    lib_bold = find_pil_font(
        [os.path.join(FONTS_DIR, "LiberationSans-Bold.ttf"), "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"],
        ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"], weight="bold"
    )
    lib_reg = find_pil_font(
        [os.path.join(FONTS_DIR, "LiberationSans-Regular.ttf"), "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"],
        ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"], weight="normal"
    )
    cjk_bold = find_pil_font(
        [os.path.join(FONTS_DIR, "ReproSansCJKSC-Bold.otf")],
        ["Repro Sans CJK SC", "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "SimHei", "WenQuanYi Micro Hei"], weight="bold"
    )
    cjk_reg = find_pil_font(
        [os.path.join(FONTS_DIR, "ReproSansCJKSC-Regular.otf")],
        ["Repro Sans CJK SC", "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "SimHei", "WenQuanYi Micro Hei"], weight="normal"
    )

    f_panel_ltr = ImageFont.truetype(lib_bold, 38)
    f_cp = ImageFont.truetype(lib_bold, 25)
    f_name = ImageFont.truetype(cjk_bold if lang == "cn" else lib_reg, 27)
    f_leg = ImageFont.truetype(cjk_reg if lang == "cn" else lib_reg, 25)
    f_leg_b = ImageFont.truetype(cjk_bold if lang == "cn" else lib_bold, 25)

    panel_codes = [chr(ord('a') + i) if i < 26 else "aa" for i in range(27)]
    row_hdr_clear = [(0, 196), (820, 1032), (1655, 1868)]
    col_bounds = [(242, 739), (968, 1465), (1694, 2190)]

    for page_idx in range(3):
        src_img_path = os.path.join(DATA_DIR, "basemaps", "supp_fig1_base", f"base_p{page_idx + 1}_{lang}.png")
        im = Image.open(src_img_path).convert("RGB")
        draw = ImageDraw.Draw(im)
        W, H = im.size

        for r0, r1 in row_hdr_clear:
            draw.rectangle([0, r0, W, r1], fill=(255, 255, 255))
        draw.rectangle([0, 2416, W, H], fill=(255, 255, 255))

        for r_i in range(3):
            y_box_top = [211, 1047, 1884][r_i]
            y_ltr = y_box_top - 104
            y_sub = y_box_top - 50
            for c_i in range(3):
                idx = page_idx * 9 + r_i * 3 + c_i
                c = corridors[idx]
                p_ltr = panel_codes[idx]
                x0, _ = col_bounds[c_i]

                draw.text((x0, y_ltr), p_ltr, fill=(17, 24, 39), font=f_panel_ltr)
                ltr_w = draw.textlength(p_ltr, font=f_panel_ltr)

                # Crisp subtle pill badge for CP01..CP27 (focal vs comparative tint)
                cp_txt = c["id"]
                cp_w = draw.textlength(cp_txt, font=f_cp)
                bx0 = x0 + ltr_w + 15
                by0 = y_ltr + 5
                if c["is_focal"]:
                    draw.rounded_rectangle([bx0, by0, bx0 + cp_w + 20, by0 + 33],
                                           radius=7, fill=(254, 243, 235), outline=(194, 106, 56), width=2)
                    draw.text((bx0 + 10, by0 + 3), cp_txt, fill=(154, 52, 18), font=f_cp)
                else:
                    draw.rounded_rectangle([bx0, by0, bx0 + cp_w + 20, by0 + 33],
                                           radius=7, fill=(241, 245, 249), outline=(148, 163, 184), width=2)
                    draw.text((bx0 + 10, by0 + 3), cp_txt, fill=(51, 65, 85), font=f_cp)

                nm = c["short_en"] if lang == "en" else c["name_cn"]
                draw.text((x0, y_sub), nm, fill=(17, 24, 39), font=f_name)

        # Nature Extended Data Figs. 2–7 style rounded light-gray capsule legend bar
        ly = 2431
        t1 = "Focal region" if lang == "en" else "重点区域边界"
        t2 = "Comparative region" if lang == "en" else "对比区域边界"
        t3 = "Land" if lang == "en" else "陆地"

        if page_idx == 2:
            t4 = "Panama centerline" if lang == "en" else "巴拿马中心线"
            total_leg_w = (44 + 14 + draw.textlength(t1, font=f_leg_b) + 52 +
                           44 + 14 + draw.textlength(t2, font=f_leg) + 52 +
                           44 + 14 + draw.textlength(t3, font=f_leg) + 52 +
                           44 + 14 + draw.textlength(t4, font=f_leg))
        else:
            total_leg_w = (44 + 14 + draw.textlength(t1, font=f_leg_b) + 66 +
                           44 + 14 + draw.textlength(t2, font=f_leg) + 66 +
                           44 + 14 + draw.textlength(t3, font=f_leg))
        x_start = 0.5 * (W - total_leg_w)
        pill_pad_x, pill_pad_y = 34, 11
        draw.rounded_rectangle(
            [x_start - pill_pad_x, ly - pill_pad_y + 2, x_start + total_leg_w + pill_pad_x, ly + 30 + pill_pad_y],
            radius=16, fill=(248, 250, 252), outline=(203, 213, 225), width=2
        )

        x_cur = x_start
        gap = 52 if page_idx == 2 else 66

        draw.rounded_rectangle([x_cur, ly + 2, x_cur + 44, ly + 28], radius=4, fill=(238, 222, 209), outline=(184, 92, 38), width=3)
        draw.text((x_cur + 58, ly), t1, fill=(17, 24, 39), font=f_leg_b)
        x_cur += 58 + draw.textlength(t1, font=f_leg_b) + gap

        draw.rounded_rectangle([x_cur, ly + 2, x_cur + 44, ly + 28], radius=4, fill=(214, 230, 240), outline=(36, 102, 142), width=3)
        draw.text((x_cur + 58, ly), t2, fill=(30, 41, 59), font=f_leg)
        x_cur += 58 + draw.textlength(t2, font=f_leg) + gap

        draw.rounded_rectangle([x_cur, ly + 2, x_cur + 44, ly + 28], radius=4, fill=(226, 230, 234), outline=(100, 116, 139), width=2)
        draw.text((x_cur + 58, ly), t3, fill=(51, 65, 85), font=f_leg)

        if page_idx == 2:
            x_cur += 58 + draw.textlength(t3, font=f_leg) + gap
            for seg in range(3):
                draw.line([x_cur + seg * 16, ly + 15, x_cur + seg * 16 + 10, ly + 15], fill=(36, 102, 142), width=3)
            draw.text((x_cur + 58, ly), t4, fill=(51, 65, 85), font=f_leg)

        im_cropped = im.crop((0, 72, W, H))
        out_p = resolve_supp_out(f"supp_fig1_p{page_idx + 1}", lang)
        im_cropped.save(out_p, dpi=(350, 350))
        print("Generated:", out_p)


# ==============================================================================
# SUPP FIG. 2: Temporal Window Sensitivity (Ohenhen Extended Data Fig. 8 style)
# ==============================================================================
def make_supp_fig2(lang="en"):
    set_lang_rc(lang)
    by_id = {c["id"]: c for c in DATA["corridors"]}
    ws_list = DATA["win_sens"]

    focal6 = ["CP01", "CP02", "CP13", "CP19", "CP26", "CP27"]
    win_order = ["7d", "14d", "25d", "27d"]
    win_lbls_en = ["7 d", "14 d", "25 d\n(aligned)", "27 d\n(primary)"]
    win_lbls_cn = ["7日", "14日", "25日\n(对齐)", "27日\n(主窗口)"]
    panel_ltrs = ["a", "b", "c", "d", "e", "f"]
    reg_cols = {
        "CP01": COL_NEG, "CP02": "#3B7EA1", "CP13": "#5B5F97",
        "CP19": "#2E6F65", "CP26": COL_POS, "CP27": "#B45309"
    }

    fig = plt.figure(figsize=(10.6, 7.3), dpi=360, facecolor="white")
    gs = GridSpec(3, 2, figure=fig, hspace=0.46, wspace=0.24,
                  left=0.082, right=0.975, top=0.898, bottom=0.08)

    y_configs = {
        "CP01": (-78, -61, 44, [-60, -30, 0, 30]),
        "CP02": (-82, -66, 18, [-60, -40, -20, 0]),
        "CP13": (-78, -51, 134, [-50, 0, 50, 100]),
        "CP19": (-36, -13, 162, [0, 50, 100, 150]),
        "CP26": (-118, -50, 368, [0, 100, 200, 300]),
        "CP27": (-36, -23, 48, [-20, 0, 20, 40]),
    }

    for idx, cid in enumerate(focal6):
        ax = fig.add_subplot(gs[idx // 2, idx % 2])
        col = reg_cols[cid]
        c_info = by_id[cid]
        rows = {r["window"]: r for r in ws_list if r["id"] == cid}

        ymin, strip_top, ymax, yticks = y_configs[cid]
        ax.axhspan(ymin, strip_top, color="#F4F6F9", zorder=0)
        ax.axhline(strip_top, color="#94A3B8", lw=0.68, zorder=1)
        ax.axhline(0, color=COL_ZERO, lw=0.85, ls="--", zorder=2)
        ax.grid(axis="y", color=COL_GRID, lw=0.48, zorder=0)
        style_nature_box(ax)

        xs_valid, ys_valid = [], []
        rel_xs, rel_lo, rel_hi = [], [], []

        for wi, wk in enumerate(win_order):
            rw = rows[wk]
            cov_str = f"{rw['cov_days']}†" if rw["flagged"] else rw["cov_days"]
            ax.text(wi + (0.08 if wi == 0 else 0.0), 0.5 * (ymin + strip_top), cov_str, ha="center", va="center",
                    fontsize=6.85, color="#9A3412" if rw["flagged"] else COL_MUTED,
                    fontweight="bold" if not rw["flagged"] else "normal", zorder=5)

            if rw["est"] is None:
                ax.scatter([wi], [0], marker="x", s=46, color="#475569", lw=1.6, zorder=5)
                continue

            xs_valid.append(wi)
            ys_valid.append(rw["est"])
            if not rw["flagged"]:
                rel_xs.append(wi)
                rel_lo.append(rw["ci"][0])
                rel_hi.append(rw["ci"][1])

        if len(rel_xs) >= 2:
            ax.fill_between(rel_xs, rel_lo, rel_hi, color=col, alpha=0.14, edgecolor="none", zorder=2)

        if len(xs_valid) >= 2:
            ax.plot(xs_valid, ys_valid, color=col, lw=1.4, ls="--", alpha=0.68, zorder=3)
        if len(rel_xs) >= 2:
            rel_ys = [rows[win_order[x]]["est"] for x in rel_xs]
            ax.plot(rel_xs, rel_ys, color=col, lw=1.85, ls="-", zorder=3)

        for wi, wk in enumerate(win_order):
            rw = rows[wk]
            if rw["est"] is None:
                continue
            est = rw["est"]
            if not rw["flagged"]:
                lo, hi = rw["ci"]
                ax.plot([wi, wi], [lo, hi], color=col, lw=1.75, solid_capstyle="round", zorder=4)
                ax.plot([wi - 0.06, wi + 0.06], [lo, lo], color=col, lw=1.2, zorder=4)
                ax.plot([wi - 0.06, wi + 0.06], [hi, hi], color=col, lw=1.2, zorder=4)
                ax.scatter([wi], [est], s=44, facecolor=col, edgecolor=COL_RIM, lw=0.58, zorder=5)

                if cid == "CP01":
                    ax.text(wi, hi + 2.8, f"{fmt_signed(est)}%", ha="center", va="bottom",
                            fontsize=6.95, fontweight="bold", color=col, zorder=6)
                else:
                    dx_l = 0.12 if wi < 3 else -0.12
                    ha_l = "left" if wi < 3 else "right"
                    ax.text(wi + dx_l, est + 0.048 * (ymax - strip_top), f"{fmt_signed(est)}%",
                            ha=ha_l, va="bottom", fontsize=6.95, fontweight="bold", color=col,
                            bbox=dict(boxstyle="round,pad=0.12", facecolor="white", edgecolor="none", alpha=0.88), zorder=6)
            else:
                ax.scatter([wi], [est], s=42, marker="D", facecolor="white", edgecolor=col, lw=1.45, zorder=5)
                dy_sp = 0.072 * (ymax - strip_top)
                ax.text(wi, est + dy_sp, f"{fmt_signed(est)}%†", ha="center", va="bottom",
                        fontsize=6.95, color=COL_MUTED,
                        bbox=dict(boxstyle="round,pad=0.10", facecolor="white", edgecolor="none", alpha=0.84), zorder=6)

        ax.text(-0.46, 0.5 * (ymin + strip_top), "Pre/post d:" if lang == "en" else "前/后日:",
                ha="left", va="center", fontsize=6.4, color=COL_MUTED, fontweight="bold")

        ax.set_xlim(-0.50, 3.48)
        ax.set_ylim(ymin, ymax)
        ax.set_yticks(yticks)
        ax.set_yticklabels([f"{fmt_signed(v, 0)}%" if v != 0 else "0%" for v in yticks], fontsize=7.55)
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(win_lbls_en if lang == "en" else win_lbls_cn, fontsize=7.45)
        if idx % 2 == 0:
            ax.set_ylabel("Rate change (%)" if lang == "en" else "标准化检测率变化（%）", fontsize=8.05)

        title_nm = c_info["name_en"] if lang == "en" else c_info["name_cn"]
        ax.text(-0.12, 1.042, panel_ltrs[idx], transform=ax.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
        ax.text(-0.04, 1.042, title_nm, transform=ax.transAxes, fontsize=8.45, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mlines.Line2D([], [], marker="o", color=COL_NEG, lw=1.85, markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.55, label="3-day block 95% CI (≥5 d)"),
            mpatches.Patch(facecolor=COL_NEG, alpha=0.16, edgecolor="none", label="95% CI envelope"),
            mlines.Line2D([], [], marker="D", color="#64748B", lw=1.3, ls="--", markerfacecolor="white",
                          markeredgewidth=1.4, markersize=5.5, label="<5 covered days (†)"),
            mlines.Line2D([], [], marker="x", linestyle="None", color="#475569", markeredgewidth=1.6,
                          markersize=5.8, label="Zero post-event coverage"),
        ]
    else:
        handles = [
            mlines.Line2D([], [], marker="o", color=COL_NEG, lw=1.85, markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.55, label="3日块 95% CI（≥5日）"),
            mpatches.Patch(facecolor=COL_NEG, alpha=0.16, edgecolor="none", label="95% 置信带"),
            mlines.Line2D([], [], marker="D", color="#64748B", lw=1.3, ls="--", markerfacecolor="white",
                          markeredgewidth=1.4, markersize=5.5, label="覆盖不足5日（†）"),
            mlines.Line2D([], [], marker="x", linestyle="None", color="#475569", markeredgewidth=1.6,
                          markersize=5.8, label="事件后无覆盖"),
        ]
    leg = fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.52, 0.991),
                     ncol=4, frameon=True, fontsize=7.45, handletextpad=0.42, columnspacing=1.25)
    style_top_legend(leg)

    out_path = resolve_supp_out("supp_fig2", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# SUPP FIG. 3: Annual Global SAR & AIS-Unmatched Share (Nature 2026 bar/interval polish)
# ==============================================================================
def make_supp_fig3(lang="en"):
    set_lang_rc(lang)
    abg = DATA["annual_bg"]
    xs = np.arange(len(abg))
    yr_lbls = [r["year_label"].replace("2026 (H1)", "2026 (H1)" if lang == "en" else "2026（上半年）") for r in abg]
    t5_shares_str = ["50.8%", "50.7%", "49.9%", "46.3%", "44.3%", "41.6%", "37.4%", "34.3%", "36.0%", "39.3%"]

    fig = plt.figure(figsize=(10.4, 6.2), dpi=360, facecolor="white")
    gs = GridSpec(2, 1, figure=fig, height_ratios=[1.12, 1.0], hspace=0.25,
                  left=0.085, right=0.975, top=0.92, bottom=0.09)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[1, 0], sharex=ax1)

    for ax in (ax1, ax2):
        ax.axvline(8.5, color="#475569", lw=0.9, ls="--", zorder=2)
        ax.axvspan(8.5, 9.6, color="#F4F6F9", zorder=0)
        ax.grid(axis="y", color=COL_GRID, lw=0.48, zorder=0)
        style_nature_box(ax)

    w = 0.36
    tot_m = [r["total"] / 1e6 for r in abg]
    unm_m = [r["unmatched"] / 1e6 for r in abg]
    ax1.bar(xs - w/2, tot_m, width=w, color="#2B5B84", edgecolor=COL_RIM, linewidth=0.45,
            label="Total SAR detections" if lang == "en" else "SAR 总检测事件数", zorder=3)
    ax1.bar(xs + w/2, unm_m, width=w, color="#C97A10", edgecolor=COL_RIM, linewidth=0.45,
            label="AIS-unmatched detections" if lang == "en" else "AIS 未匹配检测事件数", zorder=3)

    for i, (tm, um) in enumerate(zip(tot_m, unm_m)):
        ax1.text(i - w/2, tm + 0.08, f"{tm:.2f}", ha="center", va="bottom", fontsize=6.65, color="#1E3A5F", fontweight="bold")
        ax1.text(i + w/2, um + 0.08, f"{um:.2f}", ha="center", va="bottom", fontsize=6.55, color="#92400E")

    v_pill = dict(boxstyle="round,pad=0.14,rounding_size=0.18", facecolor="#F8FAFC", edgecolor="#CBD5E1", lw=0.5)
    ax1.annotate("", xy=(-0.4, 5.42), xytext=(7.45, 5.42),
                 arrowprops=dict(arrowstyle="<->", color="#64748B", lw=0.78))
    ax1.text(3.52, 5.56, "v20231026", ha="center", va="bottom", fontsize=6.7, color=COL_MUTED, bbox=v_pill)
    ax1.text(8.02, 5.56, "pipev3", ha="center", va="bottom", fontsize=6.7, color=COL_MUTED, bbox=v_pill)
    ax1.text(9.03, 5.56, "pipev4", ha="center", va="bottom", fontsize=6.7, color=COL_MUTED, bbox=v_pill)

    ax1.set_ylim(0, 6.22)
    ax1.set_yticks([0, 1, 2, 3, 4, 5])
    ax1.set_ylabel("Detections ($10^6$)" if lang == "en" else "检测事件数（百万次）", fontsize=8.3)
    ax1.tick_params(axis="x", labelbottom=False, length=2.2)
    leg1 = ax1.legend(loc="upper right", bbox_to_anchor=(0.88, 0.84), frameon=True, facecolor="#F8FAFC", edgecolor="#CBD5E1", fontsize=7.3)
    leg1.get_frame().set_linewidth(0.55)
    ax1.text(-0.07, 1.035, "a", transform=ax1.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax1.text(-0.015, 1.035, "Annual SAR detection counts" if lang == "en" else "全球 SAR 年度检测事件数",
             transform=ax1.transAxes, fontsize=8.5, fontweight="bold", va="bottom", ha="left")

    sh = [r["share"] for r in abg]
    ci3_lo = [r["ci3"][0] for r in abg]
    ci3_hi = [r["ci3"][1] for r in abg]
    ci1_lo = [r["ci1"][0] for r in abg]
    ci1_hi = [r["ci1"][1] for r in abg]

    ax2.fill_between(xs[:9], ci3_lo[:9], ci3_hi[:9], color="#1B5E91", alpha=0.15,
                     label="3-month block 95% interval" if lang == "en" else "3个月循环块 95% 探索性区间", zorder=2)
    ax2.plot(xs[:9], sh[:9], color="#1B5E91", lw=1.85, zorder=4)

    for i in range(len(abg)):
        ax2.plot([i, i], [ci3_lo[i], ci3_hi[i]], color="#1B5E91", lw=1.1, alpha=0.78, zorder=3)
        ax2.plot([i - 0.08, i + 0.08], [ci3_lo[i], ci3_lo[i]], color="#1B5E91", lw=1.0, alpha=0.78, zorder=3)
        ax2.plot([i - 0.08, i + 0.08], [ci3_hi[i], ci3_hi[i]], color="#1B5E91", lw=1.0, alpha=0.78, zorder=3)
        ax2.plot([i, i], [ci1_lo[i], ci1_hi[i]], color="#C8472C", lw=2.35, alpha=0.88, zorder=4,
                 label=("1-month block 95% interval" if lang == "en" else "1个月循环块 95% 探索性区间") if i == 0 else None)
        ax2.scatter([i], [sh[i]], s=44, facecolor="#1B5E91" if i < 9 else "#C8472C", edgecolor=COL_RIM, lw=0.6, zorder=5)

        top_y = max(ci3_hi[i], ci1_hi[i])
        ax2.text(i, top_y + 0.75, t5_shares_str[i], ha="center", va="bottom", fontsize=7.05, fontweight="bold",
                 color="#1B5E91" if i < 9 else "#C8472C")

    ax2.set_xlim(-0.55, 9.55)
    ax2.set_ylim(31.5, 56.2)
    ax2.set_yticks([35, 40, 45, 50, 55])
    ax2.set_yticklabels(["35%", "40%", "45%", "50%", "55%"])
    ax2.set_xticks(xs)
    ax2.set_xticklabels(yr_lbls, fontsize=7.8)
    ax2.set_ylabel("AIS-unmatched share (%)" if lang == "en" else "AIS 未匹配占比（%）", fontsize=8.3)
    leg2 = ax2.legend(loc="upper right", bbox_to_anchor=(0.88, 0.96), frameon=True, facecolor="#F8FAFC", edgecolor="#CBD5E1", fontsize=7.3)
    leg2.get_frame().set_linewidth(0.55)
    ax2.text(-0.07, 1.035, "b", transform=ax2.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax2.text(-0.015, 1.035, "Annual AIS-unmatched share" if lang == "en" else "年度 AIS 未匹配占比与探索性区间",
             transform=ax2.transAxes, fontsize=8.5, fontweight="bold", va="bottom", ha="left")

    out_path = resolve_supp_out("supp_fig3", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# SUPP FIG. 4: Daily Observations, 7-Day Rolling Curves & Post-Event Phases
# ==============================================================================
def make_supp_fig4(lang="en"):
    set_lang_rc(lang)
    phases_data = DATA["post_phases"]

    fig = plt.figure(figsize=(10.5, 8.8), dpi=360, facecolor="white")
    gs = GridSpec(4, 1, figure=fig, height_ratios=[1.0, 1.0, 1.0, 1.15], hspace=0.33,
                  left=0.09, right=0.975, top=0.91, bottom=0.065)

    cfgs = [
        ("a", "CP01", "#B23A22", (-76, 15), [-60, -40, -20, 0],
         "Strait of Hormuz" if lang == "en" else "霍尔木兹海峡"),
        ("b", "CP26", "#1B6984", (-135, 455), [-100, 0, 100, 200, 300, 400],
         "Mozambique Channel" if lang == "en" else "莫桑比克海峡"),
        ("c", "CP27", "#3A6B35", (-62, 132), [-50, 0, 50, 100],
         "Cape of Good Hope shipping zone" if lang == "en" else "好望角航运区"),
    ]

    date_ticks = [0, 4, 8, 12, 16, 20, 24, 28]
    date_lbls_en = ["28 Feb", "4 Mar", "8 Mar", "12 Mar", "16 Mar", "20 Mar", "24 Mar", "28 Mar"]
    date_lbls_cn = ["2月28日", "3月4日", "3月8日", "3月12日", "3月16日", "3月20日", "3月24日", "3月28日"]

    axes_daily = []
    for idx, (pltr, cid, col, (ymin, ymax), yts, ptitle) in enumerate(cfgs):
        ax = fig.add_subplot(gs[idx, 0], sharex=axes_daily[0] if axes_daily else None)
        axes_daily.append(ax)

        ax.axvspan(7.5, 14.5, color="#F4F6F9", zorder=0)
        ax.axvline(7.5, color="#94A3B8", lw=0.68, ls=":", zorder=1)
        ax.axvline(14.5, color="#94A3B8", lw=0.68, ls=":", zorder=1)
        ax.axhline(0, color=COL_ZERO, lw=0.85, ls="--", zorder=2)
        ax.grid(axis="y", color=COL_GRID, lw=0.48, zorder=0)
        style_nature_box(ax)

        s4 = SUPP4[cid]
        cov_d = [p["day"] for p in s4["covered"]]
        cov_v = [p["val"] for p in s4["covered"]]
        rol_d = [p["day"] for p in s4["rolling"]]
        rol_v = [p["val"] for p in s4["rolling"]]
        unc_d = s4["uncovered_days"]

        tick_h = 0.068 * (ymax - ymin)
        for ud in unc_d:
            ax.plot([ud, ud], [ymin, ymin + tick_h], color="#64748B", lw=1.35, zorder=3)

        ax.plot(rol_d, rol_v, color=col, lw=1.9, zorder=4)
        ax.scatter(cov_d, cov_v, s=38, facecolor=col, edgecolor=COL_RIM, lw=0.52, zorder=5)

        if idx == 0:
            p_pill = dict(boxstyle="round,pad=0.14,rounding_size=0.18", facecolor="white", edgecolor="#CBD5E1", lw=0.5, alpha=0.92)
            for px_mid, plbl in [(4.0, "Phase 1" if lang == "en" else "阶段 1"),
                                 (11.0, "Phase 2" if lang == "en" else "阶段 2"),
                                 (21.0, "Phase 3" if lang == "en" else "阶段 3")]:
                ax.text(px_mid, ymax - 2.2, plbl, ha="center", va="top", fontsize=6.65, fontweight="bold", color=COL_MUTED, bbox=p_pill, zorder=6)

        ax.set_xlim(-0.4, 28.4)
        ax.set_ylim(ymin, ymax)
        ax.set_yticks(yts)
        ax.set_yticklabels([f"{fmt_signed(v, 0)}" if v != 0 else "0" for v in yts], fontsize=7.55)
        ax.set_ylabel("ΔR (%)" if lang == "en" else "检测率变化（%）", fontsize=8.05)
        ax.set_xticks(date_ticks)
        if idx < 2:
            ax.tick_params(axis="x", labelbottom=False, length=2.2)
        else:
            ax.set_xticklabels(date_lbls_en if lang == "en" else date_lbls_cn, fontsize=7.65)

        ax.text(-0.075, 1.035, pltr, transform=ax.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
        ax.text(-0.015, 1.035, ptitle, transform=ax.transAxes, fontsize=8.4, fontweight="bold", va="bottom", ha="left")

    ax_d = fig.add_subplot(gs[3, 0])
    ax_d.axhline(0, color=COL_ZERO, lw=0.85, ls="--", zorder=2)
    ax_d.grid(axis="y", color=COL_GRID, lw=0.48, zorder=0)
    style_nature_box(ax_d)

    xp = np.array([0, 1, 2])
    offsets = {"CP01": -0.22, "CP26": 0.0, "CP27": 0.22}
    p_cols = {"CP01": "#B23A22", "CP26": "#1B6984", "CP27": "#3A6B35"}
    p_names = {
        "CP01": "Strait of Hormuz" if lang == "en" else "霍尔木兹海峡",
        "CP26": "Mozambique Channel" if lang == "en" else "莫桑比克海峡",
        "CP27": "Cape of Good Hope" if lang == "en" else "好望角航运区",
    }

    for cid in ["CP01", "CP26", "CP27"]:
        pd = phases_data[cid]
        col = p_cols[cid]
        xj = xp + offsets[cid]
        vals = pd["chg"]
        covs = pd["cov_d"]
        ax_d.bar(xj, vals, width=0.19, color=col, alpha=0.26, edgecolor=col, lw=0.95, label=p_names[cid], zorder=3)
        for xi, v, cd in zip(xj, vals, covs):
            sparse = cd < 5
            dag = "†" if sparse else ""
            if sparse:
                ax_d.scatter([xi], [v], s=40, marker="D", facecolor="white", edgecolor=col, lw=1.45, zorder=5)
            else:
                ax_d.scatter([xi], [v], s=42, facecolor=col, edgecolor=COL_RIM, lw=0.55, zorder=5)
            lbl_v = f"{fmt_signed(v)}%{dag}\n({cd} d)" if lang == "en" else f"{fmt_signed(v)}%{dag}\n({cd}日)"
            ty = v + 7.2 if v >= 0 else v - 7.5
            va_p = "bottom" if v >= 0 else "top"
            ax_d.text(xi, ty, lbl_v, ha="center", va=va_p, fontsize=6.6, fontweight="bold", color=col, linespacing=1.08)

    ax_d.set_xlim(-0.55, 2.55)
    ax_d.set_ylim(-74, 88)
    ax_d.set_yticks([-50, -25, 0, 25, 50])
    ax_d.set_yticklabels(["−50", "−25", "0", "+25", "+50"], fontsize=7.55)
    ax_d.set_xticks(xp)
    ax_d.set_xticklabels(
        ["Phase 1 (1–7 Mar)", "Phase 2 (8–14 Mar)", "Phase 3 (15–27 Mar)"] if lang == "en"
        else ["阶段 1（3月1—7日）", "阶段 2（3月8—14日）", "阶段 3（3月15—27日）"],
        fontsize=7.75
    )
    ax_d.set_ylabel("Phase ΔR (%)" if lang == "en" else "分阶段变化（%）", fontsize=8.05)
    leg_d = ax_d.legend(loc="upper right", ncol=3, frameon=True, facecolor="#F8FAFC", edgecolor="#CBD5E1",
                        fontsize=7.05, handletextpad=0.4, columnspacing=0.9)
    leg_d.get_frame().set_linewidth(0.55)
    ax_d.text(-0.075, 1.035, "d", transform=ax_d.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_d.text(-0.015, 1.035, "Post-event phased rate changes" if lang == "en" else "事件后分阶段检测率变化",
              transform=ax_d.transAxes, fontsize=8.4, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", color="#334155", markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.5, label="Covered-day ΔR (%)"),
            mlines.Line2D([], [], color="#334155", lw=1.95, label="7-day rolling ΔR (≥2 d)"),
            mlines.Line2D([], [], marker="|", linestyle="None", color="#64748B", markersize=8, markeredgewidth=1.4, label="Uncovered date"),
            mlines.Line2D([], [], marker="D", linestyle="None", markerfacecolor="white", markeredgecolor="#334155",
                          markeredgewidth=1.4, markersize=5.4, label="<5 covered days (†)"),
        ]
    else:
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", color="#334155", markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.5, label="有覆盖日变化（%）"),
            mlines.Line2D([], [], color="#334155", lw=1.95, label="7日滚动窗口变化（≥2日）"),
            mlines.Line2D([], [], marker="|", linestyle="None", color="#64748B", markersize=8, markeredgewidth=1.4, label="无覆盖日期"),
            mlines.Line2D([], [], marker="D", linestyle="None", markerfacecolor="white", markeredgecolor="#334155",
                          markeredgewidth=1.4, markersize=5.4, label="覆盖不足5日（†）"),
        ]
    leg = fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.53, 0.991),
                     ncol=4, frameon=True, fontsize=7.45, handletextpad=0.42, columnspacing=1.3)
    style_top_legend(leg)

    out_path = resolve_supp_out("supp_fig4", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# SUPP FIG. 5: Cape of Good Hope Dual-Boundary Map (with km scale bar) & Estimation
# ==============================================================================
def make_supp_fig5(lang="en"):
    set_lang_rc(lang)
    cs = DATA["cape_sens"]
    by_id = {c["id"]: c for c in DATA["corridors"]}
    cp27 = by_id["CP27"]

    COL_EXP = "#1B5E91"
    COL_NAR = "#7C3AED"

    fig = plt.figure(figsize=(11.0, 5.1), dpi=360, facecolor="white")
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.22, 0.82, 1.16], wspace=0.28,
                  left=0.058, right=0.98, top=0.835, bottom=0.13)

    ax_a = fig.add_subplot(gs[0, 0])
    ax_a.set_facecolor("#EFF4F9")
    ax_a.fill(SA_LONS, SA_LATS, facecolor="#E3E7EB", edgecolor="#64748B", linewidth=0.85, zorder=1)

    for glon in [14, 20, 26, 32]:
        ax_a.axvline(glon, color="#D8E3ED", lw=0.52, ls=":", zorder=0)
    for glat in [-40, -36, -32, -28]:
        ax_a.axhline(glat, color="#D8E3ED", lw=0.52, ls=":", zorder=0)

    rect_exp = mpatches.Rectangle((14.0, -40.0), 18.0, 11.0, facecolor=(27/255, 94/255, 145/255, 0.08),
                                  edgecolor=COL_EXP, linewidth=2.05, linestyle="-", zorder=3)
    ax_a.add_patch(rect_exp)

    rect_nar = mpatches.Rectangle((15.0, -36.3), 5.5, 4.5, facecolor=(124/255, 58/255, 237/255, 0.12),
                                  edgecolor=COL_NAR, linewidth=1.95, linestyle="--", zorder=4)
    ax_a.add_patch(rect_nar)

    ax_a.text(24.2, -30.8, "South Africa" if lang == "en" else "南非",
              fontsize=8.1, fontweight="bold", color="#334155", ha="center", va="center", zorder=5)
    ax_a.text(17.75, -35.48, "Initial narrow\nboundary" if lang == "en" else "初始窄边界",
              fontsize=6.85, fontweight="bold", color=COL_NAR, ha="center", va="center", zorder=5)
    ax_a.text(26.2, -38.3, "Expanded shipping zone" if lang == "en" else "扩展航运区",
              fontsize=7.2, fontweight="bold", color=COL_EXP, ha="center", va="center", zorder=5)

    # Ohenhen Fig. 2b-m style geodesic 500 km scale bar at 35°S (1° lon = 91.19 km -> 500 km = 5.483° lon)
    sb_x0, sb_x1, sb_y = 13.15, 13.15 + 5.483, -40.68
    ax_a.plot([sb_x0, sb_x1], [sb_y, sb_y], color=COL_FRAME, lw=1.4, zorder=6)
    ax_a.plot([sb_x0, sb_x0], [sb_y - 0.18, sb_y + 0.18], color=COL_FRAME, lw=1.1, zorder=6)
    ax_a.plot([sb_x1, sb_x1], [sb_y - 0.18, sb_y + 0.18], color=COL_FRAME, lw=1.1, zorder=6)
    ax_a.text(0.5 * (sb_x0 + sb_x1), sb_y + 0.22, "500 km", ha="center", va="bottom",
              fontsize=6.4, fontweight="bold", color=COL_FRAME, zorder=6)

    ax_a.set_xlim(12.5, 33.5)
    ax_a.set_ylim(-41.25, -27.5)
    ax_a.set_xticks([14, 20, 26, 32])
    ax_a.set_xticklabels(["14°E", "20°E", "26°E", "32°E"], fontsize=7.8)
    ax_a.set_yticks([-40, -36, -32, -28])
    ax_a.set_yticklabels(["40°S", "36°S", "32°S", "28°S"], fontsize=7.8)
    ax_a.set_xlabel("Longitude (WGS 84)" if lang == "en" else "经度（WGS 84）", fontsize=8.2)
    ax_a.set_ylabel("Latitude (WGS 84)" if lang == "en" else "纬度（WGS 84）", fontsize=8.2)
    style_nature_box(ax_a)

    ax_a.text(-0.14, 1.045, "a", transform=ax_a.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_a.text(-0.05, 1.045, "Spatial boundaries" if lang == "en" else "空间边界范围",
              transform=ax_a.transAxes, fontsize=8.45, fontweight="bold", va="bottom", ha="left")

    # Panel b: Pre/Post paired rates
    ax_b = fig.add_subplot(gs[0, 1])
    ax_b.grid(axis="y", color=COL_GRID, lw=0.48, zorder=0)
    style_nature_box(ax_b)

    nar_rows = [r for r in cs if "narrow" in r["boundary"].lower()]
    exp_rows = [r for r in cs if "Expanded" in r["boundary"]]
    mk_map = {"original_nominal": "o", "half_nominal": "^", "half_spherical": "s"}

    for r in nar_rows:
        is_base = r["algo_code"] == "original_nominal"
        ax_b.plot([0, 1], [r["pre_rate"], r["post_rate"]], color=COL_NAR,
                  lw=1.95 if is_base else 0.85, ls="--" if is_base else ":", alpha=0.95 if is_base else 0.45, zorder=4 if is_base else 2)
        ax_b.scatter([0, 1], [r["pre_rate"], r["post_rate"]], s=44 if is_base else 20,
                     marker=mk_map[r["algo_code"]], facecolor=COL_NAR, edgecolor=COL_RIM if is_base else "none",
                     lw=0.58, alpha=0.95 if is_base else 0.6, zorder=5 if is_base else 3)

    ax_b.plot([0, 0], cp27["pre_ci"], color=COL_EXP, lw=1.65, alpha=0.85, zorder=3)
    ax_b.plot([1, 1], cp27["post_ci"], color=COL_EXP, lw=1.65, alpha=0.85, zorder=3)
    for r in exp_rows:
        is_base = r["algo_code"] == "original_nominal"
        ax_b.plot([0, 1], [r["pre_rate"], r["post_rate"]], color=COL_EXP,
                  lw=1.95 if is_base else 0.85, alpha=0.95 if is_base else 0.45, zorder=4 if is_base else 2)
        ax_b.scatter([0, 1], [r["pre_rate"], r["post_rate"]], s=44 if is_base else 20,
                     marker=mk_map[r["algo_code"]], facecolor=COL_EXP, edgecolor=COL_RIM if is_base else "none",
                     lw=0.58, alpha=0.95 if is_base else 0.6, zorder=5 if is_base else 3)

    ax_b.text(0.5, 1.385, "1.324 → 1.346", ha="center", va="bottom", fontsize=7.05, fontweight="bold", color=COL_NAR)
    ax_b.text(0.5, 0.735, "0.876 → 0.936", ha="center", va="top", fontsize=7.05, fontweight="bold", color=COL_EXP)

    ax_b.set_xlim(-0.30, 1.30)
    ax_b.set_ylim(0.55, 1.52)
    ax_b.set_xticks([0, 1])
    ax_b.set_xticklabels(["Pre-event\n(1–27 Feb)" if lang == "en" else "事件前\n(2月1—27日)",
                          "Post-event\n(1–27 Mar)" if lang == "en" else "事件后\n(3月1—27日)"], fontsize=7.75)
    ax_b.set_ylabel("Detections per $10^3$ km$^2$" if lang == "en" else "标准化检测率 [次/(10³ km²)]", fontsize=8.2)
    ax_b.text(-0.22, 1.045, "b", transform=ax_b.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_b.text(-0.10, 1.045, "Pre- vs. post-event rates" if lang == "en" else "事件前后检测率",
              transform=ax_b.transAxes, fontsize=8.45, fontweight="bold", va="bottom", ha="left")

    ax_c = fig.add_subplot(gs[0, 2])
    ax_c.axvline(0, color=COL_ZERO, lw=0.9, ls="--", zorder=2)
    ax_c.axhline(3.52, color="#64748B", lw=0.82, ls="--", zorder=2)
    ax_c.grid(axis="x", color=COL_GRID, lw=0.48, zorder=0)
    style_nature_box(ax_c)

    ordered_cs = exp_rows + nar_rows
    ys_c = [6, 5, 4, 3, 2, 1]

    for yi, r in zip(ys_c, ordered_cs):
        is_exp = "Expanded" in r["boundary"]
        col = COL_EXP if is_exp else COL_NAR
        if yi % 2 == 0:
            ax_c.axhspan(yi - 0.44, yi + 0.44, color=COL_ZEBRA, zorder=0)

        ax_c.plot(r["ci1"], [yi + 0.19, yi + 0.19], color="#94A3B8", lw=1.1, zorder=3)
        ax_c.plot(r["ci3"], [yi, yi], color=col, lw=2.15, solid_capstyle="round", zorder=4)
        ax_c.plot([r["ci3"][0], r["ci3"][0]], [yi - 0.12, yi + 0.12], color=col, lw=1.25, zorder=4)
        ax_c.plot([r["ci3"][1], r["ci3"][1]], [yi - 0.12, yi + 0.12], color=col, lw=1.25, zorder=4)
        ax_c.plot(r["ci7"], [yi - 0.19, yi - 0.19], color="#64748B", lw=1.1, ls="-.", zorder=3)

        ax_c.scatter([r["chg_precise"]], [yi], s=44, marker=mk_map[r["algo_code"]],
                     facecolor=col, edgecolor=COL_RIM, lw=0.58, zorder=5)

        lbl_r = f"+{r['chg_disp']:.1f}% [{fmt_signed(r['ci3'][0])}, +{r['ci3'][1]:.1f}]"
        ax_c.text(r["ci3"][1] + 1.4, yi, lbl_r, va="center", ha="left", fontsize=6.7,
                  fontweight="bold" if r["algo_code"] == "original_nominal" else "normal", color=col)

    pill_c = dict(boxstyle="round,pad=0.14,rounding_size=0.18", facecolor="#F8FAFC", edgecolor="#CBD5E1", lw=0.5)
    ax_c.text(50.5, 6.68, "Expanded zone" if lang == "en" else "扩展航运区",
              fontsize=6.8, fontweight="bold", color=COL_EXP, va="top", ha="right", bbox=pill_c, zorder=6)
    ax_c.text(50.5, 3.44, "Narrow boundary" if lang == "en" else "初始窄边界",
              fontsize=6.8, fontweight="bold", color=COL_NAR, va="top", ha="right", bbox=pill_c, zorder=6)

    ax_c.set_yticks(ys_c)
    yl_c = (["Baseline grid", "Halved grid", "Spherical grid", "Baseline grid", "Halved grid", "Spherical grid"] if lang == "en"
            else ["基准网格", "间距减半网格", "球面加权网格", "基准网格", "间距减半网格", "球面加权网格"])
    ax_c.set_yticklabels(yl_c, fontsize=7.5)
    ax_c.set_xlim(-24, 52)
    ax_c.set_ylim(0.35, 6.82)
    ax_c.set_xticks([-20, 0, 20, 40])
    ax_c.set_xticklabels(["−20%", "0%", "+20%", "+40%"])
    ax_c.set_xlabel("Rate change ΔR & 95% CI (%)" if lang == "en" else "检测率变化 ΔR 及 95% 置信区间（%）", fontsize=8.2)
    ax_c.text(-0.26, 1.045, "c", transform=ax_c.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_c.text(-0.16, 1.045, "Boundary, grid & block sensitivity" if lang == "en" else "边界、网格与块长敏感性",
              transform=ax_c.transAxes, fontsize=8.45, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mpatches.Patch(facecolor=(27/255, 94/255, 145/255, 0.14), edgecolor=COL_EXP, lw=1.7, label="Expanded shipping zone"),
            mpatches.Patch(facecolor=(124/255, 58/255, 237/255, 0.16), edgecolor=COL_NAR, lw=1.7, ls="--", label="Initial narrow boundary"),
            mlines.Line2D([], [], marker="o", color=COL_EXP, lw=2.15, markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.55, label="3-day block 95% CI"),
            mlines.Line2D([], [], color="#94A3B8", lw=1.2, label="1-day block 95% CI"),
            mlines.Line2D([], [], color="#64748B", lw=1.2, ls="-.", label="7-day block 95% CI"),
        ]
    else:
        handles = [
            mpatches.Patch(facecolor=(27/255, 94/255, 145/255, 0.14), edgecolor=COL_EXP, lw=1.7, label="扩展航运区"),
            mpatches.Patch(facecolor=(124/255, 58/255, 237/255, 0.16), edgecolor=COL_NAR, lw=1.7, ls="--", label="初始窄边界"),
            mlines.Line2D([], [], marker="o", color=COL_EXP, lw=2.15, markersize=5.6,
                          markeredgecolor=COL_RIM, markeredgewidth=0.55, label="3日块 95% CI"),
            mlines.Line2D([], [], color="#94A3B8", lw=1.2, label="1日块 95% CI"),
            mlines.Line2D([], [], color="#64748B", lw=1.2, ls="-.", label="7日块 95% CI"),
        ]
    leg = fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.52, 0.991),
                     ncol=5, frameon=True, fontsize=7.45, handletextpad=0.42, columnspacing=1.2)
    style_top_legend(leg)

    out_path = resolve_supp_out("supp_fig5", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)

if __name__ == "__main__":
    for lg in ("en", "cn"):
        make_supp_fig1(lg)
        make_supp_fig2(lg)
        make_supp_fig3(lg)
        make_supp_fig4(lg)
        make_supp_fig5(lg)
