#!/usr/bin/env python3
"""
Standalone generator for Main Figures 1–4 (English & Chinese, 360 DPI).
Uses only relative repository paths and pure-Python GeoJSON PathPatch rendering
(zero hard dependency on GDAL/GeoPandas, with automatic cross-platform font detection).
"""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.font_manager as fm
from matplotlib.gridspec import GridSpec
from matplotlib.path import Path as MplPath
from matplotlib.patches import PathPatch

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(REPO_ROOT, "data")
FONTS_DIR = os.path.join(REPO_ROOT, "fonts")

for fn in sorted(os.listdir(FONTS_DIR)) if os.path.isdir(FONTS_DIR) else []:
    if fn.lower().endswith((".otf", ".ttf", ".ttc")):
        fm.fontManager.addfont(os.path.join(FONTS_DIR, fn))

with open(os.path.join(DATA_DIR, "master_data.json"), encoding="utf-8") as f:
    DATA = json.load(f)

OUT_DIR = os.environ.get("GFW_FIG_OUT_DIR", os.path.join(REPO_ROOT, "figures"))
os.makedirs(OUT_DIR, exist_ok=True)

OUT_NAME_MAP = {
    ("fig1", "en"): "English_Main/Fig1_Coverage_Normalization_and_95CI.png",
    ("fig2", "en"): "English_Main/Fig2_Global_Map_and_Focal_Estimation.png",
    ("fig3", "en"): "English_Main/Fig3_Historical_Baselines_and_2026_CI.png",
    ("fig4", "en"): "English_Main/Fig4_AIS_Stratified_Estimation.png",
    ("fig1", "cn"): "Chinese_Main/图1_覆盖标准化位移与95置信区间.png",
    ("fig2", "cn"): "Chinese_Main/图2_全球空间格局与重点通道配对估计.png",
    ("fig3", "cn"): "Chinese_Main/图3_历史同期范围与2026区间对比.png",
    ("fig4", "cn"): "Chinese_Main/图4_AIS分层检测率与未匹配占比净差估计.png",
}

def resolve_out_path(fig_key, lang):
    rel = OUT_NAME_MAP[(fig_key, lang)]
    full = os.path.join(OUT_DIR, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    return full

def plot_world_land_110m(ax):
    geojson_path = os.path.join(DATA_DIR, "basemaps", "naturalearth_110m_land.geojson")
    with open(geojson_path, encoding="utf-8") as f:
        gj = json.load(f)
    mp_coords = gj["features"][0]["geometry"]["coordinates"]
    verts, codes = [], []
    for poly_rings in mp_coords:
        for ring in poly_rings:
            if len(ring) < 3:
                continue
            verts.extend(ring)
            codes.append(MplPath.MOVETO)
            codes.extend([MplPath.LINETO] * (len(ring) - 2))
            codes.append(MplPath.CLOSEPOLY)
    patch = PathPatch(MplPath(verts, codes), facecolor="#E5E9EC", edgecolor="#9AA5B1", linewidth=0.55, zorder=1)
    ax.add_patch(patch)

COL_POS = "#C8472C"
COL_POS_SOFT = "#E59886"
COL_NEG = "#1B5E91"
COL_NEG_SOFT = "#7AA6C7"
COL_RAW = "#5B6878"
COL_REV = "#1E293B"
COL_REV_BG = "#FFF6EB"
COL_ZEBRA = "#F6F8FB"
COL_ZERO = "#334155"
COL_TEXT = "#111827"
COL_MUTED = "#475569"
COL_GRID = "#E2E8F0"
COL_MATCH = "#1B5E91"
COL_UNMATCH = "#C97A10"

def set_lang_rc(lang="en"):
    plt.rcParams.update(plt.rcParamsDefault)
    if lang == "cn":
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "SimHei", "WenQuanYi Micro Hei", "Liberation Sans", "Arial", "DejaVu Sans"]
    else:
        plt.rcParams["font.family"] = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["Liberation Sans", "Arial", "Helvetica", "Noto Sans CJK SC", "PingFang SC", "Microsoft YaHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["axes.edgecolor"] = "#64748B"
    plt.rcParams["axes.linewidth"] = 0.8
    plt.rcParams["xtick.color"] = "#334155"
    plt.rcParams["ytick.color"] = "#334155"
    plt.rcParams["xtick.labelsize"] = 8.0
    plt.rcParams["ytick.labelsize"] = 8.0
    plt.rcParams["text.color"] = COL_TEXT

def fmt_signed(val, decimals=1):
    sign = "+" if val > 0 else ("−" if val < 0 else "")
    return f"{sign}{abs(val):.{decimals}f}"

# ==============================================================================
# MAIN FIG. 1: Necessary structural/numeric labels kept, narrative prose removed
# ==============================================================================
def make_fig1(lang="en"):
    set_lang_rc(lang)
    corridors = DATA["corridors"]
    n = len(corridors)
    ys = [n - i for i in range(n)]
    y_med = -0.45

    fig = plt.figure(figsize=(11.0, 8.4), dpi=360, facecolor="white")
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.06, 1.24], wspace=0.06,
                  left=0.252, right=0.985, top=0.905, bottom=0.075)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1], sharey=ax1)

    for idx, c in enumerate(corridors):
        y = ys[idx]
        if c["is_sign_reversal"]:
            for ax in (ax1, ax2):
                ax.axhspan(y - 0.46, y + 0.46, color=COL_REV_BG, alpha=0.85, zorder=0)
        elif idx % 2 == 0:
            for ax in (ax1, ax2):
                ax.axhspan(y - 0.46, y + 0.46, color=COL_ZEBRA, alpha=0.9, zorder=0)

    for s_idx in [6, 16, 24]:
        y_sep = ys[s_idx] - 0.5
        for ax in (ax1, ax2):
            ax.axhline(y_sep, color="#CBD5E1", lw=0.75, ls="--", zorder=1)

    for ax in (ax1, ax2):
        ax.axhline(0.32, color="#94A3B8", lw=0.9, ls="-", zorder=2)
        ax.axhspan(y_med - 0.45, y_med + 0.45, color="#EEF2F6", alpha=0.95, zorder=0)
        ax.axvline(0, color=COL_ZERO, lw=1.0, ls="--", zorder=2)
        ax.grid(axis="x", color=COL_GRID, lw=0.6, zorder=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    for idx, c in enumerate(corridors):
        y = ys[idx]
        raw_v, norm_v = c["cnt_chg"], c["rate_chg"]
        col_n = COL_POS if norm_v >= 0 else COL_NEG

        if c["is_sign_reversal"]:
            ax1.plot([raw_v, norm_v], [y, y], color=COL_REV, lw=1.9, zorder=3)
            dx = norm_v - raw_v
            if abs(dx) > 6:
                ax1.annotate("", xy=(norm_v - np.sign(dx)*1.8, y), xytext=(raw_v + np.sign(dx)*1.8, y),
                             arrowprops=dict(arrowstyle="->,head_width=0.22,head_length=0.28",
                                             color=COL_REV, lw=1.5), zorder=3)
        else:
            ax1.plot([raw_v, norm_v], [y, y], color="#94A3B8", lw=1.15, zorder=3)

        ax1.scatter([raw_v], [y], s=40, facecolors="white", edgecolors=COL_RAW, linewidths=1.35, zorder=4)
        if c["flagged"]:
            ax1.scatter([norm_v], [y], s=42, marker="D", facecolors="white", edgecolors=col_n, linewidths=1.5, zorder=5)
        else:
            ax1.scatter([norm_v], [y], s=46, facecolors=col_n, edgecolors="white", linewidths=0.5, zorder=5)

    # Pure numeric values on median row (no narrative parenthetical!)
    ax1.plot([12.5, 4.6], [y_med, y_med], color=COL_REV, lw=2.0, zorder=3)
    ax1.scatter([12.5], [y_med], s=48, facecolors="white", edgecolors=COL_RAW, linewidths=1.5, zorder=4)
    ax1.scatter([4.6], [y_med], s=54, facecolors=COL_POS, edgecolors="white", linewidths=0.6, zorder=5)
    ax1.text(16.0, y_med, "+12.5% → +4.6%", va="center", ha="left", fontsize=7.4, fontweight="bold", color=COL_REV)

    ax1.set_xlim(-86, 94)
    ax1.set_xticks([-80, -60, -40, -20, 0, 20, 40, 60, 80])
    ax1.set_xticklabels(["−80", "−60", "−40", "−20", "0", "+20", "+40", "+60", "+80"])
    ax1.set_xlabel("Post- vs. pre-event change (%)" if lang == "en" else "事件后相对事件前变化（%）",
                   fontsize=8.8, labelpad=6)

    X2_MIN, X2_MAX = -105, 292
    ax2.axvline(232, color="#CBD5E1", lw=0.8, ls="-", zorder=2)
    ax2.axvspan(232, X2_MAX, color="#F8FAFC", alpha=0.95, zorder=1)

    for idx, c in enumerate(corridors):
        y = ys[idx]
        est = c["rate_chg"]
        lo, hi = c["rc_ci"]
        is_pos = est >= 0
        base_col = COL_POS if is_pos else COL_NEG

        if c["flagged"]:
            ax2.scatter([est], [y], s=42, marker="D", facecolors="white", edgecolors=base_col, linewidths=1.5, zorder=5)
            ax2.text(est + 5.8, y, "†", va="center", ha="left", fontsize=8.0, fontweight="bold", color="#64748B", zorder=6)
        else:
            excludes_zero = (lo > 0) or (hi < 0)
            ci_col = base_col if excludes_zero else (COL_POS_SOFT if is_pos else COL_NEG_SOFT)
            lw_ci = 2.1 if excludes_zero else 1.35
            ax2.plot([lo, hi], [y, y], color=ci_col, lw=lw_ci, solid_capstyle="round", zorder=3)
            if excludes_zero:
                ax2.plot([lo, lo], [y - 0.16, y + 0.16], color=ci_col, lw=1.3, zorder=3)
                ax2.plot([hi, hi], [y - 0.16, y + 0.16], color=ci_col, lw=1.3, zorder=3)
                ax2.scatter([est], [y], s=50, facecolors=base_col, edgecolors="white", linewidths=0.6, zorder=5)
            else:
                ax2.scatter([est], [y], s=38, facecolors=base_col, edgecolors="white", linewidths=0.5, alpha=0.9, zorder=5)

        cov_txt = f"{c['cov_days']}†" if c["flagged"] else c["cov_days"]
        cov_col = "#9A3412" if c["flagged"] else COL_MUTED
        ax2.text(262, y, cov_txt, va="center", ha="center", fontsize=7.4,
                 fontweight="bold" if (c["is_focal"] or c["flagged"]) else "normal",
                 color=cov_col, zorder=6)

    # Pure key numbers only
    ax2.text(-56.5, ys[0], "−36.7%", va="center", ha="right", fontsize=7.3, fontweight="bold", color=COL_NEG)
    ax2.scatter([4.6], [y_med], s=50, facecolors=COL_POS, edgecolors="white", linewidths=0.6, zorder=5)
    ax2.text(12.0, y_med, "+4.6%", va="center", ha="left", fontsize=7.3, fontweight="bold", color=COL_POS)
    ax2.text(262, y_med, "27/27", va="center", ha="center", fontsize=7.3, color=COL_MUTED)

    hdr_cov = "Pre/post\ncovered d" if lang == "en" else "前/后\n覆盖日数"
    ax2.text(262, n + 0.62, hdr_cov, va="bottom", ha="center", fontsize=7.5, fontweight="bold", color=COL_TEXT, linespacing=1.15)

    ax2.set_xlim(X2_MIN, X2_MAX)
    ax2.set_xticks([-100, -50, 0, 50, 100, 150, 200])
    ax2.set_xticklabels(["−100", "−50", "0", "+50", "+100", "+150", "+200"])
    ax2.set_xlabel("Coverage-normalized rate change & 95% CI (%)" if lang == "en" else "覆盖标准化检测率变化及 95% 置信区间（%）",
                   fontsize=8.8, labelpad=6)

    y_ticks = ys + [y_med]
    y_labels = ([c["short_en"] for c in corridors] + ["27-corridor median"]) if lang == "en" else ([c["name_cn"] for c in corridors] + ["27通道中位数"])
    ax1.set_yticks(y_ticks)
    ax1.set_yticklabels(y_labels, fontsize=8.0)
    for tick_lbl, c in zip(ax1.get_yticklabels()[:-1], corridors):
        if c["is_focal"]:
            tick_lbl.set_fontweight("bold")
            tick_lbl.set_color("#0F172A")
    ax1.get_yticklabels()[-1].set_fontweight("bold")
    ax1.set_ylim(y_med - 0.65, n + 0.65)
    ax1.spines["left"].set_visible(False)
    ax1.tick_params(axis="y", length=0, pad=6)
    ax2.spines["left"].set_color("#CBD5E1")
    ax2.tick_params(axis="y", labelleft=False, length=0)

    trans = ax1.get_yaxis_transform()
    bx_out, bx_in = (-0.455, -0.432) if lang == "en" else (-0.365, -0.342)
    for g_en, g_cn, idx_start, idx_end in DATA["macro_groups"]:
        y_top = ys[idx_start] + 0.32
        y_bot = ys[idx_end] - 0.32
        y_mid = 0.5 * (y_top + y_bot)
        ax1.plot([bx_in, bx_out, bx_out, bx_in], [y_top, y_top, y_bot, y_bot],
                 transform=trans, clip_on=False, color="#64748B", lw=0.95)
        lbl_g = g_en.replace("–", "–\n") if lang == "en" else g_cn.replace("—", "—\n")
        ax1.text(bx_out - 0.015, y_mid, lbl_g, transform=trans, clip_on=False,
                 va="center", ha="right", fontsize=7.3, color=COL_MUTED, linespacing=1.15)

    # Concise structural panel noun labels (3–4 words, Nature EarthArXiv style)
    ax1.text(-0.04, 1.022, "a", transform=ax1.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax1.text(0.02, 1.022, "Raw vs. normalized shift" if lang == "en" else "覆盖标准化前后位移",
             transform=ax1.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    ax2.text(-0.02, 1.022, "b", transform=ax2.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax2.text(0.035, 1.022, "Normalized rate Δ & 95% CI" if lang == "en" else "标准化率变化与 95% CI",
             transform=ax2.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=6.2, markerfacecolor="white",
                          markeredgecolor=COL_RAW, markeredgewidth=1.35, label="Raw count"),
            mlines.Line2D([], [], color=COL_REV, lw=1.9, label="Sign reversal"),
            mlines.Line2D([], [], marker="o", color=COL_POS, lw=2.0, markersize=6.2, label="Increase (95% CI excl. 0)"),
            mlines.Line2D([], [], marker="o", color=COL_NEG, lw=2.0, markersize=6.2, label="Decrease (95% CI excl. 0)"),
            mlines.Line2D([], [], marker="o", color="#94A3B8", lw=1.35, markersize=5.5, label="95% CI spans 0"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.8, markerfacecolor="white",
                          markeredgecolor=COL_NEG, markeredgewidth=1.4, label="<5 covered days (†)"),
        ]
    else:
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=6.2, markerfacecolor="white",
                          markeredgecolor=COL_RAW, markeredgewidth=1.35, label="原始检测次数"),
            mlines.Line2D([], [], color=COL_REV, lw=1.9, label="方向反转"),
            mlines.Line2D([], [], marker="o", color=COL_POS, lw=2.0, markersize=6.2, label="增长（95% CI 不跨零）"),
            mlines.Line2D([], [], marker="o", color=COL_NEG, lw=2.0, markersize=6.2, label="下降（95% CI 不跨零）"),
            mlines.Line2D([], [], marker="o", color="#94A3B8", lw=1.35, markersize=5.5, label="95% CI 跨零"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.8, markerfacecolor="white",
                          markeredgecolor=COL_NEG, markeredgewidth=1.4, label="覆盖不足5日（†）"),
        ]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.56, 0.99),
               ncol=6, frameon=False, fontsize=7.6, handletextpad=0.45, columnspacing=1.15)

    out_path = resolve_out_path("fig1", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# MAIN FIG. 2: Necessary structural & numeric labels kept, narrative boxes out!
# ==============================================================================
def get_tier_style(val):
    av = abs(val)
    if val >= 0:
        if av <= 10:   return "#F3B097", 52
        elif av <= 25: return "#E27658", 88
        elif av <= 50: return "#C8472C", 132
        else:          return "#7F1D1D", 185
    else:
        if av <= 10:   return "#99C1DE", 52
        elif av <= 25: return "#4C87B4", 88
        elif av <= 50: return "#1B5E91", 132
        else:          return "#0A3254", 185

def make_fig2(lang="en"):
    set_lang_rc(lang)
    corridors = DATA["corridors"]
    by_id = {c["id"]: c for c in corridors}

    # Uses bundled Natural Earth 1:110m GeoJSON

    fig = plt.figure(figsize=(11.0, 8.2), dpi=360, facecolor="white")
    gs = GridSpec(2, 2, figure=fig, height_ratios=[1.48, 1.0], width_ratios=[1.04, 1.13],
                  hspace=0.33, wspace=0.37, left=0.062, right=0.978, top=0.952, bottom=0.075)

    ax_map = fig.add_subplot(gs[0, :])
    ax_map.set_facecolor("#EAF2F8")
    plot_world_land_110m(ax_map)

    for glon in [-120, -60, 0, 60, 120]:
        ax_map.axvline(glon, color="#D5E3EE", lw=0.55, zorder=0)
    for glat in [-60, -30, 0, 30, 60]:
        ax_map.axhline(glat, color="#D5E3EE", lw=0.55, zorder=0)

    ax_map.plot([60, 58, 52, 42, 30], [70, 58, 46, 42, 41], color="#64748B", lw=0.95, ls="--", zorder=2)
    ax_map.plot([32.5, 34.0], [31.5, 29.5], color="#64748B", lw=0.95, ls="--", zorder=2)
    ax_map.plot([130, 132, 128, 124], [3, -4, -9, -13], color="#64748B", lw=0.95, ls="--", zorder=2)

    if lang == "en":
        cont_lbls = [(-103, 46, "NORTH AMERICA"), (-60, -18, "SOUTH AMERICA"), (16, 51, "EUROPE"),
                     (18, 10, "AFRICA"), (88, 49, "ASIA"), (135, -25, "OCEANIA")]
        ocean_lbls = [(-138, -5, "Pacific Ocean"), (-33, 13, "Atlantic Ocean"), (80, -28, "Indian Ocean"),
                      (156, 8, "Pacific Ocean"), (2, -57, "Southern Ocean")]
    else:
        cont_lbls = [(-103, 46, "北美洲"), (-60, -18, "南美洲"), (16, 51, "欧洲"),
                     (18, 10, "非洲"), (88, 49, "亚洲"), (135, -25, "大洋洲")]
        ocean_lbls = [(-138, -5, "太平洋"), (-33, 13, "大西洋"), (80, -28, "印度洋"),
                      (156, 8, "太平洋"), (2, -57, "南大洋")]

    for x, y, t in cont_lbls:
        ax_map.text(x, y, t, fontsize=7.3, fontweight="bold", color="#52606D", ha="center", va="center", zorder=2)
    for x, y, t in ocean_lbls:
        ax_map.text(x, y, t, fontsize=7.2, style="italic" if lang == "en" else "normal",
                    color="#5B7890", ha="center", va="center", zorder=2)

    order = sorted(corridors, key=lambda c: (c["is_focal"], abs(c["rate_chg"])))
    for c in order:
        col, sz = get_tier_style(c["rate_chg"])
        ax_map.scatter([c["lon"]], [c["lat"]], s=sz, facecolor=col, edgecolor="white", linewidth=1.1, zorder=4)
        if c["flagged"]:
            ax_map.scatter([c["lon"]], [c["lat"]], s=sz * 1.48, facecolor="none", edgecolor="#334155",
                           linewidth=0.85, linestyle=":", zorder=5)

    focal_callouts = [
        ("CP01", (88, 30.5), "left",
         "Strait of Hormuz\n−36.7% [−53.8, −15.8]" if lang == "en" else "霍尔木兹海峡\n−36.7% [−53.8, −15.8]"),
        ("CP02", (-2, -2.5), "right",
         "Bab el-Mandeb Strait\n−23.9%†" if lang == "en" else "曼德海峡\n−23.9%†"),
        ("CP26", (76, -15.5), "left",
         "Mozambique Channel\n+37.9% [−27.6, +164.0]" if lang == "en" else "莫桑比克海峡\n+37.9% [−27.6, +164.0]"),
        ("CP27", (52, -48.5), "left",
         "Cape of Good Hope zone\n+6.9% [−9.6, +27.3]" if lang == "en" else "好望角航运区\n+6.9% [−9.6, +27.3]"),
    ]
    for cid, (tx, ty), ha_dir, txt in focal_callouts:
        fc = by_id[cid]
        bcol = COL_POS if fc["rate_chg"] >= 0 else COL_NEG
        ax_map.annotate(
            txt, xy=(fc["lon"], fc["lat"]), xytext=(tx, ty),
            ha=ha_dir, va="center", fontsize=7.3, fontweight="bold", color=COL_TEXT,
            bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor=bcol, alpha=0.94, lw=0.95),
            arrowprops=dict(arrowstyle="-", color="#334155", lw=0.9, shrinkA=0, shrinkB=4),
            zorder=6
        )

    ax_map.set_xlim(-168, 176)
    ax_map.set_ylim(-64, 72)
    ax_map.set_aspect("auto")
    ax_map.set_xticks([-120, -60, 0, 60, 120])
    ax_map.set_xticklabels(["120°W", "60°W", "0°", "60°E", "120°E"], fontsize=7.8)
    ax_map.set_yticks([-60, -30, 0, 30, 60])
    ax_map.set_yticklabels(["60°S", "30°S", "0°", "30°N", "60°N"], fontsize=7.8)
    for sp in ax_map.spines.values():
        sp.set_visible(True); sp.set_color("#64748B"); sp.set_linewidth(0.85)

    leg_box = ax_map.inset_axes([0.012, 0.03, 0.44, 0.25])
    leg_box.set_facecolor((1, 1, 1, 0.92))
    for sp in leg_box.spines.values():
        sp.set_color("#CBD5E1"); sp.set_linewidth(0.7)
    leg_box.set_xticks([]); leg_box.set_yticks([])
    leg_box.set_xlim(0, 10); leg_box.set_ylim(0, 3.1)
    t_hdr = "Rate change ΔR (%)" if lang == "en" else "检测率变化 ΔR（%）"
    leg_box.text(0.25, 2.55, t_hdr, fontsize=6.9, fontweight="bold", va="center", ha="left")
    leg_box.scatter([7.85], [2.55], s=36, facecolor="none", edgecolor="#334155", lw=0.9, linestyle=":")
    leg_box.text(8.15, 2.55, "<5 d (†)" if lang == "en" else "<5日 (†)", fontsize=6.6, color=COL_MUTED, va="center", ha="left")

    tiers_lbl = ["≤10%", ">10–25%", ">25–50%", ">50%"]
    pos_cols = ["#F3B097", "#E27658", "#C8472C", "#7F1D1D"]
    neg_cols = ["#99C1DE", "#4C87B4", "#1B5E91", "#0A3254"]
    szs = [26, 44, 66, 92]
    leg_box.text(0.25, 1.52, "Inc. (+)" if lang == "en" else "增加 (+)", fontsize=6.8, fontweight="bold", color=COL_POS, va="center")
    leg_box.text(0.25, 0.58, "Dec. (−)" if lang == "en" else "下降 (−)", fontsize=6.8, fontweight="bold", color=COL_NEG, va="center")
    for xt, tl, pc, nc, s_i in zip([2.05, 4.15, 6.45, 8.55], tiers_lbl, pos_cols, neg_cols, szs):
        leg_box.scatter([xt], [1.52], s=s_i, facecolor=pc, edgecolor="white", lw=0.7)
        leg_box.scatter([xt], [0.58], s=s_i, facecolor=nc, edgecolor="white", lw=0.7)
        leg_box.text(xt + 0.35, 1.05, tl, fontsize=6.5, va="center", ha="left", color=COL_TEXT)

    ax_map.text(-0.042, 1.02, "a", transform=ax_map.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_map.text(-0.005, 1.02, "Global spatial pattern" if lang == "en" else "全球空间格局",
                transform=ax_map.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    # --- Panel b: Paired Pre/Post Rates WITH concise numeric rate values (NO off-scale narrative box!) ---
    ax_b = fig.add_subplot(gs[1, 0])
    t1_ids_main = ["CP01", "CP13", "CP02", "CP27", "CP26"]
    palette_b = {"CP01": COL_NEG, "CP13": "#475569", "CP02": "#4C87B4", "CP27": "#B45309", "CP26": COL_POS}
    jit = {"CP01": -0.03, "CP13": 0.0, "CP02": 0.03, "CP27": -0.02, "CP26": 0.02}

    ax_b.grid(axis="y", color=COL_GRID, lw=0.6, zorder=0)
    ax_b.spines["top"].set_visible(False)
    ax_b.spines["right"].set_visible(False)

    for cid in t1_ids_main:
        c = by_id[cid]
        col = palette_b[cid]
        xp0, xp1 = 0.0 + jit[cid], 1.0 + jit[cid]
        ax_b.plot([xp0, xp1], [c["pre_rate"], c["post_rate"]], color=col, lw=1.7,
                  ls="--" if c["flagged"] else "-", zorder=3)
        if c["pre_ci"][0] is not None:
            ax_b.plot([xp0, xp0], c["pre_ci"], color=col, lw=1.5, alpha=0.8, zorder=3)
            ax_b.scatter([xp0], [c["pre_rate"]], s=40, facecolor=col, edgecolor="white", lw=0.6, zorder=4)
        else:
            ax_b.scatter([xp0], [c["pre_rate"]], s=40, marker="D", facecolor="white", edgecolor=col, lw=1.4, zorder=4)
        if c["post_ci"][0] is not None:
            ax_b.plot([xp1, xp1], c["post_ci"], color=col, lw=1.5, alpha=0.8, zorder=3)
            ax_b.scatter([xp1], [c["post_rate"]], s=40, facecolor=col, edgecolor="white", lw=0.6, zorder=4)
        else:
            ax_b.scatter([xp1], [c["post_rate"]], s=40, marker="D", facecolor="white", edgecolor=col, lw=1.4, zorder=4)

    lbl_pos_y = {"CP01": 10.9, "CP13": 5.75, "CP02": 3.45, "CP27": 1.62, "CP26": 0.12}
    short_b_en = {"CP01": "Hormuz", "CP13": "Malacca", "CP02": "Bab el-Mandeb", "CP27": "Cape of Good Hope", "CP26": "Mozambique"}
    for cid in t1_ids_main:
        c = by_id[cid]
        col = palette_b[cid]
        nm = short_b_en[cid] if lang == "en" else c["name_cn"]
        dag = "†" if c["flagged"] else ""
        if c["pre_rate"] < 2.0:
            txt = f"{nm}  {c['pre_rate']:.3f}→{c['post_rate']:.3f}{dag}"
        else:
            txt = f"{nm}  {c['pre_rate']:.2f}→{c['post_rate']:.2f}{dag}"
        ax_b.text(1.06, lbl_pos_y[cid], txt, fontsize=6.95, fontweight="bold" if c["is_focal"] else "normal",
                  color=col, va="center", ha="left")

    ax_b.set_xlim(-0.18, 2.08)
    ax_b.set_ylim(-0.6, 20.2)
    ax_b.set_xticks([0.0, 1.0])
    ax_b.set_xticklabels(["Pre-event\n(1–27 Feb)" if lang == "en" else "事件前\n(2月1—27日)",
                          "Post-event\n(1–27 Mar)" if lang == "en" else "事件后\n(3月1—27日)"], fontsize=7.8)
    ax_b.set_ylabel("Detections per $10^3$ km$^2$ (95% CI)" if lang == "en" else "标准化检测率 [次/(10³ km²)]", fontsize=8.3)
    ax_b.text(-0.14, 1.035, "b", transform=ax_b.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_b.text(-0.04, 1.035, "Pre- vs. post-event rates" if lang == "en" else "事件前后标准化检测率",
              transform=ax_b.transAxes, fontsize=8.5, fontweight="bold", va="bottom", ha="left")

    # --- Panel c: Table 1 Effect Magnitude ΔR (%), 95% CI & Multi-Grid Robustness ---
    ax_c = fig.add_subplot(gs[1, 1])
    t1_all = ["CP01", "CP02", "CP13", "CP19", "CP26", "CP27"]
    yc_vals = list(range(len(t1_all), 0, -1))

    ax_c.axvline(0, color=COL_ZERO, lw=1.0, ls="--", zorder=2)
    ax_c.grid(axis="x", color=COL_GRID, lw=0.6, zorder=0)
    ax_c.spines["top"].set_visible(False)
    ax_c.spines["right"].set_visible(False)

    for yi, cid in zip(yc_vals, t1_all):
        c = by_id[cid]
        if yi % 2 == 0:
            ax_c.axhspan(yi - 0.42, yi + 0.42, color=COL_ZEBRA, zorder=0)
        col = COL_POS if c["rate_chg"] >= 0 else COL_NEG
        lo, hi = c["rc_ci"]
        if not c["flagged"]:
            excl = (lo > 0) or (hi < 0)
            ax_c.plot([lo, hi], [yi, yi], color=col if excl else (COL_POS_SOFT if c["rate_chg"]>=0 else COL_NEG_SOFT),
                      lw=2.2 if excl else 1.5, solid_capstyle="round", zorder=3)
            ax_c.scatter([c["grid_base"]], [yi], s=48, facecolor=col, edgecolor="white", lw=0.6, zorder=5)
        else:
            ax_c.scatter([c["grid_base"]], [yi], s=44, marker="D", facecolor="white", edgecolor=col, lw=1.5, zorder=5)

        ax_c.scatter([c["grid_half"]], [yi + 0.19], s=18, marker="^", facecolor="#334155", alpha=0.75, zorder=4)
        ax_c.scatter([c["grid_sph"]], [yi - 0.19], s=18, marker="s", facecolor="#64748B", alpha=0.75, zorder=4)

        if c["flagged"]:
            lbl_ci = f"{fmt_signed(c['rate_chg'])}%†"
            ax_c.text(max(c["rate_chg"] + 7.5, 5.0), yi, lbl_ci, fontsize=7.0, va="center", ha="left", color=COL_MUTED)
        else:
            lbl_ci = f"{fmt_signed(c['rate_chg'])}% [{fmt_signed(lo)}, {fmt_signed(hi)}]"
            if cid == "CP01":
                ax_c.text(5.0, yi, lbl_ci, fontsize=7.0, fontweight="bold", va="center", ha="left", color=COL_NEG)
            elif hi > 115:
                ax_c.text(hi, yi + 0.27, lbl_ci, fontsize=7.0, va="center", ha="right", color=COL_TEXT)
            else:
                ax_c.text(hi + 4.5, yi, lbl_ci, fontsize=7.0, va="center", ha="left", color=COL_TEXT)

    ax_c.set_yticks(yc_vals)
    ax_c.set_yticklabels([by_id[k]["short_en"].replace(" shipping zone", " zone") if lang == "en" else by_id[k]["name_cn"] for k in t1_all], fontsize=7.8)
    ax_c.set_xlim(-65, 176)
    ax_c.set_ylim(0.4, len(t1_all) + 0.65)
    ax_c.set_xticks([-50, 0, 50, 100, 150])
    ax_c.set_xticklabels(["−50", "0", "+50", "+100", "+150"])
    ax_c.set_xlabel("Rate change ΔR & 95% CI (%)" if lang == "en" else "标准化检测率变化 ΔR 及 95% CI（%）", fontsize=8.3)

    h_c = [
        mlines.Line2D([], [], marker="o", linestyle="-", color=COL_NEG, markersize=5.2, lw=1.8,
                      label="Baseline grid [95% CI]" if lang == "en" else "基准网格 [95% CI]"),
        mlines.Line2D([], [], marker="^", linestyle="None", color="#334155", markersize=4.5,
                      label="Halved grid" if lang == "en" else "间距减半网格"),
        mlines.Line2D([], [], marker="s", linestyle="None", color="#64748B", markersize=4.5,
                      label="Spherical grid" if lang == "en" else "球面加权网格"),
    ]
    ax_c.legend(handles=h_c, loc="lower right", frameon=True, facecolor="white", edgecolor="#E2E8F0",
                fontsize=6.7, handletextpad=0.35, borderpad=0.3)

    ax_c.text(-0.26, 1.035, "c", transform=ax_c.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_c.text(-0.17, 1.035, "Rate change & grid sensitivity" if lang == "en" else "相对变化率与网格敏感性",
              transform=ax_c.transAxes, fontsize=8.5, fontweight="bold", va="bottom", ha="left")

    out_path = resolve_out_path("fig2", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# MAIN FIG. 3: Concise subgroup labels kept, 'vs. min/max' prose strings out!
# ==============================================================================
def make_fig3(lang="en"):
    set_lang_rc(lang)
    corridors = DATA["corridors"]
    by_id = {c["id"]: c for c in corridors}
    n = len(corridors)
    ys = [n - i for i in range(n)]

    fig = plt.figure(figsize=(11.0, 8.2), dpi=360, facecolor="white")
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.22, 1.00], wspace=0.33,
                  left=0.252, right=0.982, top=0.895, bottom=0.075)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])

    for idx, c in enumerate(corridors):
        y = ys[idx]
        if c["outside_hist"]:
            ax1.axhspan(y - 0.45, y + 0.45, color="#FFF5F2", alpha=0.75, zorder=0)
        elif idx % 2 == 0:
            ax1.axhspan(y - 0.45, y + 0.45, color=COL_ZEBRA, alpha=0.9, zorder=0)

    for s_idx in [6, 16, 24]:
        ax1.axhline(ys[s_idx] - 0.5, color="#CBD5E1", lw=0.75, ls="--", zorder=1)

    ax1.axvline(0, color=COL_ZERO, lw=1.0, ls="--", zorder=2)
    ax1.grid(axis="x", color=COL_GRID, lw=0.6, zorder=0)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)

    for idx, c in enumerate(corridors):
        y = ys[idx]
        ax1.plot([c["hist_min"], c["hist_max"]], [y, y], color="#CBD5E1", lw=4.6, solid_capstyle="round", zorder=2)
        ax1.plot([c["hmed_ci_lo"], c["hmed_ci_hi"]], [y, y], color="#64748B", lw=2.1, solid_capstyle="butt", zorder=3)
        ax1.plot([c["hist_med"], c["hist_med"]], [y - 0.28, y + 0.28], color="#0F172A", lw=1.4, zorder=4)

        col26 = COL_POS if c["outside_hist"] else COL_NEG
        if not c["flagged"]:
            lo, hi = c["rc_ci"]
            ax1.plot([lo, hi], [y + 0.17, y + 0.17], color=col26, lw=1.15, alpha=0.75, zorder=4)
            ax1.scatter([c["rate_chg"]], [y], s=44, facecolor=col26, edgecolor="white", lw=0.6, zorder=5)
        else:
            ax1.scatter([c["rate_chg"]], [y], s=42, marker="D", facecolor="white", edgecolor=col26, lw=1.5, zorder=5)

    ax1.set_yticks(ys)
    ax1.set_yticklabels([c["short_en"] if lang == "en" else c["name_cn"] for c in corridors], fontsize=7.9)
    for tick_lbl, c in zip(ax1.get_yticklabels(), corridors):
        if c["is_focal"]:
            tick_lbl.set_fontweight("bold")
            tick_lbl.set_color("#0F172A")
    ax1.set_ylim(0.4, n + 0.6)
    ax1.set_xlim(-110, 325)
    ax1.set_xticks([-100, 0, 100, 200, 300])
    ax1.set_xticklabels(["−100", "0", "+100", "+200", "+300"])
    ax1.set_xlabel("Coverage-normalized rate change (%)" if lang == "en" else "覆盖标准化检测率变化（%）", fontsize=8.6, labelpad=6)
    ax1.spines["left"].set_visible(False)
    ax1.tick_params(axis="y", length=0, pad=6)

    trans = ax1.get_yaxis_transform()
    bx_out, bx_in = (-0.455, -0.432) if lang == "en" else (-0.365, -0.342)
    for g_en, g_cn, idx_start, idx_end in DATA["macro_groups"]:
        y_top = ys[idx_start] + 0.32
        y_bot = ys[idx_end] - 0.32
        y_mid = 0.5 * (y_top + y_bot)
        ax1.plot([bx_in, bx_out, bx_out, bx_in], [y_top, y_top, y_bot, y_bot],
                 transform=trans, clip_on=False, color="#64748B", lw=0.95)
        lbl_g = g_en.replace("–", "–\n") if lang == "en" else g_cn.replace("—", "—\n")
        ax1.text(bx_out - 0.015, y_mid, lbl_g, transform=trans, clip_on=False,
                 va="center", ha="right", fontsize=7.3, color=COL_MUTED, linespacing=1.15)

    # Panel b: Zoomed detail with concise structural block labels
    zoom_ids = ["CP01", "CP02", "CP26", "CP27", "CP04", "CP09", "CP17", "CP18", "CP22", "CP23"]
    yz = list(range(len(zoom_ids), 0, -1))

    ax2.axvline(0, color=COL_ZERO, lw=1.0, ls="--", zorder=2)
    ax2.axhline(yz[3] - 0.5, color="#94A3B8", lw=0.9, ls="--", zorder=2)
    ax2.grid(axis="x", color=COL_GRID, lw=0.6, zorder=0)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    for idx_z, (yi, cid) in enumerate(zip(yz, zoom_ids)):
        c = by_id[cid]
        if idx_z % 2 == 0:
            ax2.axhspan(yi - 0.44, yi + 0.44, color=COL_ZEBRA, zorder=0)

        yh = yi - 0.14
        ax2.plot([c["hist_min"], c["hist_max"]], [yh, yh], color="#CBD5E1", lw=4.5, solid_capstyle="round", zorder=2)
        ax2.plot([c["hmed_ci_lo"], c["hmed_ci_hi"]], [yh, yh], color="#64748B", lw=2.1, zorder=3)
        ax2.plot([c["hist_med"], c["hist_med"]], [yh - 0.14, yh + 0.14], color="#0F172A", lw=1.45, zorder=4)

        y26 = yi + 0.15
        col26 = COL_POS if c["outside_hist"] else COL_NEG
        if not c["flagged"]:
            lo, hi = c["rc_ci"]
            ax2.plot([lo, hi], [y26, y26], color=col26, lw=2.0, solid_capstyle="round", zorder=4)
            ax2.plot([lo, lo], [y26 - 0.08, y26 + 0.08], color=col26, lw=1.2, zorder=4)
            ax2.plot([hi, hi], [y26 - 0.08, y26 + 0.08], color=col26, lw=1.2, zorder=4)
            ax2.scatter([c["rate_chg"]], [y26], s=44, facecolor=col26, edgecolor="white", lw=0.6, zorder=5)
        else:
            ax2.scatter([c["rate_chg"]], [y26], s=42, marker="D", facecolor="white", edgecolor=col26, lw=1.5, zorder=5)
            ax2.text(c["rate_chg"] - 4.5, y26, "†", fontsize=7.8, fontweight="bold", ha="right", va="center", color="#64748B")

    # Necessary concise 2-word subgroup tags (placed in 100% clear right space)
    ax2.text(169, yz[0] + 0.36, "Focal corridors" if lang == "en" else "重点通道",
             fontsize=7.0, fontweight="bold", color="#334155", ha="right", va="top")
    ax2.text(169, yz[4] + 0.36, "Outside historical span" if lang == "en" else "超历史范围通道",
             fontsize=7.0, fontweight="bold", color=COL_POS, ha="right", va="top")

    zoom_en_map = {
        "CP01": "Strait of Hormuz", "CP02": "Bab el-Mandeb", "CP26": "Mozambique Channel",
        "CP27": "Cape of Good Hope", "CP04": "Dardanelles", "CP09": "Luzon Strait",
        "CP17": "Makassar Strait", "CP18": "Torres Strait", "CP22": "Windward Passage", "CP23": "Mona Passage"
    }
    ax2.set_yticks(yz)
    z_lbls = [zoom_en_map[k] if lang == "en" else by_id[k]["name_cn"] for k in zoom_ids]
    ax2.set_yticklabels(z_lbls, fontsize=7.8)
    for idx_z, tl in enumerate(ax2.get_yticklabels()):
        if idx_z < 4:
            tl.set_fontweight("bold")
    ax2.set_ylim(0.4, len(zoom_ids) + 0.6)
    ax2.set_xlim(-106, 174)
    ax2.set_xticks([-80, -40, 0, 40, 80, 120, 160])
    ax2.set_xticklabels(["−80", "−40", "0", "+40", "+80", "+120", "+160"])
    ax2.set_xlabel("Coverage-normalized rate change (%)" if lang == "en" else "覆盖标准化检测率变化（%）",
                   fontsize=8.6, labelpad=6)

    ax1.text(-0.04, 1.022, "a", transform=ax1.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax1.text(0.02, 1.022, "All 27 corridors" if lang == "en" else "全部 27 个通道",
             transform=ax1.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    ax2.text(-0.15, 1.022, "b", transform=ax2.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax2.text(-0.08, 1.022, "Focal & outside-span detail" if lang == "en" else "重点与超范围通道细部",
             transform=ax2.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mlines.Line2D([], [], color="#CBD5E1", lw=4.6, solid_capstyle="round", label="2017–2025 min–max"),
            mlines.Line2D([], [], color="#64748B", lw=2.2, label="Historical median 95% interval"),
            mlines.Line2D([], [], color="#0F172A", marker="|", linestyle="None", markersize=9, markeredgewidth=1.5, label="Historical median"),
            mlines.Line2D([], [], color=COL_POS, marker="o", lw=1.6, markersize=6, label="2026 outside span [95% CI]"),
            mlines.Line2D([], [], color=COL_NEG, marker="o", lw=1.6, markersize=6, label="2026 within span [95% CI]"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.6, markerfacecolor="white",
                          markeredgecolor=COL_POS, markeredgewidth=1.4, label="<5 covered days (†)"),
        ]
    else:
        handles = [
            mlines.Line2D([], [], color="#CBD5E1", lw=4.6, solid_capstyle="round", label="2017—2025年最小—最大范围"),
            mlines.Line2D([], [], color="#64748B", lw=2.2, label="历史中位数 95% 探索性区间"),
            mlines.Line2D([], [], color="#0F172A", marker="|", linestyle="None", markersize=9, markeredgewidth=1.5, label="历史中位数"),
            mlines.Line2D([], [], color=COL_POS, marker="o", lw=1.6, markersize=6, label="2026年超出历史范围 [95% CI]"),
            mlines.Line2D([], [], color=COL_NEG, marker="o", lw=1.6, markersize=6, label="2026年位于范围内 [95% CI]"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.6, markerfacecolor="white",
                          markeredgecolor=COL_POS, markeredgewidth=1.4, label="覆盖不足5日（†）"),
        ]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.56, 0.992),
               ncol=3, frameon=False, fontsize=7.6, handletextpad=0.5, columnspacing=1.35)

    out_path = resolve_out_path("fig3", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)


# ==============================================================================
# MAIN FIG. 4: Necessary math/panel/subgroup labels kept, '13/27...' narrative out!
# ==============================================================================
def make_fig4(lang="en"):
    set_lang_rc(lang)
    corridors = DATA["corridors"]
    by_id = {c["id"]: c for c in corridors}

    fig = plt.figure(figsize=(11.0, 6.5), dpi=360, facecolor="white")
    gs_outer = GridSpec(1, 2, figure=fig, width_ratios=[1.05, 1.15], wspace=0.25,
                        left=0.075, right=0.98, top=0.885, bottom=0.105)

    ax_a = fig.add_subplot(gs_outer[0, 0])
    ax_a.fill_between([-86, 0], 0, 34, color="#F8FAFC", zorder=0)
    ax_a.fill_between([0, 76], -55, 0, color="#F8FAFC", zorder=0)
    ax_a.axvline(0, color=COL_ZERO, lw=0.95, ls="--", zorder=2)
    ax_a.axhline(0, color=COL_ZERO, lw=0.95, ls="--", zorder=2)
    ax_a.grid(True, color=COL_GRID, lw=0.6, zorder=1)
    ax_a.spines["top"].set_visible(False)
    ax_a.spines["right"].set_visible(False)

    for c in corridors:
        if not c["is_focal"]:
            if c["flagged"]:
                ax_a.scatter([c["rate_chg"]], [c["unm_diff"]], s=32, marker="D",
                             facecolor="white", edgecolor="#64748B", lw=1.1, alpha=0.85, zorder=3)
            else:
                ax_a.scatter([c["rate_chg"]], [c["unm_diff"]], s=34,
                             facecolor="#64748B", edgecolor="white", lw=0.5, alpha=0.82, zorder=3)

    for cid in ["CP01", "CP02", "CP26", "CP27"]:
        c = by_id[cid]
        x, y = c["rate_chg"], c["unm_diff"]
        if not c["flagged"]:
            xlo, xhi = c["rc_ci"]
            ylo, yhi = c["du_ci"]
            xhi_draw = min(xhi, 70.5)
            ax_a.plot([xlo, xhi_draw], [y, y], color=COL_POS, lw=1.25, alpha=0.55, zorder=4)
            ax_a.plot([x, x], [ylo, yhi], color=COL_POS, lw=1.25, alpha=0.55, zorder=4)
            if xhi > 71:
                ax_a.annotate("", xy=(73.8, y), xytext=(66.0, y),
                              arrowprops=dict(arrowstyle="->", color=COL_POS, lw=1.2, alpha=0.65), zorder=4)
                ax_a.text(72.5, y + 1.8, "+164%", fontsize=6.5, color=COL_POS, ha="right", va="bottom")
            ax_a.scatter([x], [y], s=76, facecolor=COL_POS, edgecolor="white", lw=0.9, zorder=6)
        else:
            ax_a.scatter([x], [y], s=68, marker="D", facecolor="white", edgecolor=COL_POS, lw=1.8, zorder=6)

    callouts_a = [
        ("CP01", (-36.7, 17.7), (-46, 25.0), "center", True,
         "Strait of Hormuz" if lang == "en" else "霍尔木兹海峡"),
        ("CP02", (-23.9, 1.8), (-42, 9.2), "right", True,
         "Bab el-Mandeb†" if lang == "en" else "曼德海峡†"),
        ("CP26", (37.9, 11.2), (41.5, 24.0), "left", True,
         "Mozambique\nChannel" if lang == "en" else "莫桑比克海峡"),
        ("CP27", (6.9, -4.9), (-7, -15.0), "right", True,
         "Cape of Good Hope" if lang == "en" else "好望角航运区"),
        ("CP10", (51.1, 1.5), (44, 6.8), "left", False,
         "Korea Strait" if lang == "en" else "朝鲜/韩国海峡"),
        ("CP25", (-74.2, -50.0), (-58, -42.5), "left", False,
         "Cape Horn / N. Drake†" if lang == "en" else "合恩角/德雷克北部†"),
        ("CP23", (2.5, -21.5), (12, -28.0), "left", False,
         "Mona Passage" if lang == "en" else "莫纳海峡"),
        ("CP22", (33.3, -13.3), (42, -16.8), "left", False,
         "Windward\nPassage" if lang == "en" else "向风海峡"),
    ]
    for cid, xy_pt, xy_txt, ha_c, is_f, lbl in callouts_a:
        ax_a.annotate(lbl, xy=xy_pt, xytext=xy_txt, ha=ha_c, va="center",
                      fontsize=7.15 if is_f else 6.7,
                      fontweight="bold" if is_f else "normal",
                      color=COL_TEXT if is_f else COL_MUTED,
                      arrowprops=dict(arrowstyle="-", color="#64748B", lw=0.75, shrinkB=4), zorder=7)

    # Pure mathematical correlation metric ONLY (no '13/27 opposite signs' narrative!)
    ax_a.text(0.965, 0.045, "Spearman ρ = 0.237 (n = 27)", transform=ax_a.transAxes,
              fontsize=7.0, color=COL_MUTED, ha="right", va="bottom")

    ax_a.set_xlim(-86, 76)
    ax_a.set_ylim(-55, 34)
    ax_a.set_xlabel("Coverage-normalized detection rate change (%)" if lang == "en" else "覆盖标准化检测率变化（%）", fontsize=8.5)
    ax_a.set_ylabel("AIS-unmatched share change Δu (pp)" if lang == "en" else "AIS 未匹配占比变化 Δu（百分点）", fontsize=8.5)
    ax_a.text(-0.13, 1.03, "a", transform=ax_a.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_a.text(-0.04, 1.03, "Rate vs. unmatched-share Δ" if lang == "en" else "检测率与未匹配占比变化",
              transform=ax_a.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    # --- Stacked DABEST Estimation Panels b & c ---
    gs_right = gs_outer[0, 1].subgridspec(2, 1, height_ratios=[1.18, 1.0], hspace=0.22)
    ax_b = fig.add_subplot(gs_right[0, 0])
    ax_c = fig.add_subplot(gs_right[1, 0], sharex=ax_b)

    ais_ids = ["CP01", "CP02", "CP26", "CP27", "CP04", "CP22"]
    xs = np.arange(len(ais_ids))

    for ax in (ax_b, ax_c):
        ax.axhline(0, color=COL_ZERO, lw=0.95, ls="--", zorder=2)
        ax.axvline(3.5, color="#94A3B8", lw=0.85, ls=":", zorder=2)
        ax.grid(axis="y", color=COL_GRID, lw=0.6, zorder=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    dx = 0.15
    for i, cid in enumerate(ais_ids):
        c = by_id[cid]
        xm, xu = i - dx, i + dx
        ax_b.plot([xm, xu], [c["m_chg"], c["u_chg"]], color="#94A3B8", lw=1.0, zorder=2)
        if not c["ais_flagged"]:
            ax_b.plot([xm, xm], c["m_ci"], color=COL_MATCH, lw=1.75, solid_capstyle="round", zorder=3)
            ax_b.scatter([xm], [c["m_chg"]], s=44, facecolor=COL_MATCH, edgecolor="white", lw=0.6, zorder=4)
            ax_b.plot([xu, xu], c["u_ci"], color=COL_UNMATCH, lw=1.75, solid_capstyle="round", zorder=3)
            ax_b.scatter([xu], [c["u_chg"]], s=44, facecolor=COL_UNMATCH, edgecolor="white", lw=0.6, zorder=4)
        else:
            ax_b.scatter([xm], [c["m_chg"]], s=38, marker="D", facecolor="white", edgecolor=COL_MATCH, lw=1.4, zorder=4)
            ax_b.scatter([xu], [c["u_chg"]], s=38, marker="D", facecolor="white", edgecolor=COL_UNMATCH, lw=1.4, zorder=4)
            ax_b.text(i, max(c["m_chg"], c["u_chg"]) + 14, "†", ha="center", va="bottom", fontsize=7.8, fontweight="bold", color="#64748B")

    # Key stratum values + concise 2-word subgroup tags (no 'Table 4' or '显著' prose!)
    ax_b.text(0 - dx, -86, "−63.3%", ha="center", va="top", fontsize=6.7, fontweight="bold", color=COL_MATCH)
    ax_b.text(2 + dx + 0.08, 124.8, "+124.8%", ha="left", va="center", fontsize=6.7, fontweight="bold", color=COL_UNMATCH)
    ax_b.text(0.02, 0.94, "Focal regions" if lang == "en" else "重点海域",
              transform=ax_b.transAxes, fontsize=6.9, fontweight="bold", color="#334155", va="top")
    ax_b.text(0.98, 0.94, "Divergent regions" if lang == "en" else "分化对比海域",
              transform=ax_b.transAxes, fontsize=6.9, fontweight="bold", color=COL_MUTED, va="top", ha="right")

    ax_b.set_ylim(-124, 330)
    ax_b.set_yticks([-100, 0, 100, 200, 300])
    ax_b.set_yticklabels(["−100", "0", "+100", "+200", "+300"])
    ax_b.set_ylabel("Stratum rate Δ (%)" if lang == "en" else "分层检测率变化（%）", fontsize=8.3)
    ax_b.tick_params(axis="x", labelbottom=False, length=0)
    ax_b.text(-0.13, 1.05, "b", transform=ax_b.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_b.text(-0.04, 1.05, "AIS-stratified rate Δ" if lang == "en" else "AIS 分层检测率变化",
              transform=ax_b.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    # Panel c: Net Δu
    for i, cid in enumerate(ais_ids):
        c = by_id[cid]
        est = c["du_est"]
        col_du = COL_POS if est >= 0 else COL_NEG
        if not c["ais_flagged"]:
            lo, hi = c["du_ci"]
            excl = (lo > 0) or (hi < 0)
            ax_c.bar([i], [est], width=0.42, color=col_du, alpha=0.22 if excl else 0.12, edgecolor="none", zorder=2)
            ax_c.plot([i, i], [lo, hi], color=col_du if excl else "#64748B", lw=2.1 if excl else 1.5,
                      solid_capstyle="round", zorder=4)
            ax_c.scatter([i], [est], s=48, facecolor=col_du, edgecolor="white", lw=0.6, zorder=5)
            ty = hi + 2.4 if est >= 0 else lo - 2.8
            va_t = "bottom" if est >= 0 else "top"
            ax_c.text(i, ty, fmt_signed(est), ha="center", va=va_t, fontsize=6.9,
                      fontweight="bold" if excl else "normal", color=col_du if excl else COL_TEXT)
        else:
            ax_c.bar([i], [est], width=0.42, color="#CBD5E1", alpha=0.35, zorder=2)
            ax_c.scatter([i], [est], s=42, marker="D", facecolor="white", edgecolor=col_du, lw=1.5, zorder=5)
            ax_c.text(i, est + 3.2, f"{fmt_signed(est)}†", ha="center", va="bottom", fontsize=6.9, color=COL_MUTED)

    ax_c.set_ylim(-35, 39)
    ax_c.set_yticks([-20, -10, 0, 10, 20, 30])
    ax_c.set_yticklabels(["−20", "−10", "0", "+10", "+20", "+30"])
    ax_c.set_ylabel("Δu (pp)" if lang == "en" else "未匹配占比差 Δu (pp)", fontsize=8.3)
    ax_c.set_xlim(-0.62, len(ais_ids) - 0.38)
    ax_c.set_xticks(xs)
    x_lbls_c = (["Strait of\nHormuz", "Bab el-\nMandeb†", "Mozambique\nChannel",
                 "Cape of\nGood Hope", "Dardanelles", "Windward\nPassage"] if lang == "en"
                else ["霍尔木兹\n海峡", "曼德\n海峡†", "莫桑比克\n海峡",
                      "好望角\n航运区", "达达尼尔\n海峡", "向风\n海峡"])
    ax_c.set_xticklabels(x_lbls_c, fontsize=7.4)
    ax_c.text(-0.13, 1.05, "c", transform=ax_c.transAxes, fontsize=11.5, fontweight="bold", va="bottom", ha="left")
    ax_c.text(-0.04, 1.05, "Net unmatched-share shift Δu" if lang == "en" else "AIS 未匹配占比净差",
              transform=ax_c.transAxes, fontsize=8.6, fontweight="bold", va="bottom", ha="left")

    if lang == "en":
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=6.8, color=COL_POS, label="Focal region (95% CI)"),
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=5.5, color="#64748B", label="Comparative region"),
            mlines.Line2D([], [], marker="o", color=COL_MATCH, lw=1.7, markersize=5.8, label="AIS-matched Δ (%)"),
            mlines.Line2D([], [], marker="o", color=COL_UNMATCH, lw=1.7, markersize=5.8, label="AIS-unmatched Δ (%)"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.5, markerfacecolor="white",
                          markeredgecolor="#475569", markeredgewidth=1.3, label="<5 covered days (†)"),
        ]
    else:
        handles = [
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=6.8, color=COL_POS, label="重点海域（95% CI）"),
            mlines.Line2D([], [], marker="o", linestyle="None", markersize=5.5, color="#64748B", label="对比海域"),
            mlines.Line2D([], [], marker="o", color=COL_MATCH, lw=1.7, markersize=5.8, label="AIS 已匹配变化（%）"),
            mlines.Line2D([], [], marker="o", color=COL_UNMATCH, lw=1.7, markersize=5.8, label="AIS 未匹配变化（%）"),
            mlines.Line2D([], [], marker="D", linestyle="None", markersize=5.5, markerfacecolor="white",
                          markeredgecolor="#475569", markeredgewidth=1.3, label="覆盖不足5日（†）"),
        ]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.52, 0.99),
               ncol=5, frameon=False, fontsize=7.6, handletextpad=0.45, columnspacing=1.25)

    out_path = resolve_out_path("fig4", lang)
    fig.savefig(out_path, dpi=360)
    plt.close(fig)
    print("Generated:", out_path)

if __name__ == "__main__":
    for lg in ("en", "cn"):
        make_fig1(lg)
        make_fig2(lg)
        make_fig3(lg)
        make_fig4(lg)
