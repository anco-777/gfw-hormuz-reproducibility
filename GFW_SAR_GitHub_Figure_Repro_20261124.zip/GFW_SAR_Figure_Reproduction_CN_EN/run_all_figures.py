#!/usr/bin/env python3
"""
One-click reproduction script for all 22 high-resolution bilingual figures
(Main Figs. 1–4 and Supplementary Figs. 1–5, English & Simplified Chinese).

Usage:
    python3 run_all_figures.py
    python3 run_all_figures.py --out-dir /path/to/custom_output
"""
import os, sys, argparse, subprocess
from PIL import Image

REPO_ROOT = os.path.dirname(os.path.abspath(__file__))

def main():
    parser = argparse.ArgumentParser(description="Regenerate all 22 bilingual figures and CSV source tables.")
    parser.add_argument("--out-dir", default=os.path.join(REPO_ROOT, "figures"),
                        help="Output directory for generated figures (default: ./figures)")
    args = parser.parse_args()

    out_dir = os.path.abspath(args.out_dir)
    env = {**os.environ, "GFW_FIG_OUT_DIR": out_dir}

    print("[1/3] Exporting structured CSV source tables...")
    subprocess.run([sys.executable, os.path.join(REPO_ROOT, "scripts", "export_csv_tables.py")], env=env, check=True)

    print("[2/3] Generating Main Figures 1–4 (EN & CN, 360 DPI)...")
    subprocess.run([sys.executable, os.path.join(REPO_ROOT, "scripts", "generate_main_figures.py")], env=env, check=True)

    print("[3/3] Generating Supplementary Figures 1–5 (EN & CN, 350–360 DPI)...")
    subprocess.run([sys.executable, os.path.join(REPO_ROOT, "scripts", "generate_supp_figures.py")], env=env, check=True)

    png_count = 0
    for sub in ["English_Main", "English_Supplement", "Chinese_Main", "Chinese_Supplement"]:
        sub_p = os.path.join(out_dir, sub)
        for fn in sorted(os.listdir(sub_p)):
            if fn.endswith(".png"):
                im = Image.open(os.path.join(sub_p, fn))
                dpi = round(im.info.get("dpi", (0, 0))[0])
                assert im.size[0] >= 2200 and dpi >= 350, f"Unexpected dimensions/DPI for {fn}: {im.size} @ {dpi}"
                png_count += 1
    assert png_count == 22, f"Expected 22 PNGs, got {png_count}"
    print(f"\n[SUCCESS] Verified all {png_count} high-resolution PNG figures (350–360 DPI) in: {out_dir}")

if __name__ == "__main__":
    main()
