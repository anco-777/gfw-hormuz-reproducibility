# Maritime SAR study data and code

Fixed release: **2026-10-24**

Public entry: https://gfw-hormuz-reproducibility-20261024.bold-wasp-3237.chatgpt.site

The release supports the 27-region Sentinel-1 SAR manuscript. It contains research-derived data, study boundaries, table CSVs, analysis programs and numerical validation outputs. The raw 92.87 GiB Global Fishing Watch (GFW) CSV collection is obtained separately from GFW.

## Run from the raw snapshot

Use Python 3.12.14 and the dependencies in requirements_audit.txt. From this Reproducibility directory:

```bash
python -m pip install -r requirements_audit.txt
python code/run_completed_raw.py --raw-dir /path/to/gfw_csv --run-dir /path/to/empty_run_directory
```

The 228 exact input filenames, sizes and product versions are identified by results/completed_raw/raw_input_inventory.csv and the supplied snapshot metadata. The optional --hash-raw flag calculates raw file SHA256 values locally. Blank original raw hashes mean no raw hash was provided, not that the files have been byte-authenticated.

## Validate the distributed results without raw CSVs

```bash
python code/validate_completed_raw_results.py --root . --results-dir results/completed_raw --output-dir /path/to/validation
python code/verify_temporal_order.py --root . --output-dir /path/to/temporal_order
```

For the daily figure, install requirements_figures.txt and add --plot to the second command. The public release reads exact manuscript-table CSVs in tables/ instead of requiring the draft Word documents. Private review comments and draft prose are not distributed.

## Data and calculation conventions

- data/regions_27.geojson contains 26 polygons and the Panama centerline. Panama uses the original 6-km local-distance predicate, not a replacement buffer polygon. data/coordinate_reference_system.json declares WGS 84 (EPSG:4326), longitude/latitude storage order (OGC:CRS84), degrees, no reprojection, and the area approximation.
- results/completed_raw/ holds the current exact-date history, daily data, AIS groups, area/window sensitivity and fixed-baseline phases.
- results/temporal_order/ holds all 432 descriptive settings, 1,296 regional first-qualifying-block records, daily changes, figures and provenance. No setting produces the proposed strictly separated three-stage sequence. Missing coverage cannot be treated as zero activity. These diagnostics do not estimate causal delays or statistical change-point confidence intervals.
- Strict AIS matching excludes blank/na/nan status, which is retained as unknown in total counts and share denominators. The Cape post-event strict count is 1,352, plus three unknown records; its matched-rate change is +13.2%.
- data/ contains historical source aggregates retained for comparison. data/09 uses an older 14-day approximation and is not the manuscript exact-date baseline. Use results/completed_raw/historical_exact_date_2017_2025_summary.csv for the current history.
- source/original_code/ retains numerical algorithms with local machine path defaults replaced by generic placeholders. The launcher supplies actual paths. Package hashes identify this public release, not the privately received original files.
- results/validation/ supplies 4/4 manuscript-table checks and the received/rechecked 9/9 original-output comparison. The current revision environment recomputed temporal diagnostics from the supplied daily CSVs; it did not reread the full raw collection.

## Source, attribution and reuse

Original GFW data: https://globalfishingwatch.org/datasets-and-code/

GFW dataset description: https://globalfishingwatch.org/platform-update/2024-may-data-download-portal-new-dataset-released-featuring-vessel-detections-from-sentinel-1-sar/

Upstream detection methods: https://github.com/GlobalFishingWatch/paper-industrial-activity

Upstream SAR–AIS matching: https://github.com/GlobalFishingWatch/paper-longline-ais-sar-matching

Third-party data and code retain their original rights and terms. This release does not relicense GFW data. Obtain the raw snapshot using GFW's access requirements and cite GFW and the associated source research. This is a public download release; no DOI has been assigned.

## File integrity

SHA256SUMS.csv enumerates relative paths, byte sizes and SHA256 of the distributed files, excluding itself. The landing page and release.json separately identify the downloadable ZIP checksums. Keep the release date with downloaded material.
