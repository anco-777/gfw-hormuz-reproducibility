"""Raw-data event sensitivities and AIS matching groups for all 27 regions."""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from spatial_core import (
    covered_area_grid,
    flat_coords,
    footprint_key,
    load_regions,
    make_grid,
    points_in_polygon,
    points_near_panama,
    region_bbox,
)

csv.field_size_limit(2**31 - 1)


START = datetime(2026, 2, 1, tzinfo=timezone.utc)
END = datetime(2026, 3, 28, tzinfo=timezone.utc)
DAY_COUNT = (END - START).days


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def day_slice(first, last_inclusive):
    a = (datetime.fromisoformat(first).replace(tzinfo=timezone.utc) - START).days
    b = (datetime.fromisoformat(last_inclusive).replace(tzinfo=timezone.utc) - START).days + 1
    return slice(a, b)


def aggregate(counts, areas, span):
    count = int(counts[span].sum())
    area = float(areas[span].sum())
    return count, area, count / area * 1000 if area > 0 else None


def change(pre_rate, post_rate):
    return (post_rate / pre_rate - 1) * 100 if pre_rate and post_rate is not None else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--raw-dir", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    args = ap.parse_args()
    root = args.root.resolve()
    raw = args.raw_dir.resolve()
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)

    regions, panama = load_regions(root)
    original_grids = {rid: make_grid(rid, poly, panama, 1.0) for rid, (_, poly) in regions.items()}
    half_grids = {rid: make_grid(rid, poly, panama, 0.5) for rid, (_, poly) in regions.items()}
    detection_files = [
        raw / "sar_vessel_detections_pipev3_202602.csv",
        raw / "sar_vessel_detections_pipev4_202603.csv",
    ]
    footprint_files = [
        raw / "sar_detections_footprints_202602.csv",
        raw / "sar_detections_footprints_202603.csv",
    ]
    missing = [p for p in detection_files + footprint_files if not p.is_file()]
    if missing:
        raise SystemExit(f"Missing inputs: {[p.name for p in missing]}")

    groups = ("total", "matched", "unmatched", "unknown")
    counts = {rid: {group: np.zeros(DAY_COUNT, dtype=np.int64) for group in groups} for rid in regions}
    detection_rows_read = 0
    for file in detection_files:
        for chunk in pd.read_csv(file, usecols=["timestamp", "lat", "lon", "matched_category"], chunksize=300_000, low_memory=False):
            detection_rows_read += len(chunk)
            ts = pd.to_datetime(chunk["timestamp"], utc=True, errors="coerce")
            keep = ts.notna() & (ts >= START) & (ts < END)
            if not keep.any():
                continue
            lon = chunk.loc[keep, "lon"].to_numpy(float)
            lat = chunk.loc[keep, "lat"].to_numpy(float)
            days = ((ts.loc[keep] - START).dt.total_seconds() // 86400).astype(int).to_numpy()
            category = chunk.loc[keep, "matched_category"].fillna("").astype(str).str.strip().str.lower().to_numpy()
            is_unmatched = category == "unmatched"
            is_unknown = np.isin(category, ["", "na", "nan"])
            is_matched = ~(is_unmatched | is_unknown)
            for rid, (_, poly) in regions.items():
                w, s, e, n = region_bbox(rid, poly, panama)
                candidate = (lon >= w) & (lon <= e) & (lat >= s) & (lat <= n)
                if not candidate.any():
                    continue
                hit_local = points_near_panama(lon[candidate], lat[candidate], panama) if rid == 19 else points_in_polygon(lon[candidate], lat[candidate], poly)
                candidate_indices = np.flatnonzero(candidate)
                selected = candidate_indices[hit_local]
                if not len(selected):
                    continue
                np.add.at(counts[rid]["total"], days[selected], 1)
                np.add.at(counts[rid]["matched"], days[selected[is_matched[selected]]], 1)
                np.add.at(counts[rid]["unmatched"], days[selected[is_unmatched[selected]]], 1)
                np.add.at(counts[rid]["unknown"], days[selected[is_unknown[selected]]], 1)
        print(f"detections {file.name}", flush=True)

    area_modes = ("original_nominal", "half_nominal", "half_spherical")
    coverage = {rid: {mode: np.zeros(DAY_COUNT, dtype=float) for mode in area_modes} for rid in regions}
    footprint_rows = {rid: np.zeros(DAY_COUNT, dtype=np.int64) for rid in regions}
    footprint_rows_read = 0
    duplicates_skipped = 0
    for file in footprint_files:
        seen = set()
        with file.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                footprint_rows_read += 1
                date_text = row.get("date") or ""
                if not ("2026-02-01" <= date_text <= "2026-03-27"):
                    continue
                dt = datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                if not START <= dt < END:
                    continue
                wkt = row.get("footprint_wkt")
                if not wkt:
                    continue
                key = footprint_key(row)
                if key in seen:
                    duplicates_skipped += 1
                    continue
                seen.add(key)
                coords = flat_coords(wkt)
                if coords.size == 0:
                    continue
                minx, miny = coords.min(axis=0)
                maxx, maxy = coords.max(axis=0)
                day = (dt - START).days
                for rid in regions:
                    grid = original_grids[rid]
                    w, s, e, n = grid["bbox"]
                    if maxx < w or minx > e or maxy < s or miny > n:
                        continue
                    original = covered_area_grid(wkt, original_grids[rid], "nominal")
                    half = covered_area_grid(wkt, half_grids[rid], "nominal")
                    spherical = covered_area_grid(wkt, half_grids[rid], "spherical")
                    if original > 0 or half > 0 or spherical > 0:
                        coverage[rid]["original_nominal"][day] += original
                        coverage[rid]["half_nominal"][day] += half
                        coverage[rid]["half_spherical"][day] += spherical
                        footprint_rows[rid][day] += 1
        print(f"footprints {file.name}", flush=True)

    spans = {
        "7d_pre": day_slice("2026-02-21", "2026-02-27"),
        "7d_post": day_slice("2026-03-01", "2026-03-07"),
        "14d_pre": day_slice("2026-02-14", "2026-02-27"),
        "14d_post": day_slice("2026-03-01", "2026-03-14"),
        "25d_pre": day_slice("2026-02-01", "2026-02-25"),
        "25d_post": day_slice("2026-03-01", "2026-03-25"),
        "27d_pre": day_slice("2026-02-01", "2026-02-27"),
        "27d_post": day_slice("2026-03-01", "2026-03-27"),
        "phase_1": day_slice("2026-03-01", "2026-03-07"),
        "phase_2": day_slice("2026-03-08", "2026-03-14"),
        "phase_3": day_slice("2026-03-15", "2026-03-27"),
    }

    daily_rows = []
    sensitivity_rows = []
    window_rows = []
    phase_rows = []
    ais_rows = []
    dates = [(START + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(DAY_COUNT)]
    for rid, (name, _) in regions.items():
        for day, date_text in enumerate(dates):
            total = int(counts[rid]["total"][day])
            matched = int(counts[rid]["matched"][day])
            unmatched = int(counts[rid]["unmatched"][day])
            unknown = int(counts[rid]["unknown"][day])
            original_area = float(coverage[rid]["original_nominal"][day])
            daily_rows.append({
                "cp": f"CP{rid:02d}", "name": name, "date": date_text,
                "total_count": total, "matched_strict_count": matched,
                "non_unmatched_count": total - unmatched,
                "unmatched_count": unmatched, "unknown_count": unknown,
                "unmatched_share": unmatched / total if total else None,
                "coverage_original_km2": round(original_area, 6),
                "coverage_half_grid_km2": round(float(coverage[rid]["half_nominal"][day]), 6),
                "coverage_half_grid_spherical_km2": round(float(coverage[rid]["half_spherical"][day]), 6),
                "total_rate_original_per_1000_km2": round(total / original_area * 1000, 9) if original_area > 0 else None,
                "matched_strict_rate_original_per_1000_km2": round(matched / original_area * 1000, 9) if original_area > 0 else None,
                "non_unmatched_rate_original_per_1000_km2": round((total - unmatched) / original_area * 1000, 9) if original_area > 0 else None,
                "unmatched_rate_original_per_1000_km2": round(unmatched / original_area * 1000, 9) if original_area > 0 else None,
                "footprint_rows_counted": int(footprint_rows[rid][day]),
            })

        for mode in area_modes:
            pre_count, pre_area, pre_rate = aggregate(counts[rid]["total"], coverage[rid][mode], spans["27d_pre"])
            post_count, post_area, post_rate = aggregate(counts[rid]["total"], coverage[rid][mode], spans["27d_post"])
            sensitivity_rows.append({
                "cp": f"CP{rid:02d}", "name": name, "area_method": mode,
                "grid_spacing_factor": 1.0 if mode == "original_nominal" else 0.5,
                "cell_area_weight": "spherical" if mode == "half_spherical" else "nominal_spacing_squared",
                "pre_count": pre_count, "post_count": post_count,
                "pre_coverage_km2_obs": round(pre_area, 6), "post_coverage_km2_obs": round(post_area, 6),
                "pre_rate_per_1000_km2": round(pre_rate, 9) if pre_rate is not None else None,
                "post_rate_per_1000_km2": round(post_rate, 9) if post_rate is not None else None,
                "change_pct": round(change(pre_rate, post_rate), 9) if change(pre_rate, post_rate) is not None else None,
            })

        for window in ("7d", "14d", "25d", "27d"):
            pre_count, pre_area, pre_rate = aggregate(counts[rid]["total"], coverage[rid]["original_nominal"], spans[f"{window}_pre"])
            post_count, post_area, post_rate = aggregate(counts[rid]["total"], coverage[rid]["original_nominal"], spans[f"{window}_post"])
            window_rows.append({
                "cp": f"CP{rid:02d}", "name": name, "window": window,
                "pre_count": pre_count, "post_count": post_count,
                "pre_coverage_km2_obs": round(pre_area, 6), "post_coverage_km2_obs": round(post_area, 6),
                "pre_rate_per_1000_km2": round(pre_rate, 9) if pre_rate is not None else None,
                "post_rate_per_1000_km2": round(post_rate, 9) if post_rate is not None else None,
                "change_pct": round(change(pre_rate, post_rate), 9) if change(pre_rate, post_rate) is not None else None,
            })

        pre_count, pre_area, pre_rate = aggregate(counts[rid]["total"], coverage[rid]["original_nominal"], spans["27d_pre"])
        for phase_name, start_date, end_date in [
            ("phase_1", "2026-03-01", "2026-03-07"),
            ("phase_2", "2026-03-08", "2026-03-14"),
            ("phase_3", "2026-03-15", "2026-03-27"),
        ]:
            post_count, post_area, post_rate = aggregate(counts[rid]["total"], coverage[rid]["original_nominal"], spans[phase_name])
            phase_rows.append({
                "cp": f"CP{rid:02d}", "name": name,
                "baseline_start": "2026-02-01", "baseline_end": "2026-02-27",
                "phase": phase_name, "phase_start": start_date, "phase_end": end_date,
                "baseline_count": pre_count, "phase_count": post_count,
                "baseline_coverage_km2_obs": round(pre_area, 6), "phase_coverage_km2_obs": round(post_area, 6),
                "baseline_rate_per_1000_km2": round(pre_rate, 9) if pre_rate is not None else None,
                "phase_rate_per_1000_km2": round(post_rate, 9) if post_rate is not None else None,
                "change_pct": round(change(pre_rate, post_rate), 9) if change(pre_rate, post_rate) is not None else None,
            })

        group_result = {}
        for group in groups:
            pre_c, _, pre_r = aggregate(counts[rid][group], coverage[rid]["original_nominal"], spans["27d_pre"])
            post_c, _, post_r = aggregate(counts[rid][group], coverage[rid]["original_nominal"], spans["27d_post"])
            group_result[group] = (pre_c, post_c, pre_r, post_r)
        total_pre, total_post = group_result["total"][0], group_result["total"][1]
        unmatched_pre, unmatched_post = group_result["unmatched"][0], group_result["unmatched"][1]
        non_unmatched = counts[rid]["total"] - counts[rid]["unmatched"]
        non_unmatched_pre, _, non_unmatched_pre_rate = aggregate(non_unmatched, coverage[rid]["original_nominal"], spans["27d_pre"])
        non_unmatched_post, _, non_unmatched_post_rate = aggregate(non_unmatched, coverage[rid]["original_nominal"], spans["27d_post"])
        ais_rows.append({
            "cp": f"CP{rid:02d}", "name": name,
            "pre_total_count": total_pre, "post_total_count": total_post,
            "pre_matched_strict_count": group_result["matched"][0], "post_matched_strict_count": group_result["matched"][1],
            "pre_non_unmatched_count": non_unmatched_pre, "post_non_unmatched_count": non_unmatched_post,
            "pre_unmatched_count": unmatched_pre, "post_unmatched_count": unmatched_post,
            "pre_unknown_count": group_result["unknown"][0], "post_unknown_count": group_result["unknown"][1],
            "matched_strict_rate_change_pct": round(change(group_result["matched"][2], group_result["matched"][3]), 9) if change(group_result["matched"][2], group_result["matched"][3]) is not None else None,
            "non_unmatched_rate_change_pct": round(change(non_unmatched_pre_rate, non_unmatched_post_rate), 9) if change(non_unmatched_pre_rate, non_unmatched_post_rate) is not None else None,
            "unmatched_rate_change_pct": round(change(group_result["unmatched"][2], group_result["unmatched"][3]), 9) if change(group_result["unmatched"][2], group_result["unmatched"][3]) is not None else None,
            "pre_unmatched_share": unmatched_pre / total_pre if total_pre else None,
            "post_unmatched_share": unmatched_post / total_post if total_post else None,
            "unmatched_share_change_pp": round((unmatched_post / total_post - unmatched_pre / total_pre) * 100, 9) if total_pre and total_post else None,
        })

    paths = {
        "daily": out / "event_2026_daily_ais_and_area.csv",
        "area_sensitivity": out / "event_2026_area_method_sensitivity.csv",
        "window_sensitivity": out / "event_2026_window_sensitivity.csv",
        "fixed_baseline_phases": out / "event_2026_fixed_baseline_phases.csv",
        "ais_summary": out / "event_2026_ais_groups_27day_summary.csv",
    }
    write_csv(paths["daily"], daily_rows)
    write_csv(paths["area_sensitivity"], sensitivity_rows)
    write_csv(paths["window_sensitivity"], window_rows)
    write_csv(paths["fixed_baseline_phases"], phase_rows)
    write_csv(paths["ais_summary"], ais_rows)
    metadata = {
        "event_date": "2026-02-28",
        "main_pre": "2026-02-01 to 2026-02-27",
        "main_post": "2026-03-01 to 2026-03-27",
        "detection_rows_read": detection_rows_read,
        "footprint_rows_read": footprint_rows_read,
        "duplicate_footprint_rows_skipped": duplicates_skipped,
        "area_methods": list(area_modes),
        "ais_group_definitions": {
            "matched_strict": "matched_category is neither unmatched nor blank/NA/NaN",
            "non_unmatched": "all rows except matched_category=unmatched; this reproduces the manuscript matched column and therefore includes unknown status",
            "unmatched": "matched_category normalized to lowercase equals unmatched",
        },
        "outputs": {key: str(value) for key, value in paths.items()},
    }
    (out / "event_2026_sensitivity_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
